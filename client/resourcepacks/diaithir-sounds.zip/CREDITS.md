# Diaithir Sounds credits

All files are converted to Ogg Vorbis; nothing else is changed. CC-BY and OGA-BY need the credit below; CC-BY-SA files stay CC-BY-SA.

- "3 Melee sounds" by remaxim (CC0), https://opengameart.org/content/3-melee-sounds
- "A New Town (RPG Theme)" by cynicmusic (CC0), https://opengameart.org/content/a-new-town-rpg-theme
- "Bagpipes" by Spring Spring (CC-BY 3.0), https://opengameart.org/content/bagpipes
- "Bagpipes With Drums" by Tozan (CC0), https://opengameart.org/content/bagpipes-with-drums
- "Blacksmith's Hammer" by VishwaJai (CC0), https://opengameart.org/content/blacksmiths-hammer
- "Church Bell" by qubodup (CC-BY-SA 3.0), https://opengameart.org/content/church-bell
- "Dark Descent" by Matthew Pablo (CC-BY 3.0), https://opengameart.org/content/dark-descent
- "Dark Forest Bird" by Mobeyee Sounds (CC-BY 4.0), https://opengameart.org/content/dark-forest-bird
- "Enchanted Festival" by Matthew Pablo (CC-BY 3.0), https://opengameart.org/content/enchanted-festival
- "Fantasy: Lament for a Warrior's Soul" by RandomMind (CC0), https://opengameart.org/content/fantasy-lament-for-a-warriors-soul
- "Fire Crackling" by AntumDeluge (CC0), https://opengameart.org/content/fire-crackling
- "Fireplace Sound loop" by PagDev (CC0), https://opengameart.org/content/fireplace-sound-loop
- "Flutenist Dance 2" by Spring Spring (CC0), https://opengameart.org/content/flutenist-dance-2
- "Historic Renaissance music from 1597: If my complaints could passions move by John Dowland" by Of Far Different Nature (CC0), https://opengameart.org/content/historic-renaissance-music-from-1597-if-my-complaints-could-passions-move-by-john-dowland
- "Ireland's Coast (Game Edition - LIVE PLAYERS)" by Matthew Pablo (CC-BY 3.0), https://opengameart.org/content/irelands-coast-game-edition-live-players
- "Ireland's Coast (Game Edition)" by Matthew Pablo (CC-BY 3.0), https://opengameart.org/content/irelands-coast-game-edition
- "Ireland's Coast (Travelog Edition - LIVE PLAYERS)" by Matthew Pablo (CC-BY 3.0), https://opengameart.org/content/irelands-coast-travelog-edition-live-players
- "Lazy Day" by FoxSynergy (CC-BY 3.0), https://opengameart.org/content/lazy-day
- "Medieval: King's Feast" by RandomMind (CC0), https://opengameart.org/content/medieval-kings-feast
- "Medieval: Minstrel Dance" by RandomMind (CC0), https://opengameart.org/content/medieval-minstrel-dance
- "Medieval: The Bard's Tale" by RandomMind (CC0), https://opengameart.org/content/medieval-the-bards-tale
- "Medieval: The Old Tower Inn" by RandomMind (CC0), https://opengameart.org/content/medieval-the-old-tower-inn
- "Osare (Unrest Theme)" by HaelDB (CC0), https://opengameart.org/content/osare-unrest-theme
- "RPG - Costal Town Background Music" by Hitctrl (CC-BY 3.0), https://opengameart.org/content/rpg-costal-town-background-music
- "RPG Audio" by Kenney (CC0), https://kenney.nl/assets/rpg-audio
- "Soft Mysterious Harp Loop" by VWolfdog (CC-BY 3.0), https://opengameart.org/content/soft-mysterious-harp-loop
- "Swishes Sound Pack" by artisticdude (CC0), https://opengameart.org/content/swishes-sound-pack
- "Sylvan Waltz (standard + looped version)" by Otto Halmén (CC-BY 3.0), https://opengameart.org/content/sylvan-waltz-standard-looped-version
- "Woodland Fantasy" by Matthew Pablo (CC-BY 3.0), https://opengameart.org/content/woodland-fantasy
