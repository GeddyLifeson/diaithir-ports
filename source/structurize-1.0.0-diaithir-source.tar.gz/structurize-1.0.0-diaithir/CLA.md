# LDTTeam CLA

Thank you for your interest in contributing to the ldtteam organization (the "Organization"). In order to clarify the intellectual property license granted with Contributions from any person or entity, the Organization must have a Contributor License Agreement ("CLA") on file that has been signed by each Contributor, indicating agreement to the license terms below. This license is for your protection as a Contributor as well as the protection of the Organization and its users; it does not change your rights to use your own Contributions for any other purpose.

Please read this document carefully before signing and keep a copy for your records.

You accept and agree to the following terms and conditions for Your present and future Contributions submitted to the Organization. Except for the license granted herein to the Organization and recipients of software distributed by the Organization, You reserve all right, title, and interest in and to Your Contributions.

### Section 1. Definitions.
 * "You" (or "Your") shall mean the copyright owner or legal entity authorized by the copyright owner that is making this Agreement with the Organization. For legal entities, the entity making a Contribution and all other entities that control, are controlled by, or are under common control with that entity are considered to be a single Contributor. 

   For the purposes of this definition, "control" means **(i)** the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or **(ii)** ownership of fifty percent (50%) or more of the outstanding shares, or **(iii)** beneficial ownership of such entity. 
 
 * "Contribution" shall mean any original work of authorship, including any modifications or additions to an existing work, that is intentionally submitted by You to the Organization for inclusion in, or documentation of, any of the products owned or managed by the Organization (the "Work"). 

   For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Organization or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Organization for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by You as "Not a Contribution."
 
### Section 2. Grant of Copyright License.
Subject to the terms and conditions of this Agreement, You hereby grant to the Organization and to recipients of software distributed by the Organization a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare derivative works of, publicly display, publicly perform, sublicense, and distribute Your Contributions and such derivative works.

### Section 3. Grant of Patent License.
Subject to the terms and conditions of this Agreement, You hereby grant to the Organization and to recipients of software distributed by the Organization a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by You that are necessarily infringed by Your Contribution(s) alone or by combination of Your Contribution(s) with the Work to which such Contribution(s) was submitted. If any entity institutes patent litigation against You or any other entity (including a cross-claim or counterclaim in a lawsuit) alleging that your Contribution, or the Work to which you have contributed, constitutes direct or contributory patent infringement, then any patent licenses granted to that entity under this Agreement for that Contribution or Work shall terminate as of the date such litigation is filed.

### Section 4.
You represent that you are legally entitled to grant the above license. If your employer(s) has rights to intellectual property that you create that includes your Contributions, you represent that you have received permission to make Contributions on behalf of that employer, that your employer has waived such rights for your Contributions to the Organization, or that your employer has executed a separate Corporate CLA with the Organization.

### Section 5.
You represent that each of Your Contributions is Your original creation (see [section 7](#section-7) for submissions on behalf of others). You represent that Your Contribution submissions include complete details of any third-party license or other restriction (including, but not limited to, related patents and trademarks) of which you are personally aware and which are associated with any part of Your Contributions.

### Section 6.
You are not expected to provide support for Your Contributions, except to the extent You desire to provide support. You may provide support for free, for a fee, or not at all. Unless required by applicable law or agreed to in writing, You provide Your Contributions on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON- INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE.

### Section 7. 
Should You wish to submit work that is not Your original creation, You may submit it to the Organization separately from any Contribution, identifying the complete details of its source and of any license or other restriction (including, but not limited to, related patents, trademarks, and license agreements) of which you are personally aware, and conspicuously marking the work as _"Submitted on behalf of a third-party: [named here]"_.

### Section 8. 
You agree to notify the Organization of any facts or circumstances of which you become aware that would make these representations inaccurate in any respect.
