package com.ldtteam.structurize.blocks.schematic;

import com.ldtteam.structurize.api.RegistryIds;
import com.ldtteam.structurize.items.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlockContainer;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.EntityCollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

/**
 * This block is used as a substitution block for the Builder. Every solid block can be substituted by this block in schematics. This helps make schematics independent from
 * location and ground.
 */
public class BlockSubstitution extends Block implements LiquidBlockContainer
{
    /**
     * Constructor for the Substitution block. sets the creative tab, as well as the resistance and the hardness.
     */
    public BlockSubstitution()
    {
        super(defaultSubstitutionProperties()
                .forceSolidOff());  // don't kill farmland and path blocks underneath
    }

    public static Properties defaultSubstitutionProperties()
    {
        return RegistryIds.withId(Properties.of())
            .mapColor(MapColor.WOOD)
            .sound(SoundType.WOOD)
            .instabreak() // must be before explosionResistance
            .explosionResistance(Blocks.OAK_PLANKS.getExplosionResistance())
            .noOcclusion();
    }

    @Override
    public VoxelShape getShape(final BlockState state, final BlockGetter worldIn, final BlockPos pos, final CollisionContext context)
    {
        return Shapes.box(.125D, .125D, .125D, .875D, .875D, .875D);
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter blockGetter, BlockPos blockPos, CollisionContext context) {
        // Allow players to move through placeholders with a scantool in hand
        if (context instanceof EntityCollisionContext entityContext && entityContext.getEntity() instanceof Player player)
        {
            if (player.getMainHandItem().getItem() == ModItems.scanTool.get() || player.getOffhandItem().getItem() == ModItems.scanTool.get())
            {
                return Shapes.empty();
            }
        }

        return super.getCollisionShape(state,blockGetter,blockPos,context);
    }

    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter worldIn, BlockPos pos)
    {
        // Allow torches etc to be placed on the faces regardless of collision shape
        return Shapes.block();
    }

    @Override
    public boolean canPlaceLiquid(@Nullable LivingEntity player, BlockGetter level, BlockPos pos, BlockState state, Fluid fluid)
    {
        // Don't allow water to flow inside despite being non-solid
        return false;
    }

    @Override
    public boolean placeLiquid(LevelAccessor level, BlockPos pos, BlockState state, FluidState fluidState)
    {
        return false;
    }
}
