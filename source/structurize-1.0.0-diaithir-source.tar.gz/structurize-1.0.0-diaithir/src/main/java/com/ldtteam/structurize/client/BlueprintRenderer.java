package com.ldtteam.structurize.client;

import com.ldtteam.structurize.Structurize;
import com.ldtteam.structurize.blockentities.BlockEntityTagSubstitution;
import com.ldtteam.structurize.blocks.ModBlocks;
import com.ldtteam.structurize.blueprints.v1.Blueprint;
import com.ldtteam.structurize.blueprints.v1.BlueprintUtils;
import com.ldtteam.structurize.client.fakelevel.BlueprintBlockAccess;
import com.ldtteam.structurize.component.CapturedBlock;
import com.ldtteam.structurize.storage.rendering.types.BlueprintPreviewData;
import com.ldtteam.structurize.util.BlockInfo;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.QuadInstance;
import net.minecraft.CrashReport;
import net.minecraft.ReportType;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.renderer.block.BlockQuadOutput;
import net.minecraft.client.renderer.block.BlockStateModelSet;
import net.minecraft.client.renderer.block.ModelBlockRenderer;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.minecraft.util.profiling.Profiler;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.CardinalLighting;
import net.minecraft.world.level.ColorResolver;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.lighting.LevelLightEngine;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.model.data.ModelData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * The renderer for blueprint.
 * Holds all information required to render a blueprint.
 * <p>
 * 26.1: blocks are tessellated once into recorded quads and replayed each frame through the moving block render types
 * (the ones vanilla uses for pistons). Dropped: preview entities, block entity renderers, fluids.
 */
public class BlueprintRenderer implements AutoCloseable
{
    private static final Logger LOGGER = LoggerFactory.getLogger(BlueprintRenderer.class);

    private static boolean hasWarnedExceptions = false;

    private final BlueprintBlockAccess blockAccess;
    List<Entity> entities = List.of();
    private List<BlockEntity> tileEntities;
    private List<RecordedQuad> quads;
    private Set<Object> crashingObjects = Collections.newSetFromMap(new IdentityHashMap<>());

    /**
     * Static factory utility method to handle the extraction of the values from the blueprint.
     *
     * @param blueprint The blueprint to create an instance for.
     * @return The renderer.
     */
    public static BlueprintRenderer buildRendererForBlueprint(final Blueprint blueprint)
    {
        final BlueprintBlockAccess blockAccess = new BlueprintBlockAccess(blueprint);
        return new BlueprintRenderer(blockAccess);
    }

    private BlueprintRenderer(final BlueprintBlockAccess blockAccess)
    {
        this.blockAccess = blockAccess;
    }

    /**
     * Updates blueprint reference if it has same hash.
     *
     * @param previewData blueprint and context from active structure
     */
    public void updateBlueprint(final BlueprintPreviewData previewData)
    {
        if (blockAccess.getLevelSource() != previewData.getBlueprint() && blockAccess.getLevelSource().hashCode() == previewData.getBlueprint().hashCode())
        {
            blockAccess.setLevelSource(previewData.getBlueprint());
        }
    }

    private void init(final BlueprintPreviewData previewData, final Map<Object, Exception> suppressedExceptions)
    {
        final Blueprint blueprint = previewData.getBlueprint();
        final Minecraft mc = Minecraft.getInstance();
        final BlockStateModelSet modelSet = mc.getModelManager().getBlockStateModelSet();

        final Map<BlockPos, ModelData> teModelData = new HashMap<>();
        final Map<BlockPos, BlockEntity> tileEntitiesMap = BlueprintUtils.instantiateTileEntities(blueprint, blockAccess, teModelData);
        entities = BlueprintUtils.instantiateEntities(blueprint, blockAccess);

        blockAccess.setBlockEntities(tileEntitiesMap);
        blockAccess.setEntities(entities);
        blockAccess.setSolidSubstitutionOverride(previewData.getSolidSubstitutionOverride());
        blockAccess.setRenderBlocksNiceOverride(previewData.getRenderBlocksNice());

        final ModelBlockRenderer blockRenderer = new ModelBlockRenderer(mc.options.ambientOcclusion().get(), true, mc.getBlockColors());
        final BlockAndTintGetter getter = new Getter(blockAccess);
        final List<RecordedQuad> recorded = new ArrayList<>();
        final BlockQuadOutput output = (x, y, z, quad, instance) -> recorded.add(new RecordedQuad(x, y, z, quad, instance));

        for (final BlockInfo blockInfo : blueprint.getBlockInfoAsList())
        {
            final BlockPos blockPos = blockInfo.getPos();
            BlockState state = blockInfo.getState();
            // specially handle blockTagSub here cuz of block entity changes
            if (previewData.getRenderBlocksNice() && state.getBlock() == ModBlocks.blockTagSubstitution.get())
            {
                if (tileEntitiesMap.remove(blockPos) instanceof final BlockEntityTagSubstitution tagTE)
                {
                    final CapturedBlock replacement = tagTE.getReplacement();
                    state = replacement.blockState();

                    replacement.serializedBE().map(tag -> BlockEntity.loadStatic(blockPos, replacement.blockState(), tag, blueprint.getRegistryAccess())).ifPresent(newBe -> {
                        newBe.setLevel(blockAccess);
                        tileEntitiesMap.put(blockPos, newBe);
                    });
                }
                else
                {
                    state = Blocks.AIR.defaultBlockState();
                }
            }
            else
            {
                state = blockAccess.prepareBlockStateForRendering(state, blockPos);
            }

            try
            {
                if (state.getRenderShape() == RenderShape.MODEL)
                {
                    blockRenderer.tesselateBlock(output,
                        blockPos.getX(),
                        blockPos.getY(),
                        blockPos.getZ(),
                        getter,
                        blockPos,
                        state,
                        modelSet.get(state),
                        state.getSeed(blockPos));
                }
            }
            catch (final Exception e)
            {
                suppressedExceptions.put(blockInfo, e);
            }
        }

        blockAccess.setSolidSubstitutionOverride(null);
        blockAccess.setRenderBlocksNiceOverride(Structurize.getConfig().getClient().renderPlaceholdersNice.get());

        quads = recorded;
        tileEntities = new ArrayList<>(tileEntitiesMap.values());
    }

    /**
     * Draws structure into world.
     */
    public void draw(final BlueprintPreviewData previewData, final BlockPos pos, final RenderLevelStageEvent ctx)
    {
        // we've crashed hard before, full skip
        if (crashingObjects == null)
        {
            return;
        }

        try
        {
            final Map<Object, Exception> suppressedExceptions = drawUnsafe(previewData, pos, ctx);
            if (!suppressedExceptions.isEmpty())
            {
                if (!hasWarnedExceptions)
                {
                    hasWarnedExceptions = true;
                    Minecraft.getInstance().player.sendSystemMessage(Component.translatable("structurize.preview_renderer.exception"));
                }

                for (final Map.Entry<Object, Exception> e : suppressedExceptions.entrySet())
                {
                    if (crashingObjects.add(e.getKey()))
                    {
                        LOGGER.error("", e.getValue());
                    }
                }
            }
        }
        catch (final Exception e)
        {
            printCrashReport(CrashReport.forThrowable(e, "Fatal exception, cannot render"), previewData);

            crashingObjects = null;
            Minecraft.getInstance().player.sendSystemMessage(
                Component.translatable("structurize.preview_renderer.cannot_render", previewData.getBlueprint().getName()));
        }
    }

    private static void printCrashReport(final CrashReport report, final BlueprintPreviewData previewData)
    {
        previewData.getBlueprint().describeSelfInCrashReport(report.addCategory("Blueprint"));
        LOGGER.error(report.getFriendlyReport(new ReportType("Problem during blueprint rendering", ReportType.TEST.nuggets())));
    }

    /**
     * Draws structure into world.
     *
     * @return suppressed exceptions
     */
    public Map<Object, Exception> drawUnsafe(final BlueprintPreviewData previewData, final BlockPos pos, final RenderLevelStageEvent ctx)
    {
        final Minecraft mc = Minecraft.getInstance();
        final Camera camera = mc.gameRenderer.getMainCamera();
        final BlockPos anchorPos = pos.subtract(previewData.getBlueprint().getPrimaryBlockOffset());

        // cull entire rendering
        if (!camera.getCullFrustum().isVisible(previewData.getBlueprint().getAABB().move(anchorPos)))
        {
            return Map.of();
        }

        final Map<Object, Exception> suppressedExceptions = new IdentityHashMap<>();
        final ProfilerFiller profiler = Profiler.get();

        profiler.push("struct_render_init");

        // make sure instances are synced
        updateBlueprint(previewData);
        blockAccess.setWorldPos(anchorPos);

        // init
        if (quads == null)
        {
            init(previewData, suppressedExceptions);
        }

        profiler.popPush("struct_render_blocks");
        final Vec3 root = Vec3.atLowerCornerOf(anchorPos).subtract(camera.position());

        float alpha = Structurize.getConfig().getClient().rendererTransparency.get().floatValue();
        if (previewData.getOverridePreviewTransparency() != -1)
        {
            alpha = Mth.clamp(previewData.getOverridePreviewTransparency(), 0, 1);
        }
        final boolean translucent = alpha >= 0 && alpha <= TransparencyHack.THRESHOLD;
        final int alphaColor = ARGB.white(alpha);

        final MultiBufferSource.BufferSource bufferSource = mc.renderBuffers().bufferSource();
        final PoseStack poseStack = new PoseStack();
        poseStack.translate(root.x, root.y, root.z);
        final QuadInstance instance = new QuadInstance();
        for (final RecordedQuad recorded : quads)
        {
            poseStack.pushPose();
            poseStack.translate(recorded.x, recorded.y, recorded.z);
            for (int i = 0; i < 4; i++)
            {
                instance.setColor(i, translucent ? ARGB.multiply(recorded.colors[i], alphaColor) : recorded.colors[i]);
                instance.setLightCoords(i, recorded.lights[i]);
            }
            instance.setOverlayCoords(recorded.overlay);
            final RenderType type = translucent ? RenderTypes.translucentMovingBlock() : switch (recorded.quad.materialInfo().layer())
            {
                case SOLID -> RenderTypes.solidMovingBlock();
                case CUTOUT -> RenderTypes.cutoutMovingBlock();
                case TRANSLUCENT -> RenderTypes.translucentMovingBlock();
            };
            bufferSource.getBuffer(type).putBakedQuad(poseStack.last(), recorded.quad, instance);
            poseStack.popPose();
        }
        bufferSource.endBatch(RenderTypes.solidMovingBlock());
        bufferSource.endBatch(RenderTypes.cutoutMovingBlock());
        bufferSource.endBatch(RenderTypes.translucentMovingBlock());

        profiler.pop();

        return suppressedExceptions;
    }

    @Override
    public void close()
    {
        quads = null;
    }

    /**
     * The preview used a GL blend constant for transparency, 26.1 uses the translucent moving block layer instead,
     * so this only carries the threshold.
     */
    public static class TransparencyHack
    {
        public static final float THRESHOLD = 0.99f;

        public static void apply(final float overrideValue)
        {
        }

        public static void reset()
        {
        }
    }

    private record RecordedQuad(float x, float y, float z, BakedQuad quad, int[] colors, int[] lights, int overlay)
    {
        RecordedQuad(final float x, final float y, final float z, final BakedQuad quad, final QuadInstance instance)
        {
            this(x, y, z, quad,
                new int[] {instance.getColor(0), instance.getColor(1), instance.getColor(2), instance.getColor(3)},
                new int[] {instance.getLightCoords(0), instance.getLightCoords(1), instance.getLightCoords(2), instance.getLightCoords(3)},
                instance.overlayCoords());
        }
    }

    private record Getter(BlueprintBlockAccess level) implements BlockAndTintGetter
    {
        @Override
        public CardinalLighting cardinalLighting()
        {
            return CardinalLighting.DEFAULT;
        }

        @Override
        public int getBlockTint(final BlockPos pos, final ColorResolver color)
        {
            final BlockPos real = level.getWorldPos().offset(pos);
            return color.getColor(level.getBiome(pos).value(), real.getX(), real.getZ());
        }

        @Override
        public LevelLightEngine getLightEngine()
        {
            return level.getLightEngine();
        }

        @Override
        public BlockEntity getBlockEntity(final BlockPos pos)
        {
            return level.getBlockEntity(pos);
        }

        @Override
        public BlockState getBlockState(final BlockPos pos)
        {
            return level.getBlockState(pos);
        }

        @Override
        public FluidState getFluidState(final BlockPos pos)
        {
            return level.getFluidState(pos);
        }

        @Override
        public int getHeight()
        {
            return level.getHeight();
        }

        @Override
        public int getMinY()
        {
            return level.getMinY();
        }
    }
}
