package com.ldtteam.structurize.items;

import com.ldtteam.structurize.api.RegistryIds;
import com.ldtteam.structurize.api.constants.Constants;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import java.util.function.Supplier;

/**
 * Class to register items to Structurize
 */
public final class ModItems
{
    private ModItems() { /* prevent construction */ }

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(Constants.MOD_ID);

    /*
     *  Items
     */

    public static final DeferredItem<ItemBuildTool> buildTool;
    public static final DeferredItem<ItemShapeTool> shapeTool;
    public static final DeferredItem<ItemScanTool>  scanTool;
    public static final DeferredItem<ItemTagTool>   tagTool;
    public static final DeferredItem<ItemCaliper>  caliper;
    public static final DeferredItem<ItemTagSubstitution> blockTagSubstitution;

    static
    {
        buildTool = ITEMS.register("sceptergold", id -> RegistryIds.item(id, ItemBuildTool::new));
        shapeTool = ITEMS.register("shapetool", id -> RegistryIds.item(id, ItemShapeTool::new));
        scanTool  = ITEMS.register("sceptersteel", id -> RegistryIds.item(id, ItemScanTool::new));
        tagTool   = ITEMS.register("sceptertag", id -> RegistryIds.item(id, ItemTagTool::new));
        caliper   = ITEMS.register("caliper", id -> RegistryIds.item(id, ItemCaliper::new));
        blockTagSubstitution = ITEMS.register("blockTagSubstitution".toLowerCase(), id -> RegistryIds.item(id, ItemTagSubstitution::new));
    }
}
