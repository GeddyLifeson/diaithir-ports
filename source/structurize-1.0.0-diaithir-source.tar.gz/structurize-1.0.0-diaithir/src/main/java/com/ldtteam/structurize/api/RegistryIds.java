package com.ldtteam.structurize.api;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;

import java.util.function.Supplier;

/**
 * Since 1.21.2 block and item properties need their registry id before the block or item is built. Blocks and items that
 * build their own properties in their constructors get it from here: {@link #block} and {@link #item} remember which id is
 * being registered and {@link #withId} stamps it on. Registry suppliers run one at a time on the registering thread.
 * Same approach as McJtyLib's RegistryIds (MIT).
 */
public final class RegistryIds
{
    private static ResourceKey<Block> block;
    private static ResourceKey<Item>  item;

    private RegistryIds()
    {
    }

    public static <T extends Block> T block(final Identifier id, final Supplier<T> supplier)
    {
        block = ResourceKey.create(Registries.BLOCK, id);
        try
        {
            return supplier.get();
        }
        finally
        {
            block = null;
        }
    }

    public static <T extends Item> T item(final Identifier id, final Supplier<T> supplier)
    {
        item = ResourceKey.create(Registries.ITEM, id);
        try
        {
            return supplier.get();
        }
        finally
        {
            item = null;
        }
    }

    public static BlockBehaviour.Properties withId(final BlockBehaviour.Properties properties)
    {
        return block == null ? properties : properties.setId(block);
    }

    /** An item named like a block is that block's item and keeps the block's name ({@code block.<mod>.<name>}). */
    public static Item.Properties withId(final Item.Properties properties)
    {
        if (item == null)
        {
            return properties;
        }
        properties.setId(item);
        return BuiltInRegistries.BLOCK.containsKey(item.identifier()) ? properties.useBlockDescriptionPrefix() : properties;
    }
}
