package com.ldtteam.structurize.api;

/**
 * Type of shapes our tool supports.
 */
public enum Shape
{
    CUBE,
    SPHERE,
    HALF_SPHERE,
    BOWL,
    WAVE,
    WAVE_3D,
    DIAMOND,
    PYRAMID,
    UPSIDE_DOWN_PYRAMID,
    CYLINDER,
    CONE
    //RANDOM
}
