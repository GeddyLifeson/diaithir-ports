package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;

class SliceCacheTest {
   @Test
   void loadsEachSliceOnceAndSlowSliceDoesNotBlockOthers() throws Exception {
      SliceCache<String> cache = new SliceCache<>();
      AtomicInteger loads = new AtomicInteger();
      CountDownLatch release = new CountDownLatch(1);
      CountDownLatch started = new CountDownLatch(1);
      Thread slow = new Thread(() -> cache.get(1, k -> {
         started.countDown();
         try {
            release.await();
         } catch (InterruptedException e) {
            throw new IllegalStateException(e);
         }
         loads.incrementAndGet();
         return "slow";
      }));
      slow.start();
      assertTrue(started.await(5, java.util.concurrent.TimeUnit.SECONDS));
      // keys 17 and 33 share a ConcurrentHashMap bin with 1 at the default table size; they must not wait for slice 1
      assertEquals("a", cache.get(17, k -> "a"));
      assertEquals("b", cache.get(33, k -> "b"));
      release.countDown();
      slow.join();
      assertEquals("slow", cache.get(1, k -> "again"));
      assertEquals(1, loads.get());
   }

   @Test
   void failedLoadIsRetried() {
      SliceCache<String> cache = new SliceCache<>();
      assertThrows(IllegalStateException.class, () -> cache.get(2, k -> {
         throw new IllegalStateException("boom");
      }));
      assertEquals("ok", cache.get(2, k -> "ok"));
   }
}
