package com.yucareux.tellus.era;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.FutureTask;
import java.util.function.IntFunction;

/**
 * Time-slice raster cache that decodes each slice once without holding a ConcurrentHashMap bin lock.
 * ConcurrentHashMap.computeIfAbsent keeps the bin reserved for the whole PNG decode, which stalled the server thread and every
 * chunk thread that touched another slice in the same bin; here only callers of the same slice wait, on that slice's own task.
 */
final class SliceCache<V> {
   private final ConcurrentHashMap<Integer, FutureTask<V>> tasks = new ConcurrentHashMap<>();

   V get(int ka, IntFunction<V> loader) {
      FutureTask<V> task = this.tasks.get(ka);
      if (task == null) {
         FutureTask<V> mine = new FutureTask<>(() -> loader.apply(ka));
         task = this.tasks.putIfAbsent(ka, mine);
         if (task == null) {
            task = mine;
            mine.run();
         }
      }
      try {
         return task.get();
      } catch (InterruptedException e) {
         Thread.currentThread().interrupt();
         throw new IllegalStateException("interrupted loading time slice " + ka, e);
      } catch (java.util.concurrent.ExecutionException e) {
         this.tasks.remove(ka, task);
         Throwable c = e.getCause();
         if (c instanceof RuntimeException r) {
            throw r;
         }
         throw new IllegalStateException("cannot load time slice " + ka, c);
      }
   }
}
