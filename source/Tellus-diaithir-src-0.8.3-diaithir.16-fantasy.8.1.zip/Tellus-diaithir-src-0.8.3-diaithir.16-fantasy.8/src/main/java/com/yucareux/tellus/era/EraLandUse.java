package com.yucareux.tellus.era;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;

/**
 * Woodland people have cleared, by date. landuse_<ka>ka.png (10 to 0 ka, 4320 x 2160, 5 arcminutes, lon -180, lat 90) holds the
 * share of woodland lost at that date, 0 to 255 for 0 to 1, from the HYDE 3.2.1 anthromes (Klein Goldewijk et al. 2017, ESSD 9:927,
 * doi 10.17026/DANS-25G-GEZ3, CC0; builder world/earth/biome/build_landuse_slices.py in the DiaithirRPG repo). A patch of forest
 * becomes open ground in that share of patches. Before 10 ka, and where there is no raster, nothing is cleared.
 */
public final class EraLandUse {
   private static final int WIDTH = 4320, HEIGHT = 2160;
   private static final EraLandUse NONE = new EraLandUse(new byte[0]);
   private static final SliceCache<EraLandUse> SLICES = new SliceCache<>();
   private static final SliceCache<EraLandUse> CROPS = new SliceCache<>();
   private static final int TROPICAL_GRASSLAND = 19, TEMPERATE_GRASSLAND = 20;

   private final byte[] share;

   EraLandUse(byte[] share) {
      this.share = share;
   }

   public static EraLandUse slice(int ka) {
      return load(SLICES, "landuse_", ka);
   }

   /** Cropland and village cells (1.0 where HYDE has them) at a slice; the farmland catch-up reads it. */
   public static EraLandUse crops(int ka) {
      return load(CROPS, "cropland_", ka);
   }

   private static EraLandUse load(SliceCache<EraLandUse> cache, String prefix, int ka) {
      if (ka < 0 || ka > 10) {
         return NONE;
      }
      return cache.get(ka, k -> {
         try (InputStream in = EraLandUse.class.getResourceAsStream("/data/tellus/diaithir/" + prefix + k + "ka.png")) {
            if (in == null) {
               return NONE;
            }
            BufferedImage img = ImageIO.read(in);
            if (img.getWidth() != WIDTH || img.getHeight() != HEIGHT) {
               throw new IllegalStateException("land-use raster " + k + " ka is " + img.getWidth() + " x " + img.getHeight());
            }
            int[] all = img.getRaster().getSamples(0, 0, WIDTH, HEIGHT, 0, (int[]) null);
            byte[] b = new byte[all.length];
            for (int i = 0; i < all.length; i++) {
               b[i] = (byte) all[i];
            }
            return new EraLandUse(b);
         } catch (IOException e) {
            throw new IllegalStateException("land-use slice " + k + " ka unreadable", e);
         }
      });
   }

   /** Share (0 to 1) of woodland cleared at (lat, lon). */
   public double shareAt(double lat, double lon) {
      if (this.share.length == 0 || Double.isNaN(lat) || Double.isNaN(lon)) {
         return 0.0;
      }
      int row = (int) Math.floor((90.0 - lat) / 180.0 * HEIGHT);
      if (row < 0 || row >= HEIGHT) {
         return 0.0;
      }
      int col = Math.floorMod((int) Math.floor((lon + 180.0) / 360.0 * WIDTH), WIDTH);
      return (this.share[row * WIDTH + col] & 0xFF) / 255.0;
   }

   /** The BIOME4 class a patch reads once people have cleared it: open ground for forest classes, the class itself otherwise. */
   public static int clear(int cls, double lat, double lon, int ka, long patchHash) {
      int open = openGround(cls);
      if (open == cls) {
         return cls;
      }
      double unit = ((patchHash >>> 8) & 0xFFFFFF) / (double) 0x1000000;
      return unit < slice(ka).shareAt(lat, lon) ? open : cls;
   }

   static int openGround(int cls) {
      if (cls >= 1 && cls <= 3) {
         return TROPICAL_GRASSLAND;
      }
      if (cls >= 4 && cls <= 9 || cls == 15) {
         return TEMPERATE_GRASSLAND;
      }
      return cls;   // boreal forest, woodland already open, and everything that is not forest stays
   }
}
