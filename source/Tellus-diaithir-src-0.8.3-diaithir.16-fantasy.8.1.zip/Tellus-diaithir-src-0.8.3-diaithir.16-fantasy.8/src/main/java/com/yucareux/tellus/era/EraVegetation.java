package com.yucareux.tellus.era;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashSet;
import java.util.Set;
import javax.imageio.ImageIO;

/**
 * Age I vegetation: the BIOME4 class of the 15 ka slice of Beyer, Krapp & Manica 2020 (Sci. Data 7:236, CC BY 4.0), 0.5 degree
 * grid (see world/earth/biome/build_biome4_raster.py in the DiaithirRPG repo), and the table that maps each class to ESA
 * WorldCover classes and Minecraft biomes. Class 0 means no data (south of 59.75 S): Tellus keeps its own cover there.
 */
public final class EraVegetation {
   private static final String DIR = "/data/tellus/diaithir/";
   private static volatile EraVegetation shared;
   private static final SliceCache<EraVegetation> SLICES = new SliceCache<>();

   /** Per BIOME4 class: the cover it implies, the ESA classes it agrees with (today's cover kept), and the biome with and without trees. */
   record Entry(String name, int cover, int[] agrees, String wooded, String open) {
      boolean agreesWith(int esa) {
         for (int a : this.agrees) {
            if (a == esa) {
               return true;
            }
         }
         return false;
      }
   }

   private static final int TREE = 10, SHRUB = 20, GRASS = 30, BARE = 60, WETLAND = 90, MANGROVE = 95, MOSS = 100;
   static final Entry[] TABLE = {
      null,                                                                                                  // 0 no data
      new Entry("Tropical evergreen forest", TREE, new int[]{TREE, WETLAND, MANGROVE}, "jungle", "sparse_jungle"),
      new Entry("Tropical semi-deciduous forest", TREE, new int[]{TREE, SHRUB, WETLAND, MANGROVE}, "jungle", "sparse_jungle"),
      new Entry("Tropical deciduous forest/woodland", TREE, new int[]{TREE, SHRUB, GRASS}, "sparse_jungle", "savanna"),
      new Entry("Temperate deciduous forest", TREE, new int[]{TREE, WETLAND}, "forest", "plains"),
      new Entry("Temperate conifer forest", TREE, new int[]{TREE}, "taiga", "plains"),
      new Entry("Warm mixed forest", TREE, new int[]{TREE, WETLAND}, "dark_forest", "plains"),
      new Entry("Cool mixed forest", TREE, new int[]{TREE, WETLAND}, "forest", "plains"),
      new Entry("Cool conifer forest", TREE, new int[]{TREE, WETLAND}, "taiga", "meadow"),
      new Entry("Cold mixed forest", TREE, new int[]{TREE, SHRUB, WETLAND}, "birch_forest", "meadow"),
      new Entry("Evergreen taiga/montane forest", TREE, new int[]{TREE, SHRUB, WETLAND}, "old_growth_spruce_taiga", "meadow"),
      new Entry("Deciduous taiga/montane forest", TREE, new int[]{TREE, SHRUB, WETLAND}, "old_growth_pine_taiga", "meadow"),
      new Entry("Tropical savanna", GRASS, new int[]{GRASS, SHRUB, TREE}, "savanna", "savanna"),
      new Entry("Tropical xerophytic shrubland", SHRUB, new int[]{SHRUB, GRASS, BARE}, "savanna_plateau", "savanna"),
      new Entry("Temperate xerophytic shrubland", SHRUB, new int[]{SHRUB, GRASS, BARE}, "windswept_savanna", "windswept_hills"),
      new Entry("Temperate sclerophyll woodland", SHRUB, new int[]{TREE, SHRUB, GRASS}, "forest", "plains"),
      new Entry("Temperate broadleaved savanna", GRASS, new int[]{GRASS, TREE, SHRUB}, "savanna", "plains"),
      new Entry("Open conifer woodland", SHRUB, new int[]{TREE, SHRUB, GRASS}, "taiga", "windswept_hills"),
      new Entry("Boreal parkland", GRASS, new int[]{TREE, SHRUB, GRASS, WETLAND}, "taiga", "plains"),
      new Entry("Tropical grassland", GRASS, new int[]{GRASS, SHRUB}, "savanna", "savanna"),
      new Entry("Temperate grassland", GRASS, new int[]{GRASS, SHRUB}, "plains", "plains"),
      new Entry("Desert", BARE, new int[]{BARE, SHRUB}, "desert", "desert"),
      new Entry("Steppe tundra", GRASS, new int[]{GRASS, SHRUB, BARE, MOSS}, "taiga", "plains"),
      new Entry("Shrub tundra", SHRUB, new int[]{SHRUB, GRASS, MOSS, WETLAND, BARE}, "taiga", "meadow"),
      new Entry("Dwarf shrub tundra", MOSS, new int[]{MOSS, SHRUB, GRASS, BARE, WETLAND}, "taiga", "meadow"),
      new Entry("Prostrate shrub tundra", MOSS, new int[]{MOSS, BARE, GRASS, SHRUB}, "meadow", "meadow"),
      new Entry("Cushion forb lichen moss tundra", MOSS, new int[]{MOSS, BARE}, "windswept_gravelly_hills", "windswept_gravelly_hills"),
      new Entry("Barren", BARE, new int[]{BARE, MOSS}, "stony_peaks", "stony_peaks"),
   };

   private final double latN, lonW, res;
   private final int width, height;
   private final byte[] classes;

   EraVegetation(JsonObject meta, BufferedImage img) {
      this.latN = meta.get("lat_n").getAsDouble();
      this.lonW = meta.get("lon_w").getAsDouble();
      this.res = meta.get("res_deg").getAsDouble();
      this.width = meta.get("width").getAsInt();
      this.height = meta.get("height").getAsInt();
      if (img.getWidth() != this.width || img.getHeight() != this.height) {
         throw new IllegalStateException("biome raster does not match biome4_meta.json");
      }
      int[] all = img.getRaster().getSamples(0, 0, this.width, this.height, 0, (int[]) null);
      this.classes = new byte[all.length];
      for (int k = 0; k < all.length; k++) {
         if (all[k] < 0 || all[k] >= TABLE.length) {
            throw new IllegalStateException("unknown BIOME4 class " + all[k]);
         }
         this.classes[k] = (byte) all[k];
      }
   }

   public static EraVegetation loadFromClasspath() throws IOException {
      try (InputStream mi = EraVegetation.class.getResourceAsStream(DIR + "biome4_meta.json");
           InputStream ii = EraVegetation.class.getResourceAsStream(DIR + "biome4_15ka.png")) {
         if (mi == null || ii == null) {
            throw new IOException("vegetation resources missing under " + DIR);
         }
         JsonObject meta = JsonParser.parseReader(new InputStreamReader(mi, StandardCharsets.UTF_8)).getAsJsonObject();
         return new EraVegetation(meta, ImageIO.read(ii));
      }
   }

   public static EraVegetation shared() {
      EraVegetation s = shared;
      if (s == null) {
         synchronized (EraVegetation.class) {
            if (shared == null) {
               try {
                  shared = loadFromClasspath();
               } catch (IOException e) {
                  throw new IllegalStateException("cannot load Diaithir vegetation", e);
               }
            }
            s = shared;
         }
      }
      return s;
   }

   /** The raster of a time slice in ka (biome4_<ka>ka.png, same geometry as the 15 ka one); 15 is the shared one. */
   public static EraVegetation slice(int ka) {
      if (ka == 15) {
         return shared();
      }
      return SLICES.get(ka, k -> {
         try (InputStream mi = EraVegetation.class.getResourceAsStream(DIR + "biome4_meta.json");
              InputStream ii = EraVegetation.class.getResourceAsStream(DIR + "biome4_" + k + "ka.png")) {
            if (mi == null || ii == null) {
               throw new IOException("vegetation slice " + k + " ka missing under " + DIR);
            }
            return new EraVegetation(JsonParser.parseReader(new InputStreamReader(mi, StandardCharsets.UTF_8)).getAsJsonObject(), ImageIO.read(ii));
         } catch (IOException e) {
            throw new IllegalStateException("cannot load Diaithir vegetation slice " + k, e);
         }
      });
   }

   /** BIOME4 class of the cell holding (lat, lon), 0 for no data or NaN input. Longitude wraps. */
   public int classAt(double lat, double lon) {
      if (Double.isNaN(lat) || Double.isNaN(lon)) {
         return 0;
      }
      int row = (int) Math.floor((this.latN - lat) / this.res);
      if (row < 0 || row >= this.height) {
         return 0;
      }
      int col = Math.floorMod((int) Math.floor((lon - this.lonW) / this.res), this.width);
      return this.classes[row * this.width + col];
   }

   static Entry entry(int biome4) {
      return biome4 > 0 && biome4 < TABLE.length ? TABLE[biome4] : null;
   }

   /** Every Minecraft biome id the table can return. */
   public static Set<String> biomeIds() {
      Set<String> ids = new LinkedHashSet<>();
      for (Entry e : TABLE) {
         if (e != null) {
            ids.add(e.wooded());
            ids.add(e.open());
         }
      }
      ids.addAll(EraPalette.shared().biomeIds());
      return ids;
   }
}
