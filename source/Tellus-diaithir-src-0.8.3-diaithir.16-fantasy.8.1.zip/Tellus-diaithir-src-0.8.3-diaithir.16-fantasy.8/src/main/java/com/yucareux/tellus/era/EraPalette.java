package com.yucareux.tellus.era;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.imageio.ImageIO;

/**
 * Age I biome palette: picks one of the pack's biomes (vanilla, Biomes O' Plenty, Regions Unexplored) for a land column from its
 * BIOME4 class, cover, the 15 ka climate (Beyer, Krapp &amp; Manica 2020, CC BY 4.0), altitude belt, relief, coast and place. The rule table is
 * data/tellus/diaithir/biome_rules.json, written by world/earth/biome/palette/rules_src.py in the DiaithirRPG repo, which also holds the
 * Python mirror (palette.py) that the golden-vector test checks this class against.
 */
public final class EraPalette {
   private static final String DIR = "/data/tellus/diaithir/";
   private static final long M = 0xFFFFFFFFFFFFFFFFL;
   private static final int TREE = 10, WET = 90, MANGROVE = 95;
   private static volatile EraPalette shared;
   private static volatile Predicate<String> available = id -> true;

   /** Column inputs. relief and coast are asked for only when a candidate rule has such a condition. */
   public interface Column {
      double relief();

      boolean coast();
   }

   private static final class Rule {
      int index;
      String biome, fallback;
      double weight;
      double patchScale = -1.0, patchFreq;
      int[] cls, cover;
      Boolean wood, coast;
      int beltLo = 0, beltHi = 2;
      double[][] range = new double[5][];      // T, C, W, P, D
      double[] relief, lat;
      double[][] box;

      boolean isPatch() {
         return this.patchScale > 0.0;
      }
   }

   /** A mythic site: ring and optional core discs in ground km around a point; tags select cave overlays. */
   private static final class Site {
      double lat, lon, r, coreR;
      String biome, fallback, coreBiome, coreFallback;
      String[] tags = new String[0];
      double cosLat;

      boolean has(String tag) {
         for (String t : this.tags) {
            if (t.equals(tag)) {
               return true;
            }
         }
         return false;
      }
   }

   /** A cave rule: biome in a depth band, a Voronoi patch field, a rare free-standing chance and an optional site tag that raises it. */
   private static final class CaveRule {
      String biome, fallback, tag;
      double depthLo, depthHi, scale, freq, tagFreq;
      String[] surf;
   }

   public static final int SITE_BASE = 100000;
   private static final double KM_PER_DEG = 111.19;
   private static final String[] CLIMATE_KEYS = {"T", "C", "W", "P", "D"};
   private final List<Site> sites = new ArrayList<>();
   private final List<CaveRule> caves = new ArrayList<>();
   private final double baseScale;
   private final List<Rule> rules = new ArrayList<>();
   private final List<Rule> rivers = new ArrayList<>();
   private final List<Double> riverFreq = new ArrayList<>();
   private final List<Rule> patches = new ArrayList<>();
   private final List<Rule>[] baseByClass;
   private final Set<String> biomeIds = new LinkedHashSet<>();
   private final byte[] clim;       // width*height*5 : T, C, W, P(A), D
   private final byte[] meanElev;   // width*height : (mean land elevation today + 500) / 32
   private final int width, height, dataRows;
   private final double latN, lonW, res;

   @SuppressWarnings("unchecked")
   EraPalette(JsonObject spec, JsonObject meta, BufferedImage a, BufferedImage d, BufferedImage e) {
      this.baseScale = spec.get("base_scale").getAsDouble();
      this.baseByClass = new List[40];
      for (int i = 0; i < this.baseByClass.length; i++) {
         this.baseByClass[i] = new ArrayList<>();
      }
      for (JsonElement el : spec.getAsJsonArray("rules")) {
         Rule r = parse(el.getAsJsonObject());
         r.index = this.rules.size();
         this.rules.add(r);
         this.biomeIds.add(r.biome);
         this.biomeIds.add(r.fallback);
         if (r.isPatch()) {
            this.patches.add(r);
         } else {
            int[] cs = r.cls;
            if (cs == null) {
               for (List<Rule> l : this.baseByClass) {
                  l.add(r);
               }
            } else {
               for (int c : cs) {
                  this.baseByClass[c].add(r);
               }
            }
         }
      }
      if (spec.has("rivers")) {
         for (JsonElement el : spec.getAsJsonArray("rivers")) {
            Rule r = parse(withWeight(el.getAsJsonObject()));
            this.rivers.add(r);
            this.riverFreq.add(el.getAsJsonObject().get("freq").getAsDouble());
            this.biomeIds.add(r.biome);
            this.biomeIds.add(r.fallback);
         }
      }
      if (spec.has("sites")) {
         for (JsonElement el : spec.getAsJsonArray("sites")) {
            JsonObject o = el.getAsJsonObject();
            Site st = new Site();
            st.lat = o.get("lat").getAsDouble();
            st.lon = o.get("lon").getAsDouble();
            st.r = o.get("r").getAsDouble();
            st.biome = o.get("biome").getAsString();
            st.fallback = o.get("fb").getAsString();
            st.cosLat = Math.cos(Math.toRadians(st.lat));
            this.biomeIds.add(st.biome);
            this.biomeIds.add(st.fallback);
            if (o.has("core")) {
               JsonObject c = o.getAsJsonObject("core");
               st.coreR = c.get("r").getAsDouble();
               st.coreBiome = c.get("biome").getAsString();
               st.coreFallback = c.get("fb").getAsString();
               this.biomeIds.add(st.coreBiome);
               this.biomeIds.add(st.coreFallback);
            }
            if (o.has("tags")) {
               JsonArray ts = o.getAsJsonArray("tags");
               st.tags = new String[ts.size()];
               for (int i = 0; i < st.tags.length; i++) {
                  st.tags[i] = ts.get(i).getAsString();
               }
            }
            this.sites.add(st);
         }
      }
      if (spec.has("caves")) {
         for (JsonElement el : spec.getAsJsonArray("caves")) {
            JsonObject o = el.getAsJsonObject();
            CaveRule c = new CaveRule();
            c.biome = o.get("biome").getAsString();
            c.fallback = o.get("fb").getAsString();
            c.depthLo = o.getAsJsonArray("depth").get(0).getAsDouble();
            c.depthHi = o.getAsJsonArray("depth").get(1).getAsDouble();
            c.scale = o.get("scale").getAsDouble();
            c.freq = o.get("freq").getAsDouble();
            if (o.has("tag")) {
               c.tag = o.get("tag").getAsString();
               c.tagFreq = o.get("tag_freq").getAsDouble();
            }
            if (o.has("surf")) {
               JsonArray ss = o.getAsJsonArray("surf");
               c.surf = new String[ss.size()];
               for (int i = 0; i < c.surf.length; i++) {
                  c.surf[i] = ss.get(i).getAsString();
               }
            }
            this.biomeIds.add(c.biome);
            this.biomeIds.add(c.fallback);
            this.caves.add(c);
         }
      }
      this.latN = meta.get("lat_n").getAsDouble();
      this.lonW = meta.get("lon_w").getAsDouble();
      this.res = meta.get("res_deg").getAsDouble();
      this.width = meta.get("width").getAsInt();
      this.height = meta.get("height").getAsInt();
      this.dataRows = meta.get("rows_with_data").getAsInt();
      if (a.getWidth() != this.width || a.getHeight() != this.height || d.getWidth() != this.width || d.getHeight() != this.height) {
         throw new IllegalStateException("climate rasters do not match climate15ka_meta.json");
      }
      int n = this.width * this.height;
      int[] sa = new int[n];
      this.clim = packClimate(a, d, this.width, this.height);
      this.meanElev = new byte[n];
      e.getRaster().getSamples(0, 0, this.width, this.height, 0, sa);
      for (int k = 0; k < n; k++) {
         this.meanElev[k] = (byte) sa[k];
      }
   }

   /** The five climate bands (T, C, W, P, D) of a pair of climate rasters, interleaved. */
   private static byte[] packClimate(BufferedImage a, BufferedImage d, int width, int height) {
      int n = width * height;
      byte[] clim = new byte[n * 5];
      int[] sa = new int[n];
      for (int band = 0; band < 4; band++) {
         a.getRaster().getSamples(0, 0, width, height, band, sa);
         for (int k = 0; k < n; k++) {
            clim[k * 5 + (band < 3 ? band : 3)] = (byte) sa[k];
         }
      }
      d.getRaster().getSamples(0, 0, width, height, 0, sa);
      for (int k = 0; k < n; k++) {
         clim[k * 5 + 4] = (byte) sa[k];
      }
      return clim;
   }

   private final SliceCache<byte[]> climSlices = new SliceCache<>();

   /** Climate bands of a time slice in ka (climate<ka>ka_a.png and _d.png, same geometry as the 15 ka pair). */
   private byte[] climateSlice(int ka) {
      if (ka == 15) {
         return this.clim;
      }
      return this.climSlices.get(ka, k -> {
         try (InputStream ai = EraPalette.class.getResourceAsStream(DIR + "climate" + k + "ka_a.png");
              InputStream di = EraPalette.class.getResourceAsStream(DIR + "climate" + k + "ka_d.png")) {
            if (ai == null || di == null) {
               throw new IOException("climate slice " + k + " ka missing under " + DIR);
            }
            return packClimate(ImageIO.read(ai), ImageIO.read(di), this.width, this.height);
         } catch (IOException e) {
            throw new IllegalStateException("cannot load Diaithir climate slice " + k, e);
         }
      });
   }

   private static Rule parse(JsonObject o) {
      Rule r = new Rule();
      r.biome = o.get("biome").getAsString();
      r.fallback = o.get("fb").getAsString();
      r.weight = o.get("w").getAsDouble();
      if (o.has("patch")) {
         r.patchScale = o.getAsJsonArray("patch").get(0).getAsDouble();
         r.patchFreq = o.getAsJsonArray("patch").get(1).getAsDouble();
      }
      if (o.has("cls")) {
         r.cls = ints(o.getAsJsonArray("cls"));
      }
      if (o.has("cover")) {
         r.cover = ints(o.getAsJsonArray("cover"));
      }
      if (o.has("wood")) {
         r.wood = o.get("wood").getAsBoolean();
      }
      if (o.has("coast")) {
         r.coast = o.get("coast").getAsBoolean();
      }
      if (o.has("belt")) {
         r.beltLo = o.getAsJsonArray("belt").get(0).getAsInt();
         r.beltHi = o.getAsJsonArray("belt").get(1).getAsInt();
      }
      for (int i = 0; i < CLIMATE_KEYS.length; i++) {
         if (o.has(CLIMATE_KEYS[i])) {
            r.range[i] = range(o.getAsJsonArray(CLIMATE_KEYS[i]));
         }
      }
      if (o.has("lat")) {
         r.lat = range(o.getAsJsonArray("lat"));
      }
      if (o.has("relief")) {
         r.relief = range(o.getAsJsonArray("relief"));
      }
      if (o.has("box")) {
         JsonArray bs = o.getAsJsonArray("box");
         r.box = new double[bs.size()][];
         for (int i = 0; i < bs.size(); i++) {
            JsonArray b = bs.get(i).getAsJsonArray();
            r.box[i] = new double[]{b.get(0).getAsDouble(), b.get(1).getAsDouble(), b.get(2).getAsDouble(), b.get(3).getAsDouble()};
         }
      }
      return r;
   }

   private static JsonObject withWeight(JsonObject o) {
      if (!o.has("w")) {
         o.addProperty("w", 1.0);
      }
      return o;
   }

   private static int[] ints(JsonArray a) {
      int[] v = new int[a.size()];
      for (int i = 0; i < v.length; i++) {
         v[i] = a.get(i).getAsInt();
      }
      return v;
   }

   private static double[] range(JsonArray a) {
      return new double[]{a.get(0).isJsonNull() ? Double.NEGATIVE_INFINITY : a.get(0).getAsDouble(), a.get(1).isJsonNull() ? Double.POSITIVE_INFINITY : a.get(1).getAsDouble()};
   }

   public static EraPalette loadFromClasspath() throws IOException {
      try (InputStream si = EraPalette.class.getResourceAsStream(DIR + "biome_rules.json");
           InputStream mi = EraPalette.class.getResourceAsStream(DIR + "climate15ka_meta.json");
           InputStream ai = EraPalette.class.getResourceAsStream(DIR + "climate15ka_a.png");
           InputStream di = EraPalette.class.getResourceAsStream(DIR + "climate15ka_d.png");
           InputStream ei = EraPalette.class.getResourceAsStream(DIR + "meanelev_today.png")) {
         if (si == null || mi == null || ai == null || di == null || ei == null) {
            throw new IOException("biome palette resources missing under " + DIR);
         }
         return new EraPalette(JsonParser.parseReader(new InputStreamReader(si, StandardCharsets.UTF_8)).getAsJsonObject(),
            JsonParser.parseReader(new InputStreamReader(mi, StandardCharsets.UTF_8)).getAsJsonObject(), ImageIO.read(ai), ImageIO.read(di), ImageIO.read(ei));
      }
   }

   public static EraPalette shared() {
      EraPalette s = shared;
      if (s == null) {
         synchronized (EraPalette.class) {
            if (shared == null) {
               try {
                  shared = loadFromClasspath();
               } catch (IOException e) {
                  throw new IllegalStateException("cannot load Diaithir biome palette", e);
               }
            }
            s = shared;
         }
      }
      return s;
   }

   /** The biome source installs a registry check so a rule whose mod is absent falls back to its vanilla stand-in. */
   public static void setAvailability(Predicate<String> p) {
      available = p == null ? id -> true : p;
   }

   /** Every biome id a rule can return, fallbacks included. */
   public Set<String> biomeIds() {
      return this.biomeIds;
   }

   // ------------------------------------------------------------------ noise (mirrors palette.py)
   private static long mix(long h) {
      h ^= h >>> 30;
      h *= 0xBF58476D1CE4E5B9L;
      h ^= h >>> 27;
      h *= 0x94D049BB133111EBL;
      h ^= h >>> 31;
      return h;
   }

   private static long h2(long ix, long iz, long salt) {
      return mix((ix * 0x9E3779B97F4A7C15L) ^ (iz * 0xC2B2AE3D27D4EB4FL) ^ (salt * 0x165667B19E3779F9L));
   }

   private static double unit(long h) {
      return (h >>> 11) * (1.0 / (1L << 53));
   }

   private static double vnoise(double x, double z, double scale, long salt) {
      double gx = x / scale, gz = z / scale;
      long ix = (long) Math.floor(gx), iz = (long) Math.floor(gz);
      double fx = gx - ix, fz = gz - iz;
      fx = fx * fx * (3.0 - 2.0 * fx);
      fz = fz * fz * (3.0 - 2.0 * fz);
      double a = unit(h2(ix, iz, salt)), b = unit(h2(ix + 1, iz, salt)), c = unit(h2(ix, iz + 1, salt)), d = unit(h2(ix + 1, iz + 1, salt));
      return (a + (b - a) * fx) * (1.0 - fz) + (c + (d - c) * fx) * fz;
   }

   private static double vor(double x, double z, double scale, long salt) {
      double wx = x + (vnoise(x, z, scale * 0.5, salt + 101) - 0.5) * scale * 0.6;
      double wz = z + (vnoise(x, z, scale * 0.5, salt + 202) - 0.5) * scale * 0.6;
      double gx = wx / scale, gz = wz / scale;
      long ix = (long) Math.floor(gx), iz = (long) Math.floor(gz);
      double best = 1e30;
      long bx = 0, bz = 0;
      for (int dz = -1; dz <= 1; dz++) {
         for (int dx = -1; dx <= 1; dx++) {
            long cx = ix + dx, cz = iz + dz;
            double px = cx + 0.15 + 0.7 * unit(h2(cx, cz, salt * 2 + 1));
            double pz = cz + 0.15 + 0.7 * unit(h2(cx, cz, salt * 2 + 2));
            double dd = (px - gx) * (px - gx) + (pz - gz) * (pz - gz);
            if (dd < best) {
               best = dd;
               bx = cx;
               bz = cz;
            }
         }
      }
      return unit(h2(bx, bz, salt * 2 + 3));
   }

   // ------------------------------------------------------------------ climate lookup
   /** 15 ka climate at (lat, lon): T, C, W, P, D; null off the raster or south of its data. */
   public double[] climateAt(double lat, double lon) {
      return this.climateAt(lat, lon, 15);
   }

   /** Climate at (lat, lon) from the time slice of ka. */
   public double[] climateAt(double lat, double lon, int ka) {
      byte[] clim = this.climateSlice(ka);
      int row = (int) Math.floor((this.latN - lat) / this.res);
      if (row < 0 || row >= this.dataRows) {
         return null;
      }
      int col = Math.floorMod((int) Math.floor((lon - this.lonW) / this.res), this.width);
      int o = (row * this.width + col) * 5;
      double pa = clim[o + 3] & 0xFF;
      return new double[]{(clim[o] & 0xFF) / 2.5 - 50.0, (clim[o + 1] & 0xFF) / 2.5 - 80.0, (clim[o + 2] & 0xFF) / 3.8 - 15.0,
         (pa / 3.0) * (pa / 3.0), ((clim[o + 4] & 0xFF) / 6.0) * ((clim[o + 4] & 0xFF) / 6.0)};
   }

   /** Mean land elevation of the 0.5 degree cell holding (lat, lon), today's metres. */
   public double meanElevationToday(double lat, double lon) {
      int row = (int) Math.floor((this.latN - lat) / this.res);
      if (row < 0 || row >= this.height) {
         return 0.0;
      }
      int col = Math.floorMod((int) Math.floor((lon - this.lonW) / this.res), this.width);
      return (this.meanElev[row * this.width + col] & 0xFF) * 32.0 - 500.0;
   }

   // ------------------------------------------------------------------ belts
   private static final double MIN_TREELINE_M = 900.0;

   /** 0 lowland, 1 foothill, 2 montane, 3 subalpine, 4 alpine, by height above the column's climate-cell mean against the latitude's treeline. */
   public static int belt(double dhMeters, double lat) {
      double tl = Math.max(EraMath.age1TreelineMeters(lat), MIN_TREELINE_M);
      double r = dhMeters / tl;
      return r < 0.12 ? 0 : r < 0.4 ? 1 : r < 0.75 ? 2 : r < 1.0 ? 3 : 4;
   }

   // ------------------------------------------------------------------ choice
   private static boolean in(double v, double[] r) {
      return v >= r[0] && v <= r[1];
   }

   private boolean matches(Rule r, int cls, int cover, int belt, double[] cl, double lat, double lon, Column col) {
      boolean wet = cover == WET || cover == MANGROVE;
      if (r.cover == null) {
         if (wet) {
            return false;
         }
      } else {
         boolean ok = false;
         for (int c : r.cover) {
            ok |= c == cover;
         }
         if (!ok) {
            return false;
         }
      }
      if (r.cls != null) {
         boolean ok = false;
         for (int c : r.cls) {
            ok |= c == cls;
         }
         if (!ok) {
            return false;
         }
      }
      if (r.wood != null && r.wood != (cover == TREE)) {
         return false;
      }
      if (belt < r.beltLo || belt > r.beltHi) {
         return false;
      }
      for (int i = 0; i < 5; i++) {
         if (r.range[i] != null && !in(cl[i], r.range[i])) {
            return false;
         }
      }
      if (r.lat != null && !in(Math.abs(lat), r.lat)) {
         return false;
      }
      if (r.relief != null && !in(col.relief(), r.relief)) {
         return false;
      }
      if (r.coast != null && r.coast != col.coast()) {
         return false;
      }
      if (r.box != null) {
         boolean ok = false;
         for (double[] b : r.box) {
            if (lat >= b[0] && lat <= b[1] && lon >= b[2] && lon <= b[3]) {
               ok = true;
               break;
            }
         }
         if (!ok) {
            return false;
         }
      }
      return true;
   }

   private static String resolve(Rule r) {
      return resolve(r.biome, r.fallback);
   }

   private static String resolve(String biome, String fallback) {
      return available.test(biome) ? biome : available.test(fallback) ? fallback : null;
   }

   /** 2 inside the site's core, 1 inside its ring, 0 outside (mirrors palette.py site_hit). */
   private static int siteHit(Site s, double lat, double lon, int i) {
      double dy = (lat - s.lat) * KM_PER_DEG;
      if (Math.abs(dy) > s.r * 1.3) {
         return 0;
      }
      double dl = ((lon - s.lon + 180.0) % 360.0 + 360.0) % 360.0 - 180.0;
      double dx = dl * KM_PER_DEG * s.cosLat;
      double d = Math.hypot(dx, dy);
      if (d > s.r * 1.3) {
         return 0;
      }
      double nx = dx * 200.0, nz = dy * 200.0;
      if (s.coreBiome != null && d < s.coreR * (0.8 + 0.4 * vnoise(nx, nz, Math.max(s.coreR * 100.0, 40.0), 900 + (long) i * 2))) {
         return 2;
      }
      return d < s.r * (0.8 + 0.4 * vnoise(nx, nz, Math.max(s.r * 100.0, 60.0), 901 + (long) i * 2)) ? 1 : 0;
   }

   /** Packed (site index * 2 + hit - 1) of the first site holding the point, or -1. */
   private int siteAt(double lat, double lon) {
      for (int i = 0; i < this.sites.size(); i++) {
         int h = siteHit(this.sites.get(i), lat, lon, i);
         if (h > 0) {
            return i * 2 + h - 1;
         }
      }
      return -1;
   }

   /**
    * Fantasy cave biome at a block, or null for the stock cave policy. depth is blocks under the surface, surface the surface
    * biome id. Mirrors palette.py cave_choose.
    */
   public String caveBiome(double lat, double lon, double x, double y, double z, double depth, String surface) {
      int i = caveRule(lat, lon, x, y, z, depth, surface);
      return i < 0 ? null : resolve(this.caves.get(i).biome, this.caves.get(i).fallback);
   }

   /** Index of the cave rule that chose, or -1 (for tests and the simulator). */
   public int caveRule(double lat, double lon, double x, double y, double z, double depth, String surface) {
      double gy = Math.floor(y / 32.0);
      int site = -2;
      for (int i = 0; i < this.caves.size(); i++) {
         CaveRule r = this.caves.get(i);
         if (depth < r.depthLo || depth > r.depthHi) {
            continue;
         }
         double f = r.freq;
         boolean tagged = false;
         if (r.tag != null) {
            if (site == -2) {
               site = siteAt(lat, lon);
               site = site < 0 ? -1 : site >> 1;
            }
            if (site >= 0 && this.sites.get(site).has(r.tag)) {
               f = r.tagFreq;
               tagged = true;
            }
         }
         if (r.surf != null && !tagged) {
            boolean ok = false;
            for (String k : r.surf) {
               ok |= surface.contains(k);
            }
            if (!ok) {
               continue;
            }
         }
         if (f <= 0.0) {
            continue;
         }
         if (vor(x + gy * 977.0, z + gy * 1319.0, r.scale, 700 + (long) i * 7) < f) {
            return i;
         }
      }
      return -1;
   }

   /** Index of the rule that chose, or -1 (for tests and the simulator); the biome id is {@link #choose}. */
   public int chooseRule(int cls, int cover, double lat, double lon, double[] climate, double dhMeters, double blockX, double blockZ, Column col) {
      if (cls < 0 || cls >= this.baseByClass.length || climate == null) {
         return -1;
      }
      int site = siteAt(lat, lon);
      if (site >= 0) {
         return SITE_BASE + site;
      }
      int belt = belt(dhMeters, lat);
      for (int i = 0; i < this.patches.size(); i++) {
         Rule r = this.patches.get(i);
         if (matches(r, cls, cover, belt, climate, lat, lon, col) && vor(blockX, blockZ, r.patchScale, 13 + (long) r.index * 7) < r.patchFreq) {
            return r.index;
         }
      }
      List<Rule> base = this.baseByClass[cls];
      double total = 0.0;
      List<Rule> cand = new ArrayList<>(8);
      for (Rule r : base) {
         if (matches(r, cls, cover, belt, climate, lat, lon, col)) {
            cand.add(r);
            total += r.weight;
         }
      }
      if (total <= 0.0) {
         return -1;
      }
      double t = vor(blockX, blockZ, this.baseScale, 5) * total;
      double acc = 0.0;
      for (Rule r : cand) {
         acc += r.weight;
         if (t < acc && r.weight > 0.0) {
            return r.index;
         }
      }
      return cand.get(cand.size() - 1).index;
   }

   public String choose(int cls, int cover, double lat, double lon, double[] climate, double dhMeters, double blockX, double blockZ, Column col) {
      int i = chooseRule(cls, cover, lat, lon, climate, dhMeters, blockX, blockZ, col);
      if (i >= SITE_BASE) {
         Site st = this.sites.get((i - SITE_BASE) >> 1);
         return (i - SITE_BASE & 1) == 1 ? resolve(st.coreBiome, st.coreFallback) : resolve(st.biome, st.fallback);
      }
      return i < 0 ? null : resolve(this.rules.get(i));
   }

   /** River biome for a river or lake column at this climate (T, C, W, P, D), or null for the plain river. */
   public String riverBiome(double[] climate, double blockX, double blockZ) {
      if (climate == null) {
         return null;
      }
      for (int i = 0; i < this.rivers.size(); i++) {
         Rule r = this.rivers.get(i);
         boolean ok = true;
         for (int k = 0; k < 5 && ok; k++) {
            ok = r.range[k] == null || in(climate[k], r.range[k]);
         }
         if (ok && vor(blockX, blockZ, 3000.0, 400 + i) < this.riverFreq.get(i)) {
            return resolve(r);
         }
      }
      return null;
   }

   public String ruleBiome(int index) {
      if (index >= SITE_BASE) {
         Site st = this.sites.get((index - SITE_BASE) >> 1);
         return (index - SITE_BASE & 1) == 1 ? st.coreBiome : st.biome;
      }
      return this.rules.get(index).biome;
   }
}
