package com.yucareux.tellus.era;

import com.yucareux.tellus.worldgen.EarthProjection;

/**
 * Per-JVM era state. One world per server JVM; the generator installs its settings at construction.
 * ponytail: a static, not threaded settings, because Tellus' sources are shared singletons. Make it per-generator if two
 * differently-configured Earth worlds ever share one JVM.
 */
public final class EraRuntime {
   public interface ElevationProbe {
      double relativeMeters(double blockX, double blockZ, double worldScale);
   }

   private static volatile EraSettings era = EraSettings.NONE;
   private static volatile ElevationProbe probe;
   private static volatile int yearLc = Integer.MIN_VALUE;

   private EraRuntime() {
   }

   public static void install(EraSettings settings) {
      era = settings == null ? EraSettings.NONE : settings;
   }

   /** Sets the game year (LC) the water level follows; MIN_VALUE (the start-up value) leaves the water at the era's datum. */
   public static void setYear(int lc) {
      if (yearLc != lc) {
         yearVersion.incrementAndGet();
      }
      yearLc = lc;
   }

   private static final java.util.concurrent.atomic.AtomicInteger yearVersion = new java.util.concurrent.atomic.AtomicInteger();

   /** Counts year changes; caches that hold water, lakes or ice for a year drop their entries when it moves. */
   public static int yearVersion() {
      return yearVersion.get();
   }

   /** Cache-key suffix for the game year in 250-year steps; empty until a year is set. */
   public static String yearKey() {
      int y = yearLc;
      return y == Integer.MIN_VALUE ? "" : "@" + Math.floorDiv(y, 250);
   }

   private static volatile java.util.function.IntBinaryOperator iceBlockProbe;

   /** The Earth generator registers how many blocks of ice a column carries at the current year (it knows the height scales). */
   public static void setIceBlockProbe(java.util.function.IntBinaryOperator probe) {
      iceBlockProbe = probe;
   }

   /** Blocks of ice the current year puts on a column; 0 with no era sheets or no generator yet. For the melt catch-up. */
   public static int iceBlocksAt(int blockX, int blockZ) {
      java.util.function.IntBinaryOperator p = iceBlockProbe;
      return p == null || !era.iceSheets() ? 0 : p.applyAsInt(blockX, blockZ);
   }

   public static int year() {
      return yearLc;
   }

   /** Blocks the sea stands above the era's datum at the current game year (0 with no era or no year set). */
   public static int floodBlocks(double metersPerBlock) {
      int y = yearLc;
      EraSettings e = era;
      return y == Integer.MIN_VALUE || !e.active() ? 0 : EraTimeline.shared().floodBlocks(y, e.seaLevelOffsetM(), metersPerBlock);
   }

   public static EraSettings era() {
      return era;
   }

   public static void setElevationProbe(ElevationProbe p) {
      probe = p;
   }

   private static IslandOverlay island(EraSettings e) {
      return e.islandOverlay() ? IslandOverlay.shared() : null;
   }

   /** Today's DEM metres at a block -> metres above the Age I sea (island stamped in, ice sheets on top). Identity when the era is off. */
   public static double adjustElevation(double todayMeters, double blockX, double blockZ, double worldScale) {
      EraSettings e = era;
      if (!e.active()) {
         return todayMeters;
      }
      IslandOverlay isl = island(e);
      if (isl == null && !e.iceSheets() && !e.lakes()) {
         return EraMath.relativeMeters(todayMeters, e);
      }
      double lat = EarthProjection.blockZToLat(blockZ, worldScale);
      double lon = EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale));
      if (e.lakes()) {
         double floor = EraLakes.shared().outletFloorMeters(lat, lon);   // outlets cut after the lake drained: refilled
         if (floor > todayMeters) {                                       // NaN compares false
            todayMeters = floor;
         }
      }
      double rel = EraMath.relativeMeters(todayMeters, e);
      if (isl != null) {
         rel = EraMath.blend(rel, isl.relativeMeters(lat, lon), isl.alpha(lat, lon));
      }
      return e.iceSheets() ? EraMath.withIce(rel, iceAt(lat, lon), EraMath.relativeMeters(EraMath.EVEREST_M, e)) : rel;
   }

   /** Metres of ice at a place: the 15 ka raster until a game year is set, then the two slices that bracket the year, blended. */
   private static double iceAt(double lat, double lon) {
      int y = yearLc;
      if (y == Integer.MIN_VALUE) {
         return IceSheets.shared().meters(lat, lon);
      }
      double[] b = EraTimeline.bracket(y);
      double older = iceSliceMeters((int) b[0], lat, lon);
      return b[2] == 0.0 ? older : older + (iceSliceMeters((int) b[1], lat, lon) - older) * b[2];
   }

   private static double iceSliceMeters(int ka, double lat, double lon) {
      return ka <= EraTimeline.ICE_END_KA ? 0.0 : IceSheets.slice(ka).meters(lat, lon);
   }

   /** The time slice (ka) a 16-block patch reads for vegetation and climate: 15 until a game year is set. */
   private static int sliceFor(long patchHash) {
      int y = yearLc;
      return y == Integer.MIN_VALUE ? EraTimeline.OLDEST_SLICE_KA : EraTimeline.sliceKa(y, ((patchHash >>> 40) & 0xFFFFFF) / (double) 0x1000000);
   }

   private static long patchHash(double blockX, double blockZ) {
      long h = (long) Math.floor(blockX) >> 4;
      h = h * 0x9E3779B97F4A7C15L ^ ((long) Math.floor(blockZ) >> 4) * 0xC2B2AE3D27D4EB4FL;
      h ^= h >>> 29;
      h *= 0xBF58476D1CE4E5B9L;
      h ^= h >>> 32;
      return h;
   }

   private static double jitterLon(long h) {
      return ((h & 0xFFFF) / 65535.0 - 0.5) * 0.5;
   }

   private static double jitterLat(long h) {
      return (((h >>> 16) & 0xFFFF) / 65535.0 - 0.5) * 0.5;
   }

   /**
    * BIOME4 class (EraVegetation) at a block. The lookup point is jittered by up to a quarter degree per 16-block patch, so the
    * 0.5 degree cells meet in a ragged ecotone rather than a straight line.
    */
   public static int vegetationClass(double blockX, double blockZ, double worldScale) {
      long h = patchHash(blockX, blockZ);
      int ka = sliceFor(h);
      double jlat = EarthProjection.blockZToLat(blockZ, worldScale) + jitterLat(h);
      double jlon = EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale)) + jitterLon(h);
      return EraLandUse.clear(EraVegetation.slice(ka).classAt(jlat, jlon), jlat, jlon, ka, h);   // people have cleared some of the woods
   }

   private static final double RELIEF_OFFSET_M = 500.0;
   private static final int COAST_OFFSET_BLOCKS = 25;
   private static final double COAST_MAX_M = 6.0;

   /** Relief and coast of a column from the elevation probe, computed on first use. */
   private static final class ProbeColumn implements EraPalette.Column {
      private final ElevationProbe probe;
      private final double x, z, scale, rel;
      private double relief = Double.NaN;
      private int coast = -1;

      ProbeColumn(ElevationProbe probe, double x, double z, double scale, double rel) {
         this.probe = probe;
         this.x = x;
         this.z = z;
         this.scale = scale;
         this.rel = rel;
      }

      @Override
      public double relief() {
         if (Double.isNaN(this.relief)) {
            if (this.probe == null) {
               this.relief = 0.0;
            } else {
               double off = Math.max(4.0, Math.rint(RELIEF_OFFSET_M / this.scale));
               double min = this.rel, max = this.rel;
               double[] v = {this.probe.relativeMeters(this.x + off, this.z, this.scale), this.probe.relativeMeters(this.x - off, this.z, this.scale),
                  this.probe.relativeMeters(this.x, this.z + off, this.scale), this.probe.relativeMeters(this.x, this.z - off, this.scale)};
               for (double e : v) {
                  if (!Double.isNaN(e)) {
                     min = Math.min(min, e);
                     max = Math.max(max, e);
                  }
               }
               this.relief = max - min;
            }
         }
         return this.relief;
      }

      @Override
      public boolean coast() {
         if (this.coast < 0) {
            boolean c = false;
            if (this.probe != null && this.rel > 0.0 && this.rel <= COAST_MAX_M) {
               double o = COAST_OFFSET_BLOCKS;
               c = this.probe.relativeMeters(this.x + o, this.z, this.scale) <= 0.0 || this.probe.relativeMeters(this.x - o, this.z, this.scale) <= 0.0
                  || this.probe.relativeMeters(this.x, this.z + o, this.scale) <= 0.0 || this.probe.relativeMeters(this.x, this.z - o, this.scale) <= 0.0;
            }
            this.coast = c ? 1 : 0;
         }
         return this.coast == 1;
      }
   }

   /**
    * Minecraft biome id for a land column in an era with vegetation: the palette's pick (EraPalette: BIOME4 class, cover, 15 ka
    * climate, altitude belt, relief, coast, place), else the class's wooded biome under tree cover and its open biome otherwise.
    * Null (the stock classifier decides) without vegetation, on the island, off the BIOME4 grid, and for sea, water, ice and
    * mangrove cover, and for wetland cover the palette has no rule for.
    */
   public static String vegetationBiome(int cover, double blockX, double blockZ, double worldScale) {
      EraSettings e = era;
      if (!e.vegetation() || cover == EraCover.NO_DATA || cover == EraCover.SNOW_ICE || cover == EraCover.WATER || cover == 95) {
         return null;
      }
      double lat = EarthProjection.blockZToLat(blockZ, worldScale);
      double lon = EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale));
      IslandOverlay isl = island(e);
      if (isl != null && isl.alpha(lat, lon) >= 0.5) {
         return null;
      }
      long h = patchHash(blockX, blockZ);
      double jlat = lat + jitterLat(h), jlon = lon + jitterLon(h);
      int ka = sliceFor(h);
      int cls = EraLandUse.clear(EraVegetation.slice(ka).classAt(jlat, jlon), jlat, jlon, ka, h);
      EraVegetation.Entry v = EraVegetation.entry(cls);
      if (v == null) {
         return null;
      }
      EraPalette pal = EraPalette.shared();
      double[] climate = pal.climateAt(jlat, jlon, ka);
      ElevationProbe p = probe;
      double rel = p == null ? 0.0 : p.relativeMeters(blockX, blockZ, worldScale);
      if (Double.isNaN(rel)) {
         rel = 0.0;
      }
      double dh = rel - EraMath.relativeMeters(pal.meanElevationToday(jlat, jlon), e);   // height above the climate cell's own mean
      String id = pal.choose(cls, cover, lat, lon, climate, dh, blockX, blockZ, new ProbeColumn(p, blockX, blockZ, worldScale, rel));
      if (id != null) {
         return id;
      }
      return cover == 90 ? null : cover == EraCover.TREE ? v.wooded() : v.open();
   }

   /**
    * Fantasy cave biome (EraPalette caves: rare free-standing pockets, and whole discs under tagged mythic sites) at a block,
    * or null for the stock cave policy. depth is blocks under the surface; surface the surface biome's registry text.
    */
   public static String caveBiome(double blockX, double blockY, double blockZ, double depth, String surface, double worldScale) {
      if (!era.vegetation()) {
         return null;
      }
      double lat = EarthProjection.blockZToLat(blockZ, worldScale);
      double lon = EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale));
      return EraPalette.shared().caveBiome(lat, lon, blockX, blockY, blockZ, depth, surface);
   }

   /** Age I river and lake-outflow biome by 15 ka climate (EraPalette rivers); null keeps the stock river. */
   public static String riverBiome(double blockX, double blockZ, double worldScale) {
      if (!era.vegetation()) {
         return null;
      }
      double lat = EarthProjection.blockZToLat(blockZ, worldScale);
      double lon = EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale));
      EraPalette pal = EraPalette.shared();
      return pal.riverBiome(pal.climateAt(lat, lon, sliceFor(patchHash(blockX, blockZ))), blockX, blockZ);
   }

   /** Metres of ice sheet at a block (0 when the era has no sheets). The generator lays it as the column's top blocks. */
   public static double iceMeters(double blockX, double blockZ, double worldScale) {
      if (!era.iceSheets()) {
         return 0.0;
      }
      return iceAt(EarthProjection.blockZToLat(blockZ, worldScale), EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale)));
   }

   /**
    * Lake level (metres relative to today's sea) at a block; NaN when the era has no lakes or outside every basin. The terrain
    * already carries the ice sheet, so water stands only where the ice surface is below the level: the dam is the ice itself.
    */
   public static double lakeLevelMeters(double blockX, double blockZ, double worldScale) {
      if (!era.lakes()) {
         return Double.NaN;
      }
      return EraLakes.shared().levelMeters(EarthProjection.blockZToLat(blockZ, worldScale), EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale)));
   }

   public static int adjustCover(int cover, double blockX, double blockZ, double worldScale) {
      EraSettings e = era;
      if (!e.active()) {
         return cover;
      }
      double lat = EarthProjection.blockZToLat(blockZ, worldScale);
      double lon = EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale));
      IslandOverlay isl = island(e);
      double alpha = isl == null ? 0.0 : isl.alpha(lat, lon);
      double islRel = alpha > 0.0 ? isl.relativeMeters(lat, lon) : Double.NaN;
      double ice = e.iceSheets() ? iceAt(lat, lon) : 0.0;
      double lake = e.lakes() ? EraLakes.shared().levelMeters(lat, lon) : Double.NaN;
      boolean needsReal = alpha < 0.5 && (cover == EraCover.NO_DATA || cover == EraCover.WATER || ice > 0.0 || !Double.isNaN(lake)
         || (e.ice() && EraCover.inHighlandsBox(lat, lon)));
      double rel = Double.NaN;
      ElevationProbe p = probe;
      if (needsReal && p != null) {
         rel = p.relativeMeters(blockX, blockZ, worldScale);
      }
      int c = EraCover.remap(cover, rel, islRel, alpha, lat, lon, e);
      if (e.vegetation() && alpha < 0.5) {
         c = EraCover.withVegetation(c, vegetationClass(blockX, blockZ, worldScale));
      }
      if (e.ice() && c == EraCover.TREE && p != null) {
         c = EraCover.belowTreeline(c, Double.isNaN(rel) ? p.relativeMeters(blockX, blockZ, worldScale) : rel, lat);
      }
      c = EraCover.withIceSheet(c, rel, ice);
      return EraCover.underLake(c, rel, Double.isNaN(lake) ? Double.NaN : EraMath.relativeMeters(lake, e));
   }

   /** TRUE where the island is land, FALSE where the island owns the pixel and it is sea, null when the era has no opinion. */
   public static Boolean landMaskOverride(double blockX, double blockZ, double worldScale) {
      EraSettings e = era;
      IslandOverlay isl = island(e);
      if (isl == null) {
         return null;
      }
      double lat = EarthProjection.blockZToLat(blockZ, worldScale);
      double lon = EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale));
      if (isl.alpha(lat, lon) < 0.5) {
         return null;
      }
      return isl.relativeMeters(lat, lon) > 0.0;
   }

   /**
    * Whether an era world skips a structure. With structure_filter on, exactly the datapack deny list (tag tellus:era_denied,
    * passed in as {@code denied}) is skipped, so natural ones from any mod stay. Otherwise an era world carries no structures
    * from other mods (the vanilla add_* flags already gate the vanilla ones).
    */
   public static boolean blocksStructure(String namespace, boolean denied) {
      EraSettings e = era;
      return e.structureFilter() ? denied : e.active() && !"minecraft".equals(namespace);
   }

   public static double compressHeightBlocks(double blocks) {
      return era.heightCompress() ? EraMath.compressBlocks(blocks) : blocks;
   }
}
