# Data sources and licences (Diaithir fork of Tellus)

| Source | Licence / terms | Used for |
|---|---|---|
| Mapterhorn terrain DEM (https://mapterhorn.com/) | See Tellus `THIRD_PARTY_NOTICES.md` (Mapterhorn Terrain) for exact terms | Land terrain, downloaded and cached at runtime |
| OpenWaters Seascape bathymetry (https://github.com/openwatersio/seascape, tiles https://tiles.openwaters.io/seascape/) | CC BY 4.0 (published tile compilation licence) | Ocean terrain, downloaded and cached at runtime |
| ESA WorldCover 2020 | CC BY 4.0 | Land cover, via Overture Maps base theme |
| Overture Maps base theme (https://docs.overturemaps.org/attribution/) | ODbL. Derived shipped databases must be ODbL; none are shipped | Land-cover and water classification, downloaded and cached at runtime |
| Diaithir island heightmap | Marlon Lee's own work (Diaithir Atlas) | Island terrain overlay |

Attribution wording, copied from Tellus `THIRD_PARTY_NOTICES.md`:

- Overture: Copyright Overture Maps Foundation and OpenStreetMap contributors. The base theme is licensed under ODbL.
- WorldCover: © ESA WorldCover project / Contains modified Copernicus Sentinel data (2020) processed by ESA WorldCover consortium. Available under CC BY 4.0.
- OpenWaters Seascape: Published tile compilation license: CC BY 4.0.

Credit lines to show in the pack's credits screen: Copyright Overture Maps Foundation and OpenStreetMap contributors (ODbL); © ESA WorldCover project / Contains modified Copernicus Sentinel data (2020) processed by ESA WorldCover consortium (CC BY 4.0); OpenWaters Seascape bathymetry (CC BY 4.0); Mapterhorn terrain (https://mapterhorn.com/); Diaithir island heightmap by Marlon Lee.
