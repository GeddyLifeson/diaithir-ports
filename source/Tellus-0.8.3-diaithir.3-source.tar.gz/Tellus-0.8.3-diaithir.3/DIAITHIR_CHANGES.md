# Diaithir changes to Tellus (LGPL-3.0)

This is a modified version of Tellus (https://github.com/Yucareux/Tellus, LGPL-3.0). Base: version 0.8.3.
Modified versions are marked `0.8.3-diaithir.N`. Changes are listed per file below and in git history of branch `diaithir-age1`.

Distribution rule for Diaithir releases: every released jar is accompanied by this repository's source for branch
`diaithir-age1` at the release commit (a `Tellus-diaithir-src-<version>.zip` next to the jar), the unmodified `LICENSE`,
and this file. Users may replace the jar with another build of the same mod id.

## Added (new files, package com.yucareux.tellus.era)
EraSettings, EraMath, IslandOverlay, EraCover, EraRuntime, EraProbe; resources under data/tellus/diaithir/.

## Modified
(one line per modified file is appended by each task that edits Tellus code)
- EarthGeneratorSettings.java: new optional "era" field (EraSettings)
- EarthCustomizeScreen.java (shared/mc261, mc262, pre-26): pass EraSettings.NONE to the widened constructor
- resources data/tellus/diaithir/* generated from the Atlas Age I map (world/island/build_island_raster.py in the DiaithirRPG repo)
- TellusElevationSource.java: era adjustment at every public elevation entry (funnel sampleResolvedElevation; wrapped LocalOnly/MemoryOnly resolved + double samplers, samplePreviewElevationMeters provider branch, ocean/open-water samplers, terrain-tiles local-only); slope sampler left raw
- OceanClassification.java: era world decides ocean only by surface vs the era sea level
- TellusLandCoverSource.java: sampleCoverClass remapped through EraRuntime.adjustCover
- TellusLandMaskSource.java: island land-mask override (sampleLandMask and LandMaskSampler.sample)
- EarthBiomeSource.java, shared/mc262 EarthChunkGenerator.java: install era at construction; generator also installs the elevation probe and soft-compresses height in scaleElevationToHeight (shared/pre-26 generator not wired)
- Preload cache key: no code change; the settings fingerprint hashes the encoded settings JSON, which carries "era" only when non-default (test in TerrainPreloadStorageTest)
- shared/mc262 EarthChunkGenerator.java: probe(blockX, blockZ) returning EraProbe
- NeoForgeTellusRuntimePlatform.java: /diaithir_probe and /diaithir_scan commands (gamemaster permission)
- resources data/tellus/worldgen/world_preset/diaithir_age_1.json: Age I preset

## How to test
bash E:/MCTest/tellus_port/runb.sh test --tests '<fully.qualified.TestClass>'   (log: E:\MCTest\tellus_port\build_test.log)
- shared/mc261 MinecraftVersionCompat.java: default and normalised random-biome lists use the 1.21.11 set (26.1.2 has no sulfur_caves; a fresh world otherwise failed registry freeze with an unbound sulfur_caves biome)
- EarthChunkGenerator.java, EarthBiomeSource.java: only an active era claims EraRuntime (registry loading builds every preset's generator, stock presets would otherwise overwrite the Age I settings)
- TellusElevationSource.java: in an era world a land-DEM value at or below sea level is replaced by the OpenWaters sea floor (high zoom, then the global zoom 8 when the tile holds 0) before the shift, so shelves and the Channel become land instead of a flat plateau
- WaterSurfaceResolver.java: today's Overture ocean polygons hold water only where the era terrain is at or below the era sea (region data, coarse and legacy column paths)
- RandomBiomeMixer.java: selected biome keys go through MinecraftVersionCompat so a 26.2-only biome is never keyed on 26.1
- NeoForgeTellusRuntimePlatform.java, EraPreload.java: /diaithir_preload, /diaithir_preload_status, /diaithir_column (diagnostics for the Age I world)
- Server note: Tellus writes its dynamic dimension-type pack on a world's first boot; the full -2032..2031 height applies from the second boot
- EarthChunkGenerator.java, EraRuntime.java: an era world blocks structures from every namespace but minecraft (Better Dungeons placed small dungeons near Edinburgh in the full Deep Worlds set); /diaithir_scan now lists structure and block-entity ids
- resources data/tellus/dimension_type/diaithir_age_1.json (shared/mc262) and the Age I preset: the preset uses its own dimension type with the generator's full range (-2032, 4064). The stock tellus:earth type is 800 blocks tall and Tellus only widens it through a datapack written on the first boot, so a fresh Age I world ran with a 800-block dimension under a 4064-block generator (air above Y 160, stone ceiling at 431, light-engine NPE with players)
- WaterSurfaceResolver.java: the era dry-land gate keys on an active era, not a shifted sea, so an era at today's sea level (Shardfall's island) is not flooded by today's ocean polygons
- TellusElevationSource.java: sampleOpenWatersElevationMeters goes through EraRuntime.adjustElevation, so ocean depth inside the island comes from the island raster instead of today's bathymetry
- 0.8.3-diaithir.2: the two era fixes above (Shardfall's island at today's sea); MinecraftScreenMixin moved to a shared/screen-minecraft layer used by the pre-26 targets and 26.1 (no duplicate copy)
- 0.8.3-diaithir.3: the Age I preset is uniform 1:5 (world_scale 5, 5 m per block in height, linear: era.height_compress false), sea at Y 200 so Challenger Deep and Everest fit Y -2032..2031 (Age I: -1968..1989)
