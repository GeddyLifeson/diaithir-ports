package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EraCoverTest {
   static final EraSettings AGE1 = new EraSettings(-95.0, true, true, true);
   static final double NAN = Double.NaN;

   @Test
   void exposedShelfIsNotSea() {              // Dogger Bank: today -25 m -> rel +70, ESA says water/no data
      assertEquals(30, EraCover.remap(80, 70.0, NAN, 0.0, 55.0, 2.5, AGE1));
      assertEquals(30, EraCover.remap(0, 70.0, NAN, 0.0, 55.0, 2.5, AGE1));
   }

   @Test
   void realSeaStaysSea() {
      assertEquals(80, EraCover.remap(80, -500.0, NAN, 0.0, 45.0, -20.0, AGE1));
      assertEquals(0, EraCover.remap(0, -5.0, NAN, 0.0, 55.0, 3.0, AGE1));
   }

   @Test
   void inlandLakeSurvives() {                // Loch Ness: today +16 m -> rel +111, ESA 80
      assertEquals(80, EraCover.remap(80, 111.0, NAN, 0.0, 57.3, -4.45, AGE1));
   }

   @Test
   void islandGetsVegetationByHeight() {
      assertEquals(0, EraCover.remap(0, 4.0, -3.0, 1.0, 56.9, -10.0, AGE1));
      assertEquals(30, EraCover.remap(0, NAN, 40.0, 1.0, 56.9, -10.0, AGE1));
      assertEquals(60, EraCover.remap(0, NAN, 700.0, 1.0, 56.9, -10.0, AGE1));
      assertEquals(70, EraCover.remap(0, NAN, 900.0, 1.0, 56.9, -10.0, AGE1));
      assertEquals(60, EraCover.remap(0, NAN, 900.0, 1.0, 56.9, -10.0, new EraSettings(-95.0, true, true, false)));
   }

   @Test
   void featherEdgeBelowHalfUsesRealData() {
      assertEquals(80, EraCover.remap(80, -300.0, 40.0, 0.3, 56.9, -7.9, AGE1));
   }

   @Test
   void highlandsIceNeedsHeightAndBox() {
      double benNevisRel = 1345.0 + 95.0;
      assertEquals(70, EraCover.remap(60, benNevisRel, NAN, 0.0, 56.7969, -5.0036, AGE1));
      assertEquals(30, EraCover.remap(30, 300.0 + 95.0, NAN, 0.0, 56.6, -4.5, AGE1));       // low ground, no ice
      assertEquals(60, EraCover.remap(60, 1300.0 + 95.0, NAN, 0.0, 51.0, -3.0, AGE1));      // outside the box
      assertEquals(60, EraCover.remap(60, benNevisRel, NAN, 0.0, 56.7969, -5.0036, new EraSettings(-95.0, true, true, false)));
   }

   @Test
   void noEraNoChange() {
      for (int c : new int[]{0, 10, 30, 60, 70, 80}) {
         assertEquals(c, EraCover.remap(c, 70.0, NAN, 0.0, 55.0, 2.5, EraSettings.NONE));
      }
   }

   @Test
   void nanElevationLeavesCoverAlone() {
      assertEquals(80, EraCover.remap(80, NAN, NAN, 0.0, 55.0, 2.5, AGE1));
   }
}
