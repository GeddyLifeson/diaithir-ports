package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EraMathTest {
   static final EraSettings AGE1 = new EraSettings(-95.0, true, true, true);

   @Test
   void shelfBecomesLandRelativeToOldSea() {
      assertEquals(75.0, EraMath.relativeMeters(-20.0, AGE1), 1e-9);   // Dogger Bank: 20 m deep today
      assertEquals(0.0, EraMath.relativeMeters(-95.0, AGE1), 1e-9);    // the old shoreline
      assertTrue(EraMath.relativeMeters(-3000.0, AGE1) < 0.0);         // open Atlantic stays sea
      assertEquals(1345.0, EraMath.relativeMeters(1345.0, EraSettings.NONE), 1e-9); // off = identity
   }

   @Test
   void nanStaysNaN() {
      assertTrue(Double.isNaN(EraMath.relativeMeters(Double.NaN, AGE1)));
      assertTrue(Double.isNaN(EraMath.blend(Double.NaN, Double.NaN, 0.0)));
   }

   @Test
   void blendUsesIslandWhereRealDataMissing() {
      assertEquals(300.0, EraMath.blend(Double.NaN, 300.0, 1.0));
      assertEquals(300.0, EraMath.blend(Double.NaN, 300.0, 0.25));      // no real data: island wins whenever alpha > 0
      assertEquals(10.0, EraMath.blend(10.0, 300.0, 0.0));
      assertEquals(155.0, EraMath.blend(10.0, 300.0, 0.5), 1e-9);
      assertEquals(300.0, EraMath.blend(10.0, 300.0, 1.0), 1e-9);
   }

   @Test
   void compressionIsIdentityBelowKnee() {
      for (double b : new double[]{0, 1, 63, 500, 1000, 1499.9}) {
         assertEquals(b, EraMath.compressBlocks(b), 1e-9, "b=" + b);
      }
      assertEquals(-999.0, EraMath.compressBlocks(-999.0), 1e-9);
      assertEquals(1345.0, EraMath.compressBlocks(1345.0), 1e-9);       // Ben Nevis keeps its true height
   }

   @Test
   void compressionStaysInsideWorldAndIsStrictlyIncreasing() {
      double prev = Double.NEGATIVE_INFINITY;
      for (double b = -11000; b <= 9000; b += 25) {
         double c = EraMath.compressBlocks(b);
         assertTrue(c > prev, "monotonic at " + b);
         prev = c;
         int y = (int) Math.round(c) + EraMath.HEIGHT_OFFSET;
         assertTrue(y >= EraMath.MIN_Y && y <= EraMath.MAX_Y, "b=" + b + " y=" + y);
      }
      int everest = (int) Math.round(EraMath.compressBlocks(8849.0)) + EraMath.HEIGHT_OFFSET;
      int mariana = (int) Math.round(EraMath.compressBlocks(-10935.0)) + EraMath.HEIGHT_OFFSET;
      assertTrue(everest > 1800 && everest <= 2031, "everest " + everest);
      assertTrue(mariana >= -2032 && mariana < -1800, "mariana " + mariana);
      assertTrue(EraMath.compressBlocks(5000) < EraMath.compressBlocks(8849), "relief order preserved");
   }

   @Test
   void compressionNanAndInfinity() {
      assertTrue(Double.isNaN(EraMath.compressBlocks(Double.NaN)));
      assertTrue(EraMath.compressBlocks(Double.POSITIVE_INFINITY) <= EraMath.MAX_Y - EraMath.HEIGHT_OFFSET);
   }

   @Test
   void shoreConstantForLaterAges() {
      assertEquals(95.0, EraMath.todayShoreRelativeMeters(AGE1), 1e-9);
      assertEquals(0.0, EraMath.todayShoreRelativeMeters(EraSettings.NONE), 1e-9);
   }
}
