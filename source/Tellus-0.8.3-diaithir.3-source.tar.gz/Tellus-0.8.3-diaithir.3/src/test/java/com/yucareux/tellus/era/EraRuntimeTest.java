package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.*;

import com.yucareux.tellus.worldgen.EarthProjection;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

class EraRuntimeTest {
   static final EraSettings AGE1 = new EraSettings(-95.0, true, true, true);
   static final double SCALE = 1.0;

   @AfterEach
   void reset() {
      EraRuntime.install(EraSettings.NONE);
      EraRuntime.setElevationProbe(null);
   }

   static double bx(double lon) { return EarthProjection.longitudeToBlockX(lon, SCALE); }
   static double bz(double lat) { return EarthProjection.latToBlockZ(lat, SCALE); }

   @Test
   void projectionRoundTripAtTheSpawn() {
      double x = bx(-10.0145), z = bz(56.982);
      assertEquals(-10.0145, EarthProjection.blockXToLongitude(x, SCALE), 1e-9);
      assertEquals(56.982, EarthProjection.blockZToLat(z, SCALE), 1e-7);
   }

   @Test
   void offIsIdentity() {
      EraRuntime.install(EraSettings.NONE);
      assertEquals(-20.0, EraRuntime.adjustElevation(-20.0, bx(2.5), bz(55.0), SCALE));
      assertEquals(80, EraRuntime.adjustCover(80, bx(2.5), bz(55.0), SCALE));
      assertEquals(1234.0, EraRuntime.compressHeightBlocks(1234.0));
      assertNull(EraRuntime.landMaskOverride(bx(2.5), bz(55.0), SCALE));
   }

   @Test
   void doggerBankIsDry() {
      EraRuntime.install(AGE1);
      assertEquals(75.0, EraRuntime.adjustElevation(-20.0, bx(2.5), bz(55.0), SCALE), 1e-9);
   }

   @Test
   void islandOverridesRealOceanDataAtTheSpawn() {
      EraRuntime.install(AGE1);
      double x = bx(-10.0145), z = bz(56.982);
      double rel = EraRuntime.adjustElevation(-2500.0, x, z, SCALE);      // real data there is deep Atlantic
      assertTrue(rel >= 2.0, "island land wins: " + rel);
      assertEquals(Boolean.TRUE, EraRuntime.landMaskOverride(x, z, SCALE));
   }

   @Test
   void missingRealDataStaysNaNOffIslandAndIsFilledOnIsland() {
      EraRuntime.install(AGE1);
      assertTrue(Double.isNaN(EraRuntime.adjustElevation(Double.NaN, bx(2.5), bz(55.0), SCALE)));
      assertFalse(Double.isNaN(EraRuntime.adjustElevation(Double.NaN, bx(-10.0145), bz(56.982), SCALE)));
   }

   @Test
   void shelfCoverAndHighlandsIce() {
      EraRuntime.install(AGE1);
      EraRuntime.setElevationProbe((x, z, s) -> EraRuntime.adjustElevation(-25.0, x, z, s));
      assertEquals(30, EraRuntime.adjustCover(80, bx(2.5), bz(55.0), SCALE));
      EraRuntime.setElevationProbe((x, z, s) -> EraRuntime.adjustElevation(1345.0, x, z, s));
      assertEquals(70, EraRuntime.adjustCover(60, bx(-5.0036), bz(56.7969), SCALE));
   }

   @Test
   void coverNeedsNoProbeWhenNothingCanChange() {
      EraRuntime.install(AGE1);                                            // no probe installed
      assertEquals(30, EraRuntime.adjustCover(30, bx(10.0), bz(48.0), SCALE));   // inland Germany, class 30: untouched
   }

   @Test
   void eraWorldsBlockOtherModsStructuresOnly() {
      assertFalse(EraRuntime.blocksStructure("betterdungeons"));
      EraRuntime.install(AGE1);
      assertTrue(EraRuntime.blocksStructure("betterdungeons"));
      assertFalse(EraRuntime.blocksStructure("minecraft"));
   }

   @Test
   void everestFitsUnderTheCeiling() {
      EraRuntime.install(AGE1);
      int y = (int) Math.round(EraRuntime.compressHeightBlocks(8849.0)) + EraMath.HEIGHT_OFFSET;
      assertTrue(y <= EraMath.MAX_Y);
   }
}
