package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.*;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import org.junit.jupiter.api.Test;

class EraSettingsTest {
   @Test
   void defaultsToNoneWhenKeysMissing() {
      JsonElement json = JsonParser.parseString("{}");
      EraSettings s = EraSettings.CODEC.parse(JsonOps.INSTANCE, json).getOrThrow();
      assertEquals(EraSettings.NONE, s);
      assertFalse(s.active());
   }

   @Test
   void parsesAgeOne() {
      JsonElement json = JsonParser.parseString(
         "{\"sea_level_offset_m\":-95.0,\"island_overlay\":true,\"height_compress\":true,\"ice\":true}");
      EraSettings s = EraSettings.CODEC.parse(JsonOps.INSTANCE, json).getOrThrow();
      assertEquals(-95.0, s.seaLevelOffsetM());
      assertTrue(s.islandOverlay() && s.heightCompress() && s.ice());
      assertTrue(s.active());
   }

   @Test
   void roundTrips() {
      EraSettings in = new EraSettings(-95.0, true, true, true);
      JsonElement json = EraSettings.CODEC.encodeStart(JsonOps.INSTANCE, in).getOrThrow();
      assertEquals(in, EraSettings.CODEC.parse(JsonOps.INSTANCE, json).getOrThrow());
   }

   @Test
   void rejectsAbsurdOffset() {
      JsonElement json = JsonParser.parseString("{\"sea_level_offset_m\":-5000.0}");
      assertTrue(EraSettings.CODEC.parse(JsonOps.INSTANCE, json).error().isPresent());
   }

   @Test
   void cacheKeyDiffers() {
      assertNotEquals(EraSettings.NONE.cacheKey(), new EraSettings(-95.0, true, true, true).cacheKey());
      assertNotEquals(new EraSettings(-95.0, true, true, true).cacheKey(), new EraSettings(-95.0, false, true, true).cacheKey());
      assertEquals(new EraSettings(-95.0, true, true, true).cacheKey(), new EraSettings(-95.0, true, true, true).cacheKey());
   }

   @Test
   void stockEarthPresetSettingsDecodeWithEraNone() throws Exception {
      try (var in = EraSettingsTest.class.getResourceAsStream("/data/tellus/worldgen/world_preset/earth.json")) {
         JsonElement root = JsonParser.parseReader(new java.io.InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8));
         JsonElement settings = root.getAsJsonObject().getAsJsonObject("dimensions").getAsJsonObject("minecraft:overworld")
            .getAsJsonObject("generator").getAsJsonObject("settings");
         var parsed = com.yucareux.tellus.worldgen.EarthGeneratorSettings.CODEC.parse(JsonOps.INSTANCE, settings).getOrThrow();
         assertEquals(EraSettings.NONE, parsed.era());
      }
   }
}
