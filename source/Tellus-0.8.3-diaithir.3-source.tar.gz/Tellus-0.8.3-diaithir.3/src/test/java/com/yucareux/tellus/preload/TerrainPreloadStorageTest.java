package com.yucareux.tellus.preload;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import com.yucareux.tellus.worldgen.EarthGeneratorSettings;
import org.junit.jupiter.api.Test;

class TerrainPreloadStorageTest {
   @Test
   void rejectsIdentifiersThatCouldEscapeTheCacheRoot() {
      assertTrue(TerrainPreloadStorage.isValidIdentifier("preload-1234_test.v2"));
      assertFalse(TerrainPreloadStorage.isValidIdentifier("../../outside"));
      assertFalse(TerrainPreloadStorage.isValidIdentifier(".."));
      assertThrows(
         IllegalArgumentException.class,
         () -> TerrainPreloadStorage.instance().publishedDirectory("../../outside")
      );
   }

   @Test
   void eraChangesTheSettingsFingerprintAndNoneLeavesItAlone() {
      TerrainPreloadStorage storage = TerrainPreloadStorage.instance();
      EarthGeneratorSettings stock = decode("{}");
      EarthGeneratorSettings age1 = decode("{\"era\":{\"sea_level_offset_m\":-95.0,\"island_overlay\":true}}");
      JsonElement stockJson = storage.encodeSettings(stock);
      assertFalse(stockJson.getAsJsonObject().has("era"));
      assertNotEquals(storage.settingsFingerprint(stockJson), storage.settingsFingerprint(storage.encodeSettings(age1)));
   }

   private static EarthGeneratorSettings decode(String json) {
      return EarthGeneratorSettings.CODEC.parse(JsonOps.INSTANCE, JsonParser.parseString(json)).getOrThrow();
   }
}
