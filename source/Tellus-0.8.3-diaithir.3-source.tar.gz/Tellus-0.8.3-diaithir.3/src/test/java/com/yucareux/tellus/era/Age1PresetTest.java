package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.*;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import com.yucareux.tellus.worldgen.EarthGeneratorSettings;
import com.yucareux.tellus.worldgen.EarthProjection;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class Age1PresetTest {
   static EarthGeneratorSettings parsed;
   static JsonElement root;

   @BeforeAll
   static void load() throws Exception {
      try (var in = Age1PresetTest.class.getResourceAsStream("/data/tellus/worldgen/world_preset/diaithir_age_1.json")) {
         root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8));
      }
      JsonElement settings = root.getAsJsonObject().getAsJsonObject("dimensions").getAsJsonObject("minecraft:overworld")
         .getAsJsonObject("generator").getAsJsonObject("settings");
      parsed = EarthGeneratorSettings.CODEC.parse(JsonOps.INSTANCE, settings).getOrThrow();
   }

   @Test
   void oneToOneNoRoadsNoBuildingsNoRealtime() {
      assertEquals(5.0, parsed.worldScale());
      assertEquals(200, parsed.heightOffset());
      assertFalse(parsed.enableRoads());
      assertFalse(parsed.enableBuildings());
      assertFalse(parsed.realtimeTime());
      assertFalse(parsed.realtimeWeather());
      assertFalse(parsed.automaticHeightScaling());
   }

   @Test
   void everyStructureFlagIsOff() {
      for (var e : root.getAsJsonObject().getAsJsonObject("dimensions").getAsJsonObject("minecraft:overworld")
         .getAsJsonObject("generator").getAsJsonObject("settings").entrySet()) {
         if (e.getKey().startsWith("add_")) {
            assertFalse(e.getValue().getAsBoolean(), e.getKey());
         }
      }
   }

   @Test
   void eraIsAgeOne() {
      assertEquals(new EraSettings(-95.0, true, false, true), parsed.era());
   }

   @Test
   void generatorAndBiomeSourceSettingsAreIdentical() {
      var gen = root.getAsJsonObject().getAsJsonObject("dimensions").getAsJsonObject("minecraft:overworld").getAsJsonObject("generator");
      assertEquals(gen.getAsJsonObject("settings"), gen.getAsJsonObject("biome_source").getAsJsonObject("settings"));
   }

   @Test
   void spawnIsOnTheIsland() {
      IslandOverlay island = IslandOverlay.shared();
      assertEquals(1.0, island.alpha(parsed.spawnLatitude(), parsed.spawnLongitude()), 1e-9);
      assertTrue(island.relativeMeters(parsed.spawnLatitude(), parsed.spawnLongitude()) >= 2.0);
   }

   @Test
   void highestSpotOnEarthFitsTheDimension() {
      assertEquals(1989, surfaceY(8849.0, 27.9881), 1);     // Everest, linear at 5 m per block
   }

   @Test
   void deepestSpotOnEarthFitsTheDimension() {
      assertEquals(-1968, surfaceY(-10935.0, 11.3733), 1);  // Challenger Deep
   }

   private int surfaceY(double todayMeters, double lat) {
      double blocks = com.yucareux.tellus.worldgen.TerrainHeightTransform.scaledElevationBlocks(
         EraMath.relativeMeters(todayMeters, parsed.era()), EarthProjection.latToBlockZ(lat, parsed.worldScale()),
         parsed.effectiveVerticalWorldScale(), parsed.effectiveTerrestrialHeightScale(), parsed.effectiveOceanicHeightScale(),
         parsed.experimentalIncreaseHeight(), parsed.automaticHeightScaling());
      return (int) Math.round(blocks) + parsed.effectiveHeightOffset();
   }

   @Test
   void highlandsScaleLinearlyAtOneToFive() {
      double blockZ = EarthProjection.latToBlockZ(56.7969, parsed.worldScale());
      double blocks = com.yucareux.tellus.worldgen.TerrainHeightTransform.scaledElevationBlocks(
         1345.0 + 95.0, blockZ, parsed.effectiveVerticalWorldScale(), parsed.effectiveTerrestrialHeightScale(),
         parsed.effectiveOceanicHeightScale(), parsed.experimentalIncreaseHeight(), parsed.automaticHeightScaling());
      assertEquals(288.0, blocks, 1.0);        // automatic Mercator height inflation is off, so 5 m is 1 block
   }

   @Test
   void dimensionTypeMatchesTheGeneratorRangeFromTheFirstBoot() throws Exception {
      String typeId = root.getAsJsonObject().getAsJsonObject("dimensions").getAsJsonObject("minecraft:overworld").get("type").getAsString();
      assertEquals("tellus:diaithir_age_1", typeId);
      try (var in = Age1PresetTest.class.getResourceAsStream("/data/tellus/dimension_type/diaithir_age_1.json")) {
         var type = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
         var limits = EarthGeneratorSettings.resolveHeightLimits(parsed);
         assertEquals(limits.minY(), type.get("min_y").getAsInt());
         assertEquals(limits.height(), type.get("height").getAsInt());
         assertEquals(limits.logicalHeight(), type.get("logical_height").getAsInt());
         assertEquals(-2032, limits.minY());
         assertEquals(4064, limits.height());
      }
   }
}
