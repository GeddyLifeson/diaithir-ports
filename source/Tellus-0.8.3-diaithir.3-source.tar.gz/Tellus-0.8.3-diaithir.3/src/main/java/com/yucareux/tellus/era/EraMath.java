package com.yucareux.tellus.era;

/** Pure era math. No Minecraft types, no I/O. */
public final class EraMath {
   public static final int HEIGHT_OFFSET = 64;
   public static final int MIN_Y = -2032;
   public static final int MAX_Y = 2031;
   private static final int MARGIN = 8;
   private static final double UP_KNEE = 1500.0;
   private static final double DOWN_KNEE = 1000.0;
   private static final double UP_ROOM = MAX_Y - HEIGHT_OFFSET - MARGIN - UP_KNEE;                 // 459
   private static final double DOWN_ROOM = -(MIN_Y + MARGIN - HEIGHT_OFFSET) - DOWN_KNEE;          // 1088

   private EraMath() {
   }

   /** Height of a point above the era's sea. Today's DEM metres minus the era sea level (offset is negative: -95 -> +95). */
   public static double relativeMeters(double todayMeters, EraSettings era) {
      return todayMeters - era.seaLevelOffsetM();
   }

   /** Mix the island's relative height over the real one. NaN real data yields the island wherever alpha > 0. */
   public static double blend(double relMeters, double islandRelMeters, double alpha) {
      if (!(alpha > 0.0) || Double.isNaN(islandRelMeters)) {
         return relMeters;
      }
      if (Double.isNaN(relMeters)) {
         return islandRelMeters;
      }
      return relMeters + (islandRelMeters - relMeters) * Math.min(1.0, alpha);
   }

   /**
    * Smooth saturating squash of the vertical range so every column fits -2032..2031. Identity up to the knee
    * (1500 up, 1000 down), then y = room * x / (x + room): slope 1 at the knee, strictly increasing, never reaching the cap.
    */
   public static double compressBlocks(double blocks) {
      if (Double.isNaN(blocks)) {
         return Double.NaN;
      }
      if (blocks > UP_KNEE) {
         double x = blocks - UP_KNEE;
         return Double.isInfinite(x) ? UP_KNEE + UP_ROOM : UP_KNEE + UP_ROOM * x / (x + UP_ROOM);
      }
      if (blocks < -DOWN_KNEE) {
         double x = -DOWN_KNEE - blocks;
         return Double.isInfinite(x) ? -DOWN_KNEE - DOWN_ROOM : -DOWN_KNEE - DOWN_ROOM * x / (x + DOWN_ROOM);
      }
      return blocks;
   }

   /** Where today's sea sits in this era's relative metres. Later Ages flood-fill ocean-connected air below this. */
   public static double todayShoreRelativeMeters(EraSettings era) {
      return -era.seaLevelOffsetM();
   }
}
