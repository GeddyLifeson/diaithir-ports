package com.yucareux.tellus.era;

import com.yucareux.tellus.worldgen.EarthProjection;

/**
 * Per-JVM era state. One world per server JVM; the generator installs its settings at construction.
 * ponytail: a static, not threaded settings, because Tellus' sources are shared singletons. Make it per-generator if two
 * differently-configured Earth worlds ever share one JVM.
 */
public final class EraRuntime {
   public interface ElevationProbe {
      double relativeMeters(double blockX, double blockZ, double worldScale);
   }

   private static volatile EraSettings era = EraSettings.NONE;
   private static volatile ElevationProbe probe;

   private EraRuntime() {
   }

   public static void install(EraSettings settings) {
      era = settings == null ? EraSettings.NONE : settings;
   }

   public static EraSettings era() {
      return era;
   }

   public static void setElevationProbe(ElevationProbe p) {
      probe = p;
   }

   private static IslandOverlay island(EraSettings e) {
      return e.islandOverlay() ? IslandOverlay.shared() : null;
   }

   /** Today's DEM metres at a block -> metres above the Age I sea (island stamped in). Identity when the era is off. */
   public static double adjustElevation(double todayMeters, double blockX, double blockZ, double worldScale) {
      EraSettings e = era;
      if (!e.active()) {
         return todayMeters;
      }
      double rel = EraMath.relativeMeters(todayMeters, e);
      IslandOverlay isl = island(e);
      if (isl == null) {
         return rel;
      }
      double lat = EarthProjection.blockZToLat(blockZ, worldScale);
      double lon = EarthProjection.blockXToLongitude(blockX, worldScale);
      return EraMath.blend(rel, isl.relativeMeters(lat, lon), isl.alpha(lat, lon));
   }

   public static int adjustCover(int cover, double blockX, double blockZ, double worldScale) {
      EraSettings e = era;
      if (!e.active()) {
         return cover;
      }
      double lat = EarthProjection.blockZToLat(blockZ, worldScale);
      double lon = EarthProjection.blockXToLongitude(blockX, worldScale);
      IslandOverlay isl = island(e);
      double alpha = isl == null ? 0.0 : isl.alpha(lat, lon);
      double islRel = alpha > 0.0 ? isl.relativeMeters(lat, lon) : Double.NaN;
      boolean needsReal = alpha < 0.5 && (cover == EraCover.NO_DATA || cover == EraCover.WATER
         || (e.ice() && EraCover.inHighlandsBox(lat, lon)));
      double rel = Double.NaN;
      ElevationProbe p = probe;
      if (needsReal && p != null) {
         rel = p.relativeMeters(blockX, blockZ, worldScale);
      }
      return EraCover.remap(cover, rel, islRel, alpha, lat, lon, e);
   }

   /** TRUE where the island is land, FALSE where the island owns the pixel and it is sea, null when the era has no opinion. */
   public static Boolean landMaskOverride(double blockX, double blockZ, double worldScale) {
      EraSettings e = era;
      IslandOverlay isl = island(e);
      if (isl == null) {
         return null;
      }
      double lat = EarthProjection.blockZToLat(blockZ, worldScale);
      double lon = EarthProjection.blockXToLongitude(blockX, worldScale);
      if (isl.alpha(lat, lon) < 0.5) {
         return null;
      }
      return isl.relativeMeters(lat, lon) > 0.0;
   }

   /** An era world carries no structures from other mods (the vanilla add_* flags already gate the vanilla ones). */
   public static boolean blocksStructure(String namespace) {
      return era.active() && !"minecraft".equals(namespace);
   }

   public static double compressHeightBlocks(double blocks) {
      return era.heightCompress() ? EraMath.compressBlocks(blocks) : blocks;
   }
}
