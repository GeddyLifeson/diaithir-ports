package com.yucareux.tellus.era;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/** Era switches. NONE leaves Tellus behaving exactly as stock. */
public record EraSettings(double seaLevelOffsetM, boolean islandOverlay, boolean heightCompress, boolean ice) {
   public static final EraSettings NONE = new EraSettings(0.0, false, false, false);

   public static final Codec<EraSettings> CODEC = RecordCodecBuilder.create(i -> i.group(
      Codec.doubleRange(-200.0, 200.0).optionalFieldOf("sea_level_offset_m", 0.0).forGetter(EraSettings::seaLevelOffsetM),
      Codec.BOOL.optionalFieldOf("island_overlay", false).forGetter(EraSettings::islandOverlay),
      Codec.BOOL.optionalFieldOf("height_compress", false).forGetter(EraSettings::heightCompress),
      Codec.BOOL.optionalFieldOf("ice", false).forGetter(EraSettings::ice)
   ).apply(i, EraSettings::new));

   public boolean active() {
      return !this.equals(NONE);
   }

   /** Stable text folded into terrain-preload / cache keys so packages built under another era are never reused. */
   public String cacheKey() {
      return "era[" + this.seaLevelOffsetM + "," + this.islandOverlay + "," + this.heightCompress + "," + this.ice + "]";
   }
}
