package com.yucareux.tellus.era;

/** ESA WorldCover class remap for the Age I world. Pure; callers supply elevations. */
public final class EraCover {
   public static final int NO_DATA = 0, GRASS = 30, BARE = 60, SNOW_ICE = 70, WATER = 80;
   public static final double ISLAND_SNOW_LINE_M = 850.0;
   public static final double ISLAND_BARE_LINE_M = 600.0;
   public static final double HIGHLANDS_ICE_MIN_TODAY_M = 650.0;

   private EraCover() {
   }

   public static boolean inHighlandsBox(double lat, double lon) {
      return lat >= 56.2 && lat <= 57.8 && lon >= -5.9 && lon <= -3.3;
   }

   public static int remap(int cover, double relMeters, double islandRelMeters, double islandAlpha, double lat, double lon, EraSettings era) {
      if (!era.active()) {
         return cover;
      }
      if (era.islandOverlay() && islandAlpha >= 0.5 && !Double.isNaN(islandRelMeters)) {
         if (islandRelMeters <= 0.0) {
            return NO_DATA;
         }
         if (era.ice() && islandRelMeters >= ISLAND_SNOW_LINE_M) {
            return SNOW_ICE;
         }
         return islandRelMeters >= ISLAND_BARE_LINE_M ? BARE : GRASS;
      }
      if (Double.isNaN(relMeters)) {
         return cover;
      }
      double todayElev = relMeters + era.seaLevelOffsetM();
      if (era.ice() && inHighlandsBox(lat, lon) && todayElev >= HIGHLANDS_ICE_MIN_TODAY_M) {
         return SNOW_ICE;
      }
      if (era.seaLevelOffsetM() != 0.0 && relMeters > 0.0 && todayElev < 0.0 && (cover == NO_DATA || cover == WATER)) {
         return GRASS;
      }
      return cover;
   }
}
