package com.yucareux.tellus.era;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import javax.imageio.ImageIO;

/**
 * Bilinear sampler for the global Age I ice raster: metres of ice added on top of today's surface
 * (see world/earth/ice/build_ice_raster.py in the DiaithirRPG repo for the sources and the encoding).
 * Held as 64 x 64 tiles; ice-free tiles are not stored (about 12% of the 7200 x 3600 raster has ice).
 */
public final class IceSheets {
   private static final String DIR = "/data/tellus/diaithir/";
   private static final int TILE = 64;
   private static volatile IceSheets shared;

   private final double latN, latS, lonW, lonE;
   private final int width, height, tilesX;
   private final char[][] tiles;
   private final int maxMeters;

   IceSheets(JsonObject meta, BufferedImage img) {
      this.latN = meta.get("lat_n").getAsDouble();
      this.latS = meta.get("lat_s").getAsDouble();
      this.lonW = meta.get("lon_w").getAsDouble();
      this.lonE = meta.get("lon_e").getAsDouble();
      this.width = meta.get("width").getAsInt();
      this.height = meta.get("height").getAsInt();
      if (img.getWidth() != this.width || img.getHeight() != this.height) {
         throw new IllegalStateException("ice raster does not match ice_meta.json");
      }
      this.tilesX = (this.width + TILE - 1) / TILE;
      int tilesY = (this.height + TILE - 1) / TILE;
      this.tiles = new char[this.tilesX * tilesY][];
      Raster r = img.getRaster();
      int max = 0;
      int[] row = new int[TILE];
      for (int ty = 0; ty < tilesY; ty++) {
         for (int tx = 0; tx < this.tilesX; tx++) {
            char[] tile = null;
            int w = Math.min(TILE, this.width - tx * TILE);
            for (int y = 0; y < TILE && ty * TILE + y < this.height; y++) {
               r.getSamples(tx * TILE, ty * TILE + y, w, 1, 0, row);
               for (int x = 0; x < w; x++) {
                  if (row[x] != 0) {
                     if (tile == null) {
                        tile = new char[TILE * TILE];
                     }
                     tile[y * TILE + x] = (char) row[x];
                     max = Math.max(max, row[x]);
                  }
               }
            }
            this.tiles[ty * this.tilesX + tx] = tile;
         }
      }
      this.maxMeters = max;
   }

   public static IceSheets loadFromClasspath() throws IOException {
      try (InputStream mi = IceSheets.class.getResourceAsStream(DIR + "ice_meta.json");
           InputStream ii = IceSheets.class.getResourceAsStream(DIR + "ice_thickness.png")) {
         if (mi == null || ii == null) {
            throw new IOException("ice resources missing under " + DIR);
         }
         JsonObject meta = JsonParser.parseReader(new InputStreamReader(mi, StandardCharsets.UTF_8)).getAsJsonObject();
         return new IceSheets(meta, ImageIO.read(ii));
      }
   }

   public static IceSheets shared() {
      IceSheets s = shared;
      if (s == null) {
         synchronized (IceSheets.class) {
            if (shared == null) {
               try {
                  shared = loadFromClasspath();
               } catch (IOException e) {
                  throw new IllegalStateException("cannot load Diaithir ice sheets", e);
               }
            }
            s = shared;
         }
      }
      return s;
   }

   public int maxMeters() {
      return this.maxMeters;
   }

   /** Metres of ice on top of today's surface; 0 where there is none or the coordinate is NaN. Longitude wraps. */
   public double meters(double lat, double lon) {
      if (Double.isNaN(lat) || Double.isNaN(lon)) {
         return 0.0;
      }
      double fx = (lon - this.lonW) / (this.lonE - this.lonW) * this.width - 0.5;
      double fy = (this.latN - lat) / (this.latN - this.latS) * this.height - 0.5;
      fy = Math.max(0.0, Math.min(this.height - 1.0, fy));
      double x0f = Math.floor(fx);
      int y0 = (int) fy;
      int y1 = Math.min(this.height - 1, y0 + 1);
      int x0 = Math.floorMod((long) x0f, this.width);
      int x1 = (x0 + 1) % this.width;
      double tx = fx - x0f, ty = fy - y0;
      double top = this.at(x0, y0) + (this.at(x1, y0) - this.at(x0, y0)) * tx;
      double bot = this.at(x0, y1) + (this.at(x1, y1) - this.at(x0, y1)) * tx;
      return top + (bot - top) * ty;
   }

   int at(int x, int y) {
      char[] tile = this.tiles[(y / TILE) * this.tilesX + x / TILE];
      return tile == null ? 0 : tile[(y % TILE) * TILE + x % TILE];
   }
}
