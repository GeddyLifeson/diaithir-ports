package com.yucareux.tellus.era;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/** Era switches. NONE leaves Tellus behaving exactly as stock. */
public record EraSettings(double seaLevelOffsetM, boolean islandOverlay, boolean heightCompress, boolean ice, boolean iceSheets, boolean lakes, boolean vegetation, boolean structureFilter) {
   public static final EraSettings NONE = new EraSettings(0.0, false, false, false, false, false, false, false);

   public static final Codec<EraSettings> CODEC = RecordCodecBuilder.create(i -> i.group(
      Codec.doubleRange(-200.0, 200.0).optionalFieldOf("sea_level_offset_m", 0.0).forGetter(EraSettings::seaLevelOffsetM),
      Codec.BOOL.optionalFieldOf("island_overlay", false).forGetter(EraSettings::islandOverlay),
      Codec.BOOL.optionalFieldOf("height_compress", false).forGetter(EraSettings::heightCompress),
      Codec.BOOL.optionalFieldOf("ice", false).forGetter(EraSettings::ice),
      Codec.BOOL.optionalFieldOf("ice_sheets", false).forGetter(EraSettings::iceSheets),
      Codec.BOOL.optionalFieldOf("lakes", false).forGetter(EraSettings::lakes),
      Codec.BOOL.optionalFieldOf("vegetation", false).forGetter(EraSettings::vegetation),
      Codec.BOOL.optionalFieldOf("structure_filter", false).forGetter(EraSettings::structureFilter)
   ).apply(i, EraSettings::new));

   public boolean active() {
      return !this.equals(NONE);
   }

   /**
    * Stable text folded into terrain-preload / cache keys so packages built under another era are never reused. structureFilter
    * is left out: it changes no terrain.
    */
   public String cacheKey() {
      return "era[" + this.seaLevelOffsetM + "," + this.islandOverlay + "," + this.heightCompress + "," + this.ice + "," + this.iceSheets + "," + this.lakes + "," + this.vegetation + "]";
   }
}
