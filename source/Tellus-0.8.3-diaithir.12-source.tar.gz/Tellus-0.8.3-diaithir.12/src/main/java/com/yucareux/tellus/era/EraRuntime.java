package com.yucareux.tellus.era;

import com.yucareux.tellus.worldgen.EarthProjection;

/**
 * Per-JVM era state. One world per server JVM; the generator installs its settings at construction.
 * ponytail: a static, not threaded settings, because Tellus' sources are shared singletons. Make it per-generator if two
 * differently-configured Earth worlds ever share one JVM.
 */
public final class EraRuntime {
   public interface ElevationProbe {
      double relativeMeters(double blockX, double blockZ, double worldScale);
   }

   private static volatile EraSettings era = EraSettings.NONE;
   private static volatile ElevationProbe probe;

   private EraRuntime() {
   }

   public static void install(EraSettings settings) {
      era = settings == null ? EraSettings.NONE : settings;
   }

   public static EraSettings era() {
      return era;
   }

   public static void setElevationProbe(ElevationProbe p) {
      probe = p;
   }

   private static IslandOverlay island(EraSettings e) {
      return e.islandOverlay() ? IslandOverlay.shared() : null;
   }

   /** Today's DEM metres at a block -> metres above the Age I sea (island stamped in, ice sheets on top). Identity when the era is off. */
   public static double adjustElevation(double todayMeters, double blockX, double blockZ, double worldScale) {
      EraSettings e = era;
      if (!e.active()) {
         return todayMeters;
      }
      IslandOverlay isl = island(e);
      if (isl == null && !e.iceSheets() && !e.lakes()) {
         return EraMath.relativeMeters(todayMeters, e);
      }
      double lat = EarthProjection.blockZToLat(blockZ, worldScale);
      double lon = EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale));
      if (e.lakes()) {
         double floor = EraLakes.shared().outletFloorMeters(lat, lon);   // outlets cut after the lake drained: refilled
         if (floor > todayMeters) {                                       // NaN compares false
            todayMeters = floor;
         }
      }
      double rel = EraMath.relativeMeters(todayMeters, e);
      if (isl != null) {
         rel = EraMath.blend(rel, isl.relativeMeters(lat, lon), isl.alpha(lat, lon));
      }
      return e.iceSheets() ? EraMath.withIce(rel, IceSheets.shared().meters(lat, lon), EraMath.relativeMeters(EraMath.EVEREST_M, e)) : rel;
   }

   /**
    * BIOME4 class (EraVegetation) at a block. The lookup point is jittered by up to a quarter degree per 16-block patch, so the
    * 0.5 degree cells meet in a ragged ecotone rather than a straight line.
    */
   public static int vegetationClass(double blockX, double blockZ, double worldScale) {
      long h = (long) Math.floor(blockX) >> 4;
      h = h * 0x9E3779B97F4A7C15L ^ ((long) Math.floor(blockZ) >> 4) * 0xC2B2AE3D27D4EB4FL;
      h ^= h >>> 29;
      h *= 0xBF58476D1CE4E5B9L;
      h ^= h >>> 32;
      double jx = ((h & 0xFFFF) / 65535.0 - 0.5) * 0.5;
      double jz = (((h >>> 16) & 0xFFFF) / 65535.0 - 0.5) * 0.5;
      return EraVegetation.shared().classAt(
         EarthProjection.blockZToLat(blockZ, worldScale) + jz, EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale)) + jx);
   }

   /**
    * Minecraft biome id for a land column in an era with vegetation: the BIOME4 class's wooded biome under tree cover, its open
    * biome otherwise. Null (the stock classifier decides) without vegetation, on the island, off the BIOME4 grid, and for sea,
    * water, ice, wetland and mangrove cover.
    */
   public static String vegetationBiome(int cover, double blockX, double blockZ, double worldScale) {
      EraSettings e = era;
      if (!e.vegetation() || cover == EraCover.NO_DATA || cover == EraCover.SNOW_ICE || cover == EraCover.WATER || cover == 90 || cover == 95) {
         return null;
      }
      IslandOverlay isl = island(e);
      if (isl != null && isl.alpha(EarthProjection.blockZToLat(blockZ, worldScale), EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale))) >= 0.5) {
         return null;
      }
      EraVegetation.Entry v = EraVegetation.entry(vegetationClass(blockX, blockZ, worldScale));
      return v == null ? null : cover == 10 ? v.wooded() : v.open();
   }

   /** Metres of ice sheet at a block (0 when the era has no sheets). The generator lays it as the column's top blocks. */
   public static double iceMeters(double blockX, double blockZ, double worldScale) {
      if (!era.iceSheets()) {
         return 0.0;
      }
      return IceSheets.shared().meters(EarthProjection.blockZToLat(blockZ, worldScale), EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale)));
   }

   /**
    * Lake level (metres relative to today's sea) at a block; NaN when the era has no lakes or outside every basin. The terrain
    * already carries the ice sheet, so water stands only where the ice surface is below the level: the dam is the ice itself.
    */
   public static double lakeLevelMeters(double blockX, double blockZ, double worldScale) {
      if (!era.lakes()) {
         return Double.NaN;
      }
      return EraLakes.shared().levelMeters(EarthProjection.blockZToLat(blockZ, worldScale), EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale)));
   }

   public static int adjustCover(int cover, double blockX, double blockZ, double worldScale) {
      EraSettings e = era;
      if (!e.active()) {
         return cover;
      }
      double lat = EarthProjection.blockZToLat(blockZ, worldScale);
      double lon = EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale));
      IslandOverlay isl = island(e);
      double alpha = isl == null ? 0.0 : isl.alpha(lat, lon);
      double islRel = alpha > 0.0 ? isl.relativeMeters(lat, lon) : Double.NaN;
      double ice = e.iceSheets() ? IceSheets.shared().meters(lat, lon) : 0.0;
      double lake = e.lakes() ? EraLakes.shared().levelMeters(lat, lon) : Double.NaN;
      boolean needsReal = alpha < 0.5 && (cover == EraCover.NO_DATA || cover == EraCover.WATER || ice > 0.0 || !Double.isNaN(lake)
         || (e.ice() && EraCover.inHighlandsBox(lat, lon)));
      double rel = Double.NaN;
      ElevationProbe p = probe;
      if (needsReal && p != null) {
         rel = p.relativeMeters(blockX, blockZ, worldScale);
      }
      int c = EraCover.remap(cover, rel, islRel, alpha, lat, lon, e);
      if (e.vegetation() && alpha < 0.5) {
         c = EraCover.withVegetation(c, vegetationClass(blockX, blockZ, worldScale));
      }
      if (e.ice() && c == EraCover.TREE && p != null) {
         c = EraCover.belowTreeline(c, Double.isNaN(rel) ? p.relativeMeters(blockX, blockZ, worldScale) : rel, lat);
      }
      c = EraCover.withIceSheet(c, rel, ice);
      return EraCover.underLake(c, rel, Double.isNaN(lake) ? Double.NaN : EraMath.relativeMeters(lake, e));
   }

   /** TRUE where the island is land, FALSE where the island owns the pixel and it is sea, null when the era has no opinion. */
   public static Boolean landMaskOverride(double blockX, double blockZ, double worldScale) {
      EraSettings e = era;
      IslandOverlay isl = island(e);
      if (isl == null) {
         return null;
      }
      double lat = EarthProjection.blockZToLat(blockZ, worldScale);
      double lon = EarthProjection.blockLongitude(blockX, blockZ, EarthProjection.blocksPerDegree(worldScale));
      if (isl.alpha(lat, lon) < 0.5) {
         return null;
      }
      return isl.relativeMeters(lat, lon) > 0.0;
   }

   /**
    * Whether an era world skips a structure. With structure_filter on, exactly the datapack deny list (tag tellus:era_denied,
    * passed in as {@code denied}) is skipped, so natural ones from any mod stay. Otherwise an era world carries no structures
    * from other mods (the vanilla add_* flags already gate the vanilla ones).
    */
   public static boolean blocksStructure(String namespace, boolean denied) {
      EraSettings e = era;
      return e.structureFilter() ? denied : e.active() && !"minecraft".equals(namespace);
   }

   public static double compressHeightBlocks(double blocks) {
      return era.heightCompress() ? EraMath.compressBlocks(blocks) : blocks;
   }
}
