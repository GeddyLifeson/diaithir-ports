package com.ldtteam.domumornamentum.block.types;

import net.minecraft.util.StringRepresentable;
import org.apache.commons.lang3.StringUtils;
import org.jspecify.annotations.NonNull;

import java.util.Arrays;
import java.util.stream.Collectors;

public enum FancyDoorType implements StringRepresentable
{
    FULL("full"),
    CREEPER("creeper");

    private final String serializationName;

    FancyDoorType(final String serializationName) {this.serializationName = serializationName;}

    @Override
    public @NonNull String getSerializedName()
    {
        return serializationName;
    }

    public String getTranslationKeySuffix() {
        return getSerializedName().replace("_", ".");
    }

    public String getDefaultEnglishTranslation() {
        final String[] parts = getSerializedName().split("_");
        return Arrays.stream(parts)
          .map(StringUtils::capitalize)
          .collect(Collectors.joining(" "));
    }
}
