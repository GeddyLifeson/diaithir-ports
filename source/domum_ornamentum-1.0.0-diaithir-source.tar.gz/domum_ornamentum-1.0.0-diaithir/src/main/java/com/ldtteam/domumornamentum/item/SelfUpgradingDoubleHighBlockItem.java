package com.ldtteam.domumornamentum.item;

import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;

/**
 * BlockItem with own DFU on tag load/set
 */
public class SelfUpgradingDoubleHighBlockItem extends DoubleHighBlockItem
{
    public SelfUpgradingDoubleHighBlockItem(final Block block, final Properties properties)
    {
        super(block, properties);
    }

    // TODO(26.1): Item#verifyComponentsAfterLoad was removed in NeoForge 26.1.
    // Wire SelfUpgradingBlockItem.upgrade() to a new item-load hook once decided.
}