package com.ldtteam.domumornamentum.client.screens;

import com.ldtteam.domumornamentum.DomumOrnamentum;
import com.ldtteam.domumornamentum.block.IMateriallyTexturedBlock;
import com.ldtteam.domumornamentum.block.IMateriallyTexturedBlockComponent;
import com.ldtteam.domumornamentum.block.ModBlocks;
import com.ldtteam.domumornamentum.client.model.data.MaterialTextureData;
import com.ldtteam.domumornamentum.container.ArchitectsCutterContainer;
import com.ldtteam.domumornamentum.item.interfaces.IDoItem;
import com.ldtteam.domumornamentum.util.Constants;
import com.mojang.blaze3d.platform.cursor.CursorTypes;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import org.jspecify.annotations.NonNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.ldtteam.domumornamentum.util.GuiConstants.*;

public class ArchitectsCutterScreen extends AbstractContainerScreen<ArchitectsCutterContainer>
{
    private static final Identifier BACKGROUND_TEXTURE1 = Constants.resLocDO("textures/gui/container/architectscutter.png");
    private static final Identifier BACKGROUND_TEXTURE2 = Constants.resLocDO("textures/gui/container/architectscutter2.png");
    private static final Identifier SCROLLER_SPRITE = Identifier.withDefaultNamespace("container/stonecutter/scroller");
    private static final Identifier SCROLLER_DISABLED_SPRITE = Identifier.withDefaultNamespace("container/stonecutter/scroller_disabled");
    private static final Identifier RECIPE_SELECTED_SPRITE = Identifier.withDefaultNamespace("container/stonecutter/recipe_selected");
    private static final Identifier RECIPE_HIGHLIGHTED_SPRITE = Identifier.withDefaultNamespace("container/stonecutter/recipe_highlighted");
    private static final Identifier RECIPE_SPRITE = Identifier.withDefaultNamespace("container/stonecutter/recipe");

    private float recipeSliderProgress;
    private boolean clickedOnRecipeScroll;
    private int recipeIndexOffset;
    private float typeSliderProgress;
    private boolean clickedOnTypeScroll;
    private int typeIndexOffset;

    private static int groupIndexCache = 0;
    private static int variantIndexCache = -1;

    public ArchitectsCutterScreen(ArchitectsCutterContainer containerIn, Inventory playerInv, Component titleIn) {
        super(containerIn, playerInv, titleIn, CUTTER_BG_W, CUTTER_BG_H);
        --this.titleLabelY;
    }

    @Override
    public void extractBackground(final @NonNull GuiGraphicsExtractor graphics, final int mouseX, final int mouseY, final float partialTicks) {
        super.extractBackground(graphics, mouseX, mouseY, partialTicks);
        int guiLeft = this.leftPos;
        int guiTop = this.topPos;

        graphics.blit(RenderPipelines.GUI_TEXTURED, getBackGroundTexture(), guiLeft, guiTop, 0.0F, 0.0F, this.imageWidth, this.imageHeight, 256, 256);

        if (this.menu.getCurrentGroup() == null)
        {
            (this.menu).clickMenuButton(Objects.requireNonNull(Objects.requireNonNull(this.minecraft).player), groupIndexCache);
            Objects.requireNonNull(this.minecraft.gameMode).handleInventoryButtonClick(this.menu.containerId, groupIndexCache);
        }

        if (this.menu.getCurrentGroup() != null && this.menu.getCurrentVariant() == null)
        {
            if (variantIndexCache == -1)
            {
                variantIndexCache = ModBlocks.getInstance().itemGroups.size();
            }
            (this.menu).clickMenuButton(Objects.requireNonNull(Objects.requireNonNull(this.minecraft).player), variantIndexCache);
            Objects.requireNonNull(this.minecraft.gameMode).handleInventoryButtonClick(this.menu.containerId, variantIndexCache);
        }

        if (this.menu.getCurrentGroup() != null)
        {
            int sliderOffset1 = (int) (5.0F * this.recipeSliderProgress);
            Identifier sprite = this.canScrollRecipes() ? SCROLLER_SPRITE : SCROLLER_DISABLED_SPRITE;
            graphics.blitSprite(RenderPipelines.GUI_TEXTURED, sprite, guiLeft + CUTTER_SLIDER_X, guiTop + CUTTER_SLIDER_Y + CUTTER_RECIPE_SPACING + sliderOffset1, CUTTER_SLIDER_W, CUTTER_SLIDER_H);
        }

        int sliderOffset2 = (int)(5.0F * this.typeSliderProgress);
        Identifier sprite = this.canScrollTypes() ? SCROLLER_SPRITE : SCROLLER_DISABLED_SPRITE;
        graphics.blitSprite(RenderPipelines.GUI_TEXTURED, sprite, guiLeft + CUTTER_SLIDER_X, guiTop + CUTTER_SLIDER_Y + sliderOffset2, CUTTER_SLIDER_W, CUTTER_SLIDER_H);

        int recipeAreaLeft = this.leftPos + CUTTER_RECIPE_X;
        int recipeAreaTop = this.topPos + CUTTER_RECIPE_Y;

        this.drawSlotBackgrounds(graphics);
        this.drawRecipeButtonBackgrounds(graphics, mouseX, mouseY, recipeAreaLeft, recipeAreaTop);
        this.drawRecipesItems(graphics, recipeAreaLeft, recipeAreaTop);

        // Cursor handling for sliders
        if (this.menu.getCurrentGroup() != null) {
            int scrollerXStart = guiLeft + CUTTER_SLIDER_X;
            int scrollerYStart = guiTop + CUTTER_SLIDER_Y + CUTTER_RECIPE_SPACING;
            if (mouseX >= scrollerXStart && mouseY >= scrollerYStart && mouseX < scrollerXStart + CUTTER_SLIDER_W && mouseY < scrollerYStart + CUTTER_RECIPE_H) {
                if (this.canScrollRecipes()) {
                    graphics.requestCursor(this.clickedOnRecipeScroll ? CursorTypes.RESIZE_NS : CursorTypes.POINTING_HAND);
                } else {
                    graphics.requestCursor(CursorTypes.NOT_ALLOWED);
                }
            }
        }

        int scrollerXStart = guiLeft + CUTTER_SLIDER_X;
        int scrollerYStart = guiTop + CUTTER_SLIDER_Y;
        if (mouseX >= scrollerXStart && mouseY >= scrollerYStart && mouseX < scrollerXStart + CUTTER_SLIDER_W && mouseY < scrollerYStart + CUTTER_RECIPE_H) {
            if (this.canScrollTypes()) {
                graphics.requestCursor(this.clickedOnTypeScroll ? CursorTypes.RESIZE_NS : CursorTypes.POINTING_HAND);
            } else {
                graphics.requestCursor(CursorTypes.NOT_ALLOWED);
            }
        }
    }

    private Identifier getBackGroundTexture()
    {
        return this.menu.getCurrentGroup() == null ? BACKGROUND_TEXTURE1 : BACKGROUND_TEXTURE2;
    }

    private void drawRecipesItems(final GuiGraphicsExtractor graphics, int left, int top) {

        final List<Identifier> typeList = new ArrayList<>(ModBlocks.getInstance().getOrComputeItemGroups().keySet());
        for(int i = this.typeIndexOffset; i < this.typeIndexOffset + 10 && i < typeList.size(); ++i) {
            int j = i - this.typeIndexOffset;
            int k = left + j % 10 * CUTTER_RECIPE_W;
            int l = j / 10;
            int i1 = top + l * CUTTER_RECIPE_H + 2;

            final Identifier type = typeList.get(i);
            if (ModBlocks.getInstance().getOrComputeItemGroups().get(type).isEmpty())
            {
                DomumOrnamentum.LOGGER.error("Empty Item Category: " + type);
                continue;
            }

            graphics.item(ModBlocks.getInstance().getOrComputeItemGroups().get(typeList.get(i)).get(0), k, i1);
        }

        if (this.menu.getCurrentGroup() != null)
        {
            List<ItemStack> list = ModBlocks.getInstance().getOrComputeItemGroups().get(this.menu.getCurrentGroup());
            for (int i = this.recipeIndexOffset; i < this.recipeIndexOffset + 10 && i < list.size(); ++i)
            {
                int j = i - this.recipeIndexOffset;
                int k = left + j % 10 * CUTTER_RECIPE_W;
                int l = j / 10;
                int i1 = top + CUTTER_RECIPE_SPACING + l * CUTTER_RECIPE_H + 2;

                if (this.menu.outputInventorySlot.hasItem())
                {
                    final ItemStack input = list.get(i).copy();
                    texturizeVariantUsingCurrentInput(input);
                    graphics.item(input, k, i1);
                }
                else
                {
                    graphics.item(list.get(i), k, i1);
                }
            }
        }
    }

    private void drawSlotBackgrounds(GuiGraphicsExtractor graphics)
    {
        if (this.menu.getCurrentVariant() != null && this.menu.getCurrentVariant().getItem() instanceof BlockItem item && item.getBlock() instanceof IMateriallyTexturedBlock block)
        {
            final int numComponents = block.getComponents().size();
            final List<Identifier> input = new ArrayList<>();
            if (item instanceof IDoItem doItem)
            {
                input.addAll(doItem.getInputIds());
            }

            for (int i = 0; i < 2; i++)
            {
                int drawLeft = CUTTER_INPUT_X - 1 + this.leftPos;
                int drawTop = this.topPos + CUTTER_INPUT_Y - 1 + i * CUTTER_INPUT_SPACING;
                if (i < input.size())
                {
                    graphics.text(this.font, Component.translatable(input.get(i).getNamespace() + ".desc." + input.get(i).getPath(), Component.translatable(Constants.MOD_ID + ".desc.material", "")), drawLeft - 88, drawTop + 5, 4210752, false);
                }
                graphics.blit(RenderPipelines.GUI_TEXTURED, BACKGROUND_TEXTURE1, drawLeft, drawTop, CUTTER_SLOT_U + (i >= numComponents ? CUTTER_SLOT_W : 0), CUTTER_SLOT_V, CUTTER_SLOT_W, CUTTER_SLOT_H, 256, 256);
            }
        }
    }

    private void drawRecipeButtonBackgrounds(GuiGraphicsExtractor graphics, int x, int y, int recipeAreaLeft, int recipeAreaTop) {

        final List<Identifier> groups = new ArrayList<>(ModBlocks.getInstance().getOrComputeItemGroups().keySet());
        for(int i = this.typeIndexOffset; i < this.typeIndexOffset + 10 && i < groups.size(); ++i) {
            int drawIndex = i - this.typeIndexOffset;
            int drawLeft = recipeAreaLeft + drawIndex % 10 * CUTTER_RECIPE_W;
            int rowIndex = drawIndex / 10;
            int drawTop = recipeAreaTop + rowIndex * CUTTER_RECIPE_H + 2;
            Identifier sprite;
            if (this.menu.getCurrentGroup() != null && i == groups.indexOf(this.menu.getCurrentGroup())) {
                sprite = RECIPE_SELECTED_SPRITE;
            } else if (x >= drawLeft && y >= drawTop && x < drawLeft + CUTTER_RECIPE_W && y < drawTop + CUTTER_RECIPE_H) {
                sprite = RECIPE_HIGHLIGHTED_SPRITE;
            } else {
                sprite = RECIPE_SPRITE;
            }

            graphics.blitSprite(RenderPipelines.GUI_TEXTURED, sprite, drawLeft, drawTop - 1, CUTTER_RECIPE_W, CUTTER_RECIPE_H);
            if (x >= drawLeft && y >= drawTop - 1 && x < drawLeft + CUTTER_RECIPE_W && y < drawTop - 1 + CUTTER_RECIPE_H) {
                graphics.requestCursor(CursorTypes.POINTING_HAND);
            }
        }

        if (this.menu.getCurrentGroup() != null)
        {
            List<ItemStack> list = ModBlocks.getInstance().getOrComputeItemGroups().get(this.menu.getCurrentGroup());
            for (int i = this.recipeIndexOffset; i < recipeIndexOffset + 10 && i < list.size(); ++i)
            {
                int drawIndex = i - this.recipeIndexOffset;
                int drawLeft = recipeAreaLeft + drawIndex % 10 * CUTTER_RECIPE_W;
                int rowIndex = drawIndex / 10;
                int drawTop = recipeAreaTop + CUTTER_RECIPE_SPACING + rowIndex * CUTTER_RECIPE_H + 2;
                Identifier sprite;
                if (this.menu.getCurrentVariant() != null && i == list.indexOf(this.menu.getCurrentVariant())) {
                    sprite = RECIPE_SELECTED_SPRITE;
                } else if (x >= drawLeft && y >= drawTop && x < drawLeft + CUTTER_RECIPE_W && y < drawTop + CUTTER_RECIPE_H) {
                    sprite = RECIPE_HIGHLIGHTED_SPRITE;
                } else {
                    sprite = RECIPE_SPRITE;
                }

                graphics.blitSprite(RenderPipelines.GUI_TEXTURED, sprite, drawLeft, drawTop - 1, CUTTER_RECIPE_W, CUTTER_RECIPE_H);
                if (x >= drawLeft && y >= drawTop - 1 && x < drawLeft + CUTTER_RECIPE_W && y < drawTop - 1 + CUTTER_RECIPE_H) {
                    graphics.requestCursor(CursorTypes.POINTING_HAND);
                }
            }
        }
    }

    @Override
    protected void extractTooltip(final @NonNull GuiGraphicsExtractor graphics, final int mouseX, final int mouseY) {
        super.extractTooltip(graphics, mouseX, mouseY);
        {
            int i = this.leftPos + CUTTER_RECIPE_X;
            int j = this.topPos + CUTTER_RECIPE_Y;
            int k = this.typeIndexOffset + 10;
            final List<Identifier> list = new ArrayList<>(ModBlocks.getInstance().getOrComputeItemGroups().keySet());
            for (int l = this.typeIndexOffset; l < k && l < list.size(); ++l)
            {
                int i1 = l - this.typeIndexOffset;
                int j1 = i + i1 % 10 * CUTTER_RECIPE_W;
                int k1 = j + i1 / 10 * CUTTER_RECIPE_H + 2;
                if (mouseX >= j1 && mouseX < j1 + CUTTER_RECIPE_W && mouseY >= k1 && mouseY < k1 + CUTTER_RECIPE_H)
                {
                    graphics.setTooltipForNextFrame(this.font, Component.translatable("cuttergroup." + list.get(l).getNamespace() + "." + list.get(l).getPath()), mouseX, mouseY);
                }
            }
        }

        if (this.menu.getCurrentGroup() != null)
        {
            List<ItemStack> list = ModBlocks.getInstance().getOrComputeItemGroups().get(this.menu.getCurrentGroup());
            int i = this.leftPos + CUTTER_RECIPE_X;
            int j = this.topPos + CUTTER_RECIPE_Y + CUTTER_RECIPE_SPACING;
            int k = this.recipeIndexOffset + 10;

            for(int l = this.recipeIndexOffset; l < k && l < list.size(); ++l) {
                int i1 = l - this.recipeIndexOffset;
                int j1 = i + i1 % 10 * CUTTER_RECIPE_W;
                int k1 = j + i1 / 10 * CUTTER_RECIPE_H + 2;
                if (mouseX >= j1 && mouseX < j1 + CUTTER_RECIPE_W && mouseY >= k1 && mouseY < k1 + CUTTER_RECIPE_H) {
                    final ItemStack stack;
                    if (this.menu.outputInventorySlot.hasItem())
                    {
                        final ItemStack input = list.get(l).copy();
                        texturizeVariantUsingCurrentInput(input);
                        stack = input;
                    }
                    else
                    {
                        stack = list.get(l);
                    }
                    graphics.setTooltipForNextFrame(this.font, stack, mouseX, mouseY);
                }
            }
        }
    }

    private void texturizeVariantUsingCurrentInput(final ItemStack variantItemStack)
    {
        if (!(variantItemStack.getItem() instanceof final BlockItem bi && bi.getBlock() instanceof final IMateriallyTexturedBlock block))
        {
            return;
        }

        final MaterialTextureData.Builder textureData = MaterialTextureData.builder();
        int i = 0;
        for (final IMateriallyTexturedBlockComponent component : block.getComponents())
        {
            if (this.menu.inputInventory.getItem(i).getItem() instanceof final BlockItem blockItem)
            {
                textureData.setComponent(component.getId(), blockItem.getBlock());
            }
            i++;
        }
        textureData.writeToItemStack(variantItemStack);
    }

    @Override
    public boolean mouseClicked(final @NonNull MouseButtonEvent event, final boolean doubleClick) {
        this.clickedOnRecipeScroll = false;
        this.clickedOnTypeScroll = false;

        if (this.menu.getCurrentGroup() != null) {
            int leftOffset = this.leftPos + CUTTER_RECIPE_X + 1;
            int topOffset = this.topPos + CUTTER_RECIPE_Y + CUTTER_RECIPE_SPACING;
            int scrollOffset = this.recipeIndexOffset + 10;

            for(int index = this.recipeIndexOffset; index < scrollOffset; ++index) {
                int rowIndex = index - this.recipeIndexOffset;
                double mouseXOffset = event.x() - (double)(leftOffset + rowIndex % 10 * CUTTER_RECIPE_W);
                double mouseYOffset = event.y() - (double)(topOffset + rowIndex / 10 * CUTTER_RECIPE_H);
                if (mouseXOffset >= 0.0D && mouseYOffset >= 0.0D && mouseXOffset < CUTTER_RECIPE_W && mouseYOffset < CUTTER_RECIPE_H && (this.menu).clickMenuButton(Objects.requireNonNull(Objects.requireNonNull(this.minecraft).player), index + ModBlocks.getInstance().itemGroups.size())) {
                    Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_STONECUTTER_SELECT_RECIPE, 1.0F));
                    Objects.requireNonNull(this.minecraft.gameMode).handleInventoryButtonClick(this.menu.containerId, index + ModBlocks.getInstance().itemGroups.size());
                    variantIndexCache = index + ModBlocks.getInstance().itemGroups.size();
                    return true;
                }
            }

            leftOffset = this.leftPos + CUTTER_SLIDER_X;
            if (event.x() >= (double)leftOffset && event.x() < (double)(leftOffset + CUTTER_SLIDER_W) && event.y() >= (double)topOffset && event.y() < (double)(topOffset + CUTTER_RECIPE_H)) {
                this.clickedOnRecipeScroll = true;
            }
        }

        if (!clickedOnRecipeScroll)
        {
            int leftOffset = this.leftPos + CUTTER_RECIPE_X + 1;
            int topOffset = this.topPos + CUTTER_RECIPE_Y;
            int scrollOffset = this.typeIndexOffset + 10;

            for(int index = this.typeIndexOffset; index < scrollOffset; ++index) {
                int rowIndex = index - this.typeIndexOffset;
                double mouseXOffset = event.x() - (double)(leftOffset + rowIndex % 10 * CUTTER_RECIPE_W);
                double mouseYOffset = event.y() - (double)(topOffset + rowIndex / 10 * CUTTER_RECIPE_H);
                if (mouseXOffset >= 0.0D && mouseYOffset >= 0.0D && mouseXOffset < CUTTER_RECIPE_W && mouseYOffset < CUTTER_RECIPE_H && (this.menu).clickMenuButton(Objects.requireNonNull(Objects.requireNonNull(this.minecraft).player), index)) {
                    Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_STONECUTTER_SELECT_RECIPE, 1.0F));
                    Objects.requireNonNull(this.minecraft.gameMode).handleInventoryButtonClick(this.menu.containerId, index);
                    groupIndexCache = index;
                    recipeIndexOffset = 0;
                    recipeSliderProgress = 0;
                    return true;
                }
            }

            leftOffset = this.leftPos + CUTTER_SLIDER_X;
            if (event.x() >= (double)leftOffset && event.x() < (double)(leftOffset + CUTTER_SLIDER_W) && event.y() >= (double)topOffset && event.y() < (double)(topOffset + CUTTER_RECIPE_H)) {
                this.clickedOnTypeScroll = true;
            }
        }

        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(final @NonNull MouseButtonEvent event, final double dragX, final double dragY) {
        if (this.clickedOnRecipeScroll && this.canScrollRecipes()) {
            int i = this.topPos + CUTTER_RECIPE_Y + CUTTER_RECIPE_SPACING;
            int j = i + 10;
            this.recipeSliderProgress = ((float)event.y() - (float)i - 7.5F) / ((float)(j - i) - 5.0F);
            this.recipeSliderProgress = Mth.clamp(this.recipeSliderProgress, 0.0F, 1.0F);
            this.recipeIndexOffset = (int)((double)(this.recipeSliderProgress * (float)this.getHiddenRecipeRows()) + 0.5D) * 10;
            return true;
        }
        else if (this.clickedOnTypeScroll && this.canScrollTypes()) {
            int i = this.topPos + CUTTER_RECIPE_Y;
            int j = i + 10;
            this.typeSliderProgress = ((float)event.y() - (float)i - 7.5F) / ((float)(j - i) - 5.0F);
            this.typeSliderProgress = Mth.clamp(this.typeSliderProgress, 0.0F, 1.0F);
            this.typeIndexOffset = (int)((double)(this.typeSliderProgress * (float)this.getHiddenTypeRows()) + 0.5D) * 10;
            return true;
        } else {
            return super.mouseDragged(event, dragX, dragY);
        }
    }

    @Override
    public boolean mouseReleased(final @NonNull MouseButtonEvent event) {
        this.clickedOnRecipeScroll = false;
        this.clickedOnTypeScroll = false;
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(final double x, final double y, final double scrollX, final double scrollY) {

        boolean onlyTypes = false;
        if (x >= this.leftPos + 55 && y >= this.topPos + 15 && x < this.leftPos + CUTTER_SLIDER_X && y < this.topPos + 35) {
            onlyTypes = true;
        }

        boolean onlyRecipes = false;
        if (x >= this.leftPos + 55 && y >= this.topPos + 40 && x < this.leftPos + CUTTER_SLIDER_X && y < this.topPos + 60) {
            onlyRecipes = true;
        }

        if (this.canScrollRecipes() && !onlyTypes) {
            int i = this.getHiddenRecipeRows();
            this.recipeSliderProgress = (float)((double)this.recipeSliderProgress - scrollY / (double)i);
            this.recipeSliderProgress = Mth.clamp(this.recipeSliderProgress, 0.0F, 1.0F);
            this.recipeIndexOffset = (int)((double)(this.recipeSliderProgress * (float)i) + 0.5D) * 10;
        }

        if (this.canScrollTypes() && !onlyRecipes) {
            int i = this.getHiddenTypeRows();
            this.typeSliderProgress = (float)((double)this.typeSliderProgress - scrollY / (double)i);
            this.typeSliderProgress = Mth.clamp(this.typeSliderProgress, 0.0F, 1.0F);
            this.typeIndexOffset = (int)((double)(this.typeSliderProgress * (float)i) + 0.5D) * 10;
        }

        return true;
    }

    private boolean canScrollRecipes() {
        return this.menu.getCurrentGroup() != null && ModBlocks.getInstance().getOrComputeItemGroups().get(this.menu.getCurrentGroup()).size() > 10;
    }

    private boolean canScrollTypes() {
        return ModBlocks.getInstance().getOrComputeItemGroups().size() > 10;
    }

    protected int getHiddenRecipeRows() {
        return this.menu.getCurrentGroup() == null ? 0 : (ModBlocks.getInstance().getOrComputeItemGroups().get(this.menu.getCurrentGroup()).size() + 10 - 1) / 10 - 1;
    }

    protected int getHiddenTypeRows() {
        return (ModBlocks.getInstance().getOrComputeItemGroups().size() + 10 - 1) / 10 - 1;
    }
}
