package com.ldtteam.domumornamentum.recipe.architectscutter;

import com.ldtteam.domumornamentum.IDomumOrnamentumApi;
import com.ldtteam.domumornamentum.block.IMateriallyTexturedBlock;
import com.ldtteam.domumornamentum.client.model.data.MaterialTextureData;
import com.ldtteam.domumornamentum.util.DataComponentPatchBuilder;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementRequirements;
import net.minecraft.advancements.AdvancementRewards;
import net.minecraft.advancements.Criterion;
import net.minecraft.advancements.criterion.RecipeUnlockedTrigger;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.recipes.RecipeBuilder;
import net.minecraft.data.recipes.RecipeCategory;
import net.minecraft.data.recipes.RecipeOutput;
import net.minecraft.data.recipes.packs.VanillaRecipeProvider;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.component.BlockItemStateProperties;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.properties.Property;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Inspired by {@link RecipeBuilder}
 */
public class ArchitectsCutterRecipeBuilder
{
    private final RecipeCategory category;
    private final Map<String, Criterion<?>> criteria = new LinkedHashMap<>();

    private final Block result;
    private int count = 1;
    private final DataComponentPatchBuilder components = new DataComponentPatchBuilder();

    /**
     * @param result main result block of recipe
     * @param category recipe category as in {@link VanillaRecipeProvider}
     */
    public <T extends Block & IMateriallyTexturedBlock> ArchitectsCutterRecipeBuilder(final T result, final RecipeCategory category)
    {
        this.result = result;
        this.category = category;
    }

    public <T extends Comparable<T>> ArchitectsCutterRecipeBuilder resultProperty(final Property<T> property, final T value)
    {
        components.update(DataComponents.BLOCK_STATE, BlockItemStateProperties.EMPTY, props -> props.with(property, value));
        return this;
    }

    public ArchitectsCutterRecipeBuilder textureData(final MaterialTextureData textureData)
    {
        if (textureData.isEmpty())
        {
            return this;
        }

        components.set(IDomumOrnamentumApi.getInstance().getMaterialTextureComponentType(), textureData);

        return this;
    }

    public ArchitectsCutterRecipeBuilder count(final int count)
    {
        this.count = count;
        return this;
    }

    public ArchitectsCutterRecipeBuilder unlockedBy(final String criterionId, final Criterion<?> criterion)
    {
        this.criteria.put(criterionId, criterion);
        return this;
    }

    public void save(final RecipeOutput output, final Identifier recipeId)
    {
        final ArchitectsCutterRecipe recipe = new ArchitectsCutterRecipe(BuiltInRegistries.BLOCK.getKey(result),
            count,
            components.build());

        final ResourceKey<Recipe<?>> recipeKey = ResourceKey.create(Registries.RECIPE, recipeId);

        if (criteria.isEmpty())
        {
            output.accept(recipeKey, recipe, null);
            return;
        }

        final Advancement.Builder advancement = output.advancement()
            .addCriterion("has_the_recipe", RecipeUnlockedTrigger.unlocked(recipeKey))
            .rewards(AdvancementRewards.Builder.recipe(recipeKey))
            .requirements(AdvancementRequirements.Strategy.OR);
        this.criteria.forEach(advancement::addCriterion);

        output.accept(recipeKey, recipe, advancement.build(recipeId.withPrefix("recipes/" + category.getFolderName() + "/")));
    }

    public void saveSuffix(final RecipeOutput output, final String suffix)
    {
        save(output, BuiltInRegistries.BLOCK.getKey(result).withSuffix("_" + suffix));
    }

    public void save(final RecipeOutput output, final String name)
    {
        save(output, BuiltInRegistries.BLOCK.getKey(result).withPath(name));
    }

    public void save(final RecipeOutput output)
    {
        save(output, BuiltInRegistries.BLOCK.getKey(result));
    }
}
