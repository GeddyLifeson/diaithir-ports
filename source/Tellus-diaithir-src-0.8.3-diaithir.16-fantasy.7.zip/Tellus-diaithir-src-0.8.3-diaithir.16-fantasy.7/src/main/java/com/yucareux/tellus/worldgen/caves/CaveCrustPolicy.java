package com.yucareux.tellus.worldgen.caves;

import java.util.function.IntBinaryOperator;

/**
 * Keeps solid rock between caves and open air on steep faces and summits. Caves are mapped from vanilla's 190-block
 * column onto the whole Tellus column, so under an Alpine peak a vanilla cave is about 17 times taller and, where a
 * cliff cuts through it, opens as a slot hundreds of blocks high. Caves stay where the ground is gentle (entrances
 * included) and deep under everything.
 */
public final class CaveCrustPolicy {
   /** Horizontal reach of the crust: no cave comes within this many blocks of lower open ground. */
   public static final int RADIUS = 12;
   /** Surface drop within the radius that counts as a cliff face or steep slope. */
   public static final int STEEP_DROP = 6;
   /** Rock kept above any cave below the nearest lower ground. */
   public static final int COVER = 6;
   /** Height above sea level (blocks) from which a column counts as a summit. */
   public static final int SUMMIT_BLOCKS = 400;
   /** Rock kept above any cave under a summit surface. */
   public static final int SUMMIT_CRUST = 64;

   private CaveCrustPolicy() {
   }

   /** Highest Y a cave may reach in this column, or {@link Integer#MAX_VALUE} when the ground here is gentle. */
   public static int crustTopY(int surfaceY, int lowestNearbySurfaceY, int seaLevel) {
      boolean steep = surfaceY - lowestNearbySurfaceY > STEEP_DROP;
      boolean summit = (long)surfaceY - seaLevel > SUMMIT_BLOCKS;
      if (!steep && !summit) {
         return Integer.MAX_VALUE;
      }
      int top = Math.min(surfaceY, lowestNearbySurfaceY) - COVER;
      return summit ? Math.min(top, surfaceY - SUMMIT_CRUST) : top;
   }

   /** One entry per column of the chunk (z * 16 + x). */
   public static int[] crustTopYByColumn(
      IntBinaryOperator surfaceHeightSampler, int chunkMinX, int chunkMinZ, int[] surfaceYByColumn, int seaLevel
   ) {
      int side = 16 + RADIUS * 2;
      int[] sampled = new int[side * side];
      for (int z = 0; z < side; z++) {
         for (int x = 0; x < side; x++) {
            sampled[z * side + x] = surfaceHeightSampler.applyAsInt(chunkMinX + x - RADIUS, chunkMinZ + z - RADIUS);
         }
      }
      // lowest ground within the radius, separable: rows first, then columns
      int[] rowMin = new int[side * 16];
      for (int z = 0; z < side; z++) {
         for (int lx = 0; lx < 16; lx++) {
            int m = Integer.MAX_VALUE;
            for (int dx = 0; dx <= RADIUS * 2; dx++) {
               m = Math.min(m, sampled[z * side + lx + dx]);
            }
            rowMin[z * 16 + lx] = m;
         }
      }
      int[] result = new int[256];
      for (int lz = 0; lz < 16; lz++) {
         for (int lx = 0; lx < 16; lx++) {
            int m = Integer.MAX_VALUE;
            for (int dz = 0; dz <= RADIUS * 2; dz++) {
               m = Math.min(m, rowMin[(lz + dz) * 16 + lx]);
            }
            int index = lz * 16 + lx;
            result[index] = crustTopY(surfaceYByColumn[index], m, seaLevel);
         }
      }
      return result;
   }
}
