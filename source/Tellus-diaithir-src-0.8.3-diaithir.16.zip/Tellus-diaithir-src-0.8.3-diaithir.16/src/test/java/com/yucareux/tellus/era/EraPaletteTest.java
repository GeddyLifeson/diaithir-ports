package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.Test;

class EraPaletteTest {
   /** era_palette_golden.csv is written by world/earth/biome/palette/golden.py from the Python mirror; every row must pick the same rule. */
   @Test
   void javaMatchesPythonMirror() throws Exception {
      EraPalette pal = EraPalette.shared();
      int rows = 0, matched = 0;
      try (BufferedReader r = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("/era_palette_golden.csv"), StandardCharsets.UTF_8))) {
         r.readLine();
         String line;
         while ((line = r.readLine()) != null) {
            String[] f = line.split(",");
            int cls = Integer.parseInt(f[0]), cover = Integer.parseInt(f[1]);
            double lat = Double.parseDouble(f[2]), lon = Double.parseDouble(f[3]), rel = Double.parseDouble(f[4]);
            double relief = Double.parseDouble(f[5]);
            boolean coast = f[6].equals("1");
            double bx = Double.parseDouble(f[7]), bz = Double.parseDouble(f[8]);
            int want = Integer.parseInt(f[9]);
            double[] c = pal.climateAt(lat, lon);
            assertEquals(Double.parseDouble(f[10]), c[0], 1e-9, line);
            assertEquals(Double.parseDouble(f[11]), c[3], 1e-9, line);
            int got = pal.chooseRule(cls, cover, lat, lon, c, rel, bx, bz, new EraPalette.Column() {
               public double relief() { return relief; }
               public boolean coast() { return coast; }
            });
            assertEquals(want, got, line);
            rows++;
            if (got >= 0) {
               matched++;
            }
         }
      }
      assertTrue(rows >= 4000 && matched > 2500);
   }

   /** era_site_golden.csv: points in and around the mythic sites (and elsewhere) with a fixed column; the rule index includes the site packing. */
   @Test
   void sitesMatchPythonMirror() throws Exception {
      EraPalette pal = EraPalette.shared();
      double[] climate = {10.0, 0.0, 20.0, 800.0, 100.0};
      EraPalette.Column flat = new EraPalette.Column() {
         public double relief() { return 0.0; }
         public boolean coast() { return false; }
      };
      int rows = 0, inSite = 0;
      try (BufferedReader r = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("/era_site_golden.csv"), StandardCharsets.UTF_8))) {
         r.readLine();
         String line;
         while ((line = r.readLine()) != null) {
            String[] f = line.split(",");
            int got = pal.chooseRule(4, 10, Double.parseDouble(f[0]), Double.parseDouble(f[1]), climate, 0.0, Double.parseDouble(f[2]), Double.parseDouble(f[3]), flat);
            assertEquals(Integer.parseInt(f[4]), got, line);
            rows++;
            if (got >= EraPalette.SITE_BASE) {
               inSite++;
            }
         }
      }
      assertTrue(rows >= 3000 && inSite > 500, rows + " rows, " + inSite + " in sites");
   }

   /** era_cave_golden.csv: cave rule index for points around the sites and the world. */
   @Test
   void cavesMatchPythonMirror() throws Exception {
      EraPalette pal = EraPalette.shared();
      int rows = 0, hits = 0;
      try (BufferedReader r = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("/era_cave_golden.csv"), StandardCharsets.UTF_8))) {
         r.readLine();
         String line;
         while ((line = r.readLine()) != null) {
            String[] f = line.split(",");
            int got = pal.caveRule(Double.parseDouble(f[0]), Double.parseDouble(f[1]), Double.parseDouble(f[2]), Double.parseDouble(f[3]),
               Double.parseDouble(f[4]), Double.parseDouble(f[5]), f[6]);
            assertEquals(Integer.parseInt(f[7]), got, line);
            rows++;
            if (got >= 0) {
               hits++;
            }
         }
      }
      assertTrue(rows >= 4000 && hits > 200, rows + " rows, " + hits + " hits");
   }

   @Test
   void everyRuleBiomeHasANamespace() {
      for (String id : EraPalette.shared().biomeIds()) {
         assertTrue(id.contains(":"), id);
      }
   }

   @Test
   void beltsFollowTheTreeline() {
      assertEquals(0, EraPalette.belt(50.0, 0.0));
      assertEquals(4, EraPalette.belt(3500.0, 0.0));
      assertEquals(4, EraPalette.belt(1200.0, 45.0));
   }
}
