package com.yucareux.tellus.worldgen;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class EraWaterGateTest {
   @Test
   void todaysOceanPolygonsAreDryWhereTheEraTerrainStandsAboveTheEraSea() {
      assertTrue(WaterSurfaceResolver.eraDryLand(129, 64, true));   // Dogger Bank (Age I) or the island (Shardfall, no sea shift): ocean polygon, but above the era sea
      assertFalse(WaterSurfaceResolver.eraDryLand(10, 64, true));   // genuinely below the old sea: stays water
      assertFalse(WaterSurfaceResolver.eraDryLand(129, 64, false));  // stock worlds never change
   }
}
