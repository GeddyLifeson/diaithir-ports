package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.assertFalse;

import com.yucareux.tellus.compat.MinecraftVersionCompat;
import java.util.List;
import org.junit.jupiter.api.Test;

class NoFutureBiomesTest {
   @Test
   void the261BuildNeverSelectsA262OnlyBiome() {
      assertFalse(MinecraftVersionCompat.defaultRandomBiomeIds().contains("sulfur_caves"));
      assertFalse(MinecraftVersionCompat.normalizeRandomBiomeSelection(List.of("plains", "sulfur_caves")).contains("sulfur_caves"));
   }
}
