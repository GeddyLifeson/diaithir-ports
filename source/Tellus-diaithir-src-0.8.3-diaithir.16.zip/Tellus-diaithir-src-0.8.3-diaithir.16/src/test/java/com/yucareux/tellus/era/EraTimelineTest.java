package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

class EraTimelineTest {
   private static final EraTimeline T = new EraTimeline(new int[] {0, 1000, 2000}, new double[] {-100.0, -60.0, 0.0});

   @AfterEach
   void reset() {
      EraRuntime.install(EraSettings.NONE);
      EraRuntime.setYear(Integer.MIN_VALUE);
   }

   @Test
   void interpolatesAndHoldsAtTheEnds() {
      assertEquals(-100.0, T.seaMeters(-5), 1e-9);
      assertEquals(-80.0, T.seaMeters(500), 1e-9);
      assertEquals(-30.0, T.seaMeters(1500), 1e-9);
      assertEquals(0.0, T.seaMeters(9000), 1e-9);
   }

   @Test
   void floodIsWholeBlocksAboveTheDatumAndNeverNegative() {
      assertEquals(0, T.floodBlocks(0, -100.0, 5.0));
      assertEquals(8, T.floodBlocks(1000, -100.0, 5.0));
      assertEquals(20, T.floodBlocks(2000, -100.0, 5.0));
      assertEquals(0, T.floodBlocks(0, -80.0, 5.0));
   }

   @Test
   void keyframesMustRise() {
      assertThrows(IllegalArgumentException.class, () -> new EraTimeline(new int[] {5, 5}, new double[] {0, 1}));
   }

   @Test
   void bundledTimelineStartsAtTheAgeOneDatum() {
      EraTimeline t = EraTimeline.shared();
      assertEquals(-100.0, t.seaMeters(53), 1e-9);
      assertEquals(13, t.floodBlocks(5373, -100.0, 5.0));
   }

   @Test
   void runtimeFloodNeedsAnActiveEraAndAYear() {
      assertEquals(0, EraRuntime.floodBlocks(5.0));
      EraRuntime.install(new EraSettings(-100.0, true, false, true, true, true, true, true));
      assertEquals(0, EraRuntime.floodBlocks(5.0));
      EraRuntime.setYear(5373);
      assertEquals(13, EraRuntime.floodBlocks(5.0));
   }

   @Test
   void slicesBracketTheYear() {
      assertEquals(14873 - 14873, EraTimeline.calBp(14873));
      double[] before = EraTimeline.bracket(0);       // 14.87 ka
      assertEquals(15.0, before[0], 0.0);
      assertEquals(14.0, before[1], 0.0);
      assertEquals(0.13, before[2], 0.01);
      double[] mid = EraTimeline.bracket(14873 - 12500);    // 12.5 ka
      assertEquals(13.0, mid[0], 0.0);
      assertEquals(12.0, mid[1], 0.0);
      assertEquals(0.5, mid[2], 1e-9);
      assertEquals(0.0, EraTimeline.bracket(14873 + 50)[0], 0.0);   // after the last slice
      assertEquals(8.0, EraTimeline.bracket(14873 - 7500)[0], 0.0);
      assertEquals(7.0, EraTimeline.bracket(14873 - 7500)[1], 0.0);
      assertEquals(15.0, EraTimeline.bracket(-500)[1], 0.0);           // before the first
   }

   @Test
   void patchesSplitBetweenSlicesByTheFraction() {
      int y = 14873 - 12250;                              // 12.25 ka: three quarters of the way from 13 to 12
      int younger = 0;
      for (int i = 0; i < 1000; i++) {
         younger += EraTimeline.sliceKa(y, i / 1000.0) == 12 ? 1 : 0;
      }
      assertEquals(750, younger, 1);
   }

   @Test
   void runtimeReadsTheBundledSlices() {
      EraRuntime.install(new EraSettings(-100.0, true, false, true, true, true, true, true));
      EraRuntime.setYear(14873 - 12500);
      // Hudson Bay is under ice at 12.5 ka and the Alps have shrunk: the blended slice must load without error
      assertEquals(true, EraVegetation.slice(12).classAt(50.0, 10.0) >= 0);
      assertEquals(true, EraVegetation.slice(13).classAt(50.0, 10.0) >= 0);
      assertEquals(true, IceSheets.slice(12).meters(60.0, -85.0) >= 0.0);
      assertEquals(true, EraPalette.shared().climateAt(50.0, 10.0, 12) != null);
   }

   @Test
   void laterSlicesLoadAndIceEndsAtFiveKa() {
      EraRuntime.install(new EraSettings(-100.0, true, false, true, true, true, true, true));
      for (int ka = 9; ka >= 0; ka--) {
         assertEquals(true, EraVegetation.slice(ka).classAt(50.0, 10.0) >= 0);
         assertEquals(true, EraPalette.shared().climateAt(50.0, 10.0, ka) != null);
      }
      for (int ka = 9; ka >= 6; ka--) {
         assertEquals(true, IceSheets.slice(ka).meters(63.0, -104.0) >= 0.0);
      }
      EraRuntime.setYear(14873 - 4000);
      assertEquals(0.0, EraRuntime.iceMeters(0, 0, 5.0), 0.0);
      EraRuntime.setYear(Integer.MIN_VALUE);
   }

   @Test
   void balticIceLakeDrainsAt11700() {
      double lat = 55.0, lon = 16.0;   // the lake seed, inside the basin mask
      EraRuntime.install(new EraSettings(-100.0, true, false, true, true, true, true, true));
      EraRuntime.setYear(14873 - 12000);
      double standing = EraLakes.shared().levelMeters(lat, lon);
      EraRuntime.setYear(14873 - 11000);
      double drained = EraLakes.shared().levelMeters(lat, lon);
      assertEquals(-16.0, standing, 1e-9);
      assertEquals(true, Double.isNaN(drained));
   }

   @Test
   void cacheKeyFollowsTheYearInSteps() {
      EraSettings e = new EraSettings(-100.0, true, true, true, true, true, true, false);
      EraRuntime.setYear(Integer.MIN_VALUE);
      String unset = e.cacheKey();
      EraRuntime.setYear(1000);
      String a = e.cacheKey();
      EraRuntime.setYear(1100);
      assertEquals(a, e.cacheKey());
      EraRuntime.setYear(1300);
      assertNotEquals(a, e.cacheKey());
      assertNotEquals(unset, a);
      EraRuntime.setYear(Integer.MIN_VALUE);
   }

   @Test
   void iceBlocksComeFromTheRegisteredProbe() {
      EraRuntime.install(new EraSettings(-100.0, true, true, true, true, true, true, false));
      EraRuntime.setIceBlockProbe((x, z) -> x + z);
      assertEquals(7, EraRuntime.iceBlocksAt(3, 4));
      EraRuntime.install(EraSettings.NONE);
      assertEquals(0, EraRuntime.iceBlocksAt(3, 4));
      EraRuntime.setIceBlockProbe(null);
   }

   @Test
   void agassizStandsOnlyBetweenItsDates() {
      double lat = 46.9, lon = -96.8;   // Red River valley at Fargo
      EraRuntime.install(new EraSettings(-100.0, true, false, true, true, true, true, true));
      EraRuntime.setYear(Integer.MIN_VALUE);
      assertEquals(true, Double.isNaN(EraLakes.shared().levelMeters(lat, lon)));
      EraRuntime.setYear(14873 - 14000);
      assertEquals(true, Double.isNaN(EraLakes.shared().levelMeters(lat, lon)));
      EraRuntime.setYear(14873 - 11200);
      assertEquals(335.0, EraLakes.shared().levelMeters(lat, lon), 1e-9);
      EraRuntime.setYear(14873 - 10000);
      assertEquals(299.0, EraLakes.shared().levelMeters(lat, lon), 1e-9);
      EraRuntime.setYear(14873 - 8000);
      assertEquals(true, Double.isNaN(EraLakes.shared().levelMeters(lat, lon)));
      EraRuntime.setYear(Integer.MIN_VALUE);
   }
}
