package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.*;

import com.yucareux.tellus.worldgen.EarthProjection;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

class EraRuntimeTest {
   static final EraSettings AGE1 = new EraSettings(-100.0, true, true, true, false, false, false, false);
   static final double SCALE = 1.0;

   @AfterEach
   void reset() {
      EraRuntime.install(EraSettings.NONE);
      EraRuntime.setElevationProbe(null);
   }

   static double bx(double lon) { return EarthProjection.longitudeToBlockX(lon, SCALE); }
   static double bz(double lat) { return EarthProjection.latToBlockZ(lat, SCALE); }

   @Test
   void projectionRoundTripAtTheSpawn() {
      double x = bx(-10.0145), z = bz(56.982);
      assertEquals(-10.0145, EarthProjection.blockXToLongitude(x, SCALE), 1e-9);
      assertEquals(56.982, EarthProjection.blockZToLat(z, SCALE), 1e-7);
   }

   @Test
   void offIsIdentity() {
      EraRuntime.install(EraSettings.NONE);
      assertEquals(-20.0, EraRuntime.adjustElevation(-20.0, bx(2.5), bz(55.0), SCALE));
      assertEquals(80, EraRuntime.adjustCover(80, bx(2.5), bz(55.0), SCALE));
      assertEquals(1234.0, EraRuntime.compressHeightBlocks(1234.0));
      assertNull(EraRuntime.landMaskOverride(bx(2.5), bz(55.0), SCALE));
   }

   @Test
   void doggerBankIsDry() {
      EraRuntime.install(AGE1);
      assertEquals(80.0, EraRuntime.adjustElevation(-20.0, bx(2.5), bz(55.0), SCALE), 1e-9);
   }

   @Test
   void islandOverridesRealOceanDataAtTheSpawn() {
      EraRuntime.install(AGE1);
      double x = bx(-10.0145), z = bz(56.982);
      double rel = EraRuntime.adjustElevation(-2500.0, x, z, SCALE);      // real data there is deep Atlantic
      assertTrue(rel >= 2.0, "island land wins: " + rel);
      assertEquals(Boolean.TRUE, EraRuntime.landMaskOverride(x, z, SCALE));
   }

   @Test
   void missingRealDataStaysNaNOffIslandAndIsFilledOnIsland() {
      EraRuntime.install(AGE1);
      assertTrue(Double.isNaN(EraRuntime.adjustElevation(Double.NaN, bx(2.5), bz(55.0), SCALE)));
      assertFalse(Double.isNaN(EraRuntime.adjustElevation(Double.NaN, bx(-10.0145), bz(56.982), SCALE)));
   }

   @Test
   void shelfCoverAndHighlandsIce() {
      EraRuntime.install(AGE1);
      EraRuntime.setElevationProbe((x, z, s) -> EraRuntime.adjustElevation(-25.0, x, z, s));
      assertEquals(30, EraRuntime.adjustCover(80, bx(2.5), bz(55.0), SCALE));
      EraRuntime.setElevationProbe((x, z, s) -> EraRuntime.adjustElevation(1345.0, x, z, s));
      assertEquals(70, EraRuntime.adjustCover(60, bx(-5.0036), bz(56.7969), SCALE));
   }

   @Test
   void coverNeedsNoProbeWhenNothingCanChange() {
      EraRuntime.install(AGE1);                                            // no probe installed
      assertEquals(30, EraRuntime.adjustCover(30, bx(10.0), bz(48.0), SCALE));   // inland Germany, class 30: untouched
   }

   static final EraSettings AGE1_ICE = new EraSettings(-100.0, true, false, true, true, false, false, false);

   @Test
   void iceSheetsRaiseTheSurfaceOnlyWhenOn() {
      double x = bx(-104.0), z = bz(63.0);                                  // Keewatin dome
      EraRuntime.install(AGE1);
      assertEquals(400.0, EraRuntime.adjustElevation(300.0, x, z, SCALE), 1e-9);
      assertEquals(0.0, EraRuntime.iceMeters(x, z, SCALE));
      EraRuntime.install(AGE1_ICE);
      double ice = EraRuntime.iceMeters(x, z, SCALE);
      assertTrue(ice > 3000.0, "ice " + ice);
      assertEquals(400.0 + ice, EraRuntime.adjustElevation(300.0, x, z, SCALE), 1e-9);
      assertEquals(-4900.0, EraRuntime.adjustElevation(-5000.0, x, z, SCALE), 1e-9);   // a sheet that would float is left out
      assertEquals(80.0, EraRuntime.adjustElevation(-20.0, bx(2.5), bz(55.0), SCALE), 1e-9);  // Dogger Bank: no ice
   }

   @Test
   void iceSheetCoverIsSnowAndIce() {
      EraRuntime.install(AGE1_ICE);
      EraRuntime.setElevationProbe((x, z, s) -> EraRuntime.adjustElevation(300.0, x, z, s));
      assertEquals(70, EraRuntime.adjustCover(10, bx(-104.0), bz(63.0), SCALE));
      assertEquals(70, EraRuntime.adjustCover(80, bx(-85.0), bz(60.0), SCALE));          // Hudson Bay under the sheet
      assertEquals(10, EraRuntime.adjustCover(10, bx(-87.63), bz(41.88), SCALE));        // Chicago: ice-free
   }

   @Test
   void lakeLevelsOnlyWhenOnAndOnlyInTheBasin() {
      EraRuntime.install(AGE1_ICE);
      assertTrue(Double.isNaN(EraRuntime.lakeLevelMeters(bx(34.0), bz(43.0), SCALE)));
      EraSettings lakes = new EraSettings(-100.0, true, false, true, true, true, false, false);
      EraRuntime.install(lakes);
      assertEquals(-35.0, EraRuntime.lakeLevelMeters(bx(34.0), bz(43.0), SCALE));          // Black Sea
      assertEquals(-16.0, EraRuntime.lakeLevelMeters(bx(16.0), bz(55.0), SCALE));          // Baltic Ice Lake
      assertTrue(Double.isNaN(EraRuntime.lakeLevelMeters(bx(20.0), bz(60.0), SCALE)), "the sheet over the Baltic dams the lake");
      assertTrue(Double.isNaN(EraRuntime.lakeLevelMeters(bx(2.5), bz(55.0), SCALE)));
   }

   @Test
   void lakeColumnsTakeWaterCover() {
      EraRuntime.install(new EraSettings(-100.0, true, false, true, true, true, false, false));
      EraRuntime.setElevationProbe((x, z, s) -> EraRuntime.adjustElevation(-60.0, x, z, s));     // Bornholm basin floor
      assertEquals(80, EraRuntime.adjustCover(80, bx(16.0), bz(55.0), SCALE));                  // under the lake, not grass
      EraRuntime.setElevationProbe((x, z, s) -> EraRuntime.adjustElevation(150.0, x, z, s));     // Chicago's Loop today
      assertEquals(80, EraRuntime.adjustCover(50, bx(-87.63), bz(41.88), SCALE));                // under Lake Chicago
      EraRuntime.setElevationProbe((x, z, s) -> EraRuntime.adjustElevation(-10.0, x, z, s));     // above the Baltic level
      assertEquals(30, EraRuntime.adjustCover(80, bx(16.0), bz(55.0), SCALE));                  // exposed: grass
   }

   @Test
   void outletFillsRaiseTheGroundToTheLakeLevel() {
      EraSettings lakes = new EraSettings(-100.0, true, false, true, true, true, false, false);
      EraRuntime.install(lakes);
      double x = bx(-87.8716), z = bz(41.7473);                                            // Chicago Outlet, Des Plaines gap
      assertEquals(EraMath.relativeMeters(200.0, lakes), EraRuntime.adjustElevation(180.0, x, z, SCALE), 1e-9);
      assertEquals(EraMath.relativeMeters(230.0, lakes), EraRuntime.adjustElevation(230.0, x, z, SCALE), 1e-9);   // higher ground stays
      EraRuntime.install(AGE1_ICE);
      assertEquals(EraMath.relativeMeters(180.0, AGE1_ICE), EraRuntime.adjustElevation(180.0, x, z, SCALE), 1e-9);
   }

   @Test
   void vegetationBiomesOnlyWhenOn() {
      EraRuntime.install(AGE1_ICE);
      assertNull(EraRuntime.vegetationBiome(30, bx(-98.0), bz(38.5), SCALE));
      EraRuntime.install(new EraSettings(-100.0, true, false, true, true, true, true, false));
      assertNotNull(EraRuntime.vegetationBiome(30, bx(-98.0), bz(38.5), SCALE));            // Kansas grassland: a palette pick
      assertEquals("minecraft:desert", EraRuntime.vegetationBiome(60, bx(10.0), bz(23.0), SCALE));    // Sahara
      assertTrue(EraPalette.shared().biomeIds().contains(EraRuntime.vegetationBiome(10, bx(-60.0), bz(-3.0), SCALE)));   // Amazon: some rainforest biome
      assertNull(EraRuntime.vegetationBiome(80, bx(-60.0), bz(-3.0), SCALE));               // water: the stock path
      assertNull(EraRuntime.vegetationBiome(30, bx(-10.0145), bz(56.982), SCALE));          // the island keeps its own
      EraRuntime.setElevationProbe((px, pz, s) -> EraRuntime.adjustElevation(400.0, px, pz, s));
      assertEquals(30, EraRuntime.adjustCover(40, bx(-98.0), bz(38.5), SCALE));             // Kansas fields: grassland
   }

   @Test
   void eraWorldsBlockOtherModsStructuresOnly() {
      assertFalse(EraRuntime.blocksStructure("betterdungeons", true));
      EraRuntime.install(AGE1);
      assertTrue(EraRuntime.blocksStructure("betterdungeons", false));
      assertFalse(EraRuntime.blocksStructure("minecraft", true));
   }

   @Test
   void structureFilterBlocksExactlyTheDenyList() {
      EraRuntime.install(new EraSettings(-100.0, true, false, true, true, true, true, true));
      assertTrue(EraRuntime.blocksStructure("minecraft", true));         // a village
      assertFalse(EraRuntime.blocksStructure("minecraft", false));       // a fossil
      assertFalse(EraRuntime.blocksStructure("cenozoicraft", false));    // a mammoth skeleton
      assertTrue(EraRuntime.blocksStructure("medieval_buildings", true));
   }

   @Test
   void everestFitsUnderTheCeiling() {
      EraRuntime.install(AGE1);
      int y = (int) Math.round(EraRuntime.compressHeightBlocks(8849.0)) + EraMath.HEIGHT_OFFSET;
      assertTrue(y <= EraMath.MAX_Y);
   }
}
