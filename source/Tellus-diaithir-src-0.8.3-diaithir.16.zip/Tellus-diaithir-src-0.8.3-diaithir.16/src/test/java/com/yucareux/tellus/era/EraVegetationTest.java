package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.world.level.biome.Biomes;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class EraVegetationTest {
   static EraVegetation veg;

   @BeforeAll
   static void load() throws Exception {
      veg = EraVegetation.loadFromClasspath();
   }

   @Test
   void fifteenKaClassesAtKnownPlaces() {
      assertEquals(20, veg.classAt(38.5, -98.0));       // Kansas: temperate grassland
      assertEquals(1, veg.classAt(-3.0, -60.0));        // Amazon: tropical evergreen forest
      assertEquals(21, veg.classAt(23.0, 10.0));        // Sahara: desert
      assertEquals(23, veg.classAt(65.0, -170.0));      // Beringia: shrub tundra
      assertEquals(23, veg.classAt(51.5, -0.1));        // London: shrub tundra (Neotoma pollen overrides the model's taiga)
      assertEquals(11, veg.classAt(60.0, 100.0));       // central Siberia: deciduous taiga, no pollen override
   }

   @Test
   void noDataSouthOfTheModelAndForBadInput() {
      assertEquals(0, veg.classAt(-75.0, 0.0));
      assertEquals(0, veg.classAt(Double.NaN, 0.0));
      assertEquals(veg.classAt(10.0, -179.9), veg.classAt(10.0, 180.1));   // longitude wraps
   }

   @Test
   void tableIsConsistent() {
      assertNull(EraVegetation.entry(0));
      assertNull(EraVegetation.entry(28));
      for (int k = 1; k < EraVegetation.TABLE.length; k++) {
         EraVegetation.Entry e = EraVegetation.entry(k);
         assertNotNull(e, "class " + k);
         assertTrue(e.agreesWith(e.cover()), e.name());
      }
      assertEquals(28, EraVegetation.TABLE.length);
   }

   @Test
   void everyBiomeIsVanillaOrPack() throws Exception {
      Set<String> vanilla = new HashSet<>();
      for (Field f : Biomes.class.getFields()) {
         if (Modifier.isStatic(f.getModifiers())) {
            vanilla.add(String.valueOf(f.get(null)));
         }
      }
      for (String id : EraVegetation.biomeIds()) {
         if (id.contains(":")) {
            // palette picks from the pack's biome mods; EraPalette falls back to vanilla when one is absent
            assertTrue(id.matches("(minecraft|biomesoplenty|regions_unexplored):[a-z_]+"), id);
         } else {
            assertTrue(vanilla.stream().anyMatch(k -> k.endsWith("minecraft:" + id + "]")), id);
         }
      }
   }
}
