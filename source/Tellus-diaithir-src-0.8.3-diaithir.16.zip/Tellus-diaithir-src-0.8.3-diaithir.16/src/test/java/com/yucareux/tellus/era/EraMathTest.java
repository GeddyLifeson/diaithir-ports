package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EraMathTest {
   static final EraSettings AGE1 = new EraSettings(-100.0, true, true, true, false, false, false, false);

   @Test
   void shelfBecomesLandRelativeToOldSea() {
      assertEquals(80.0, EraMath.relativeMeters(-20.0, AGE1), 1e-9);   // Dogger Bank: 20 m deep today
      assertEquals(0.0, EraMath.relativeMeters(-100.0, AGE1), 1e-9);    // the old shoreline
      assertTrue(EraMath.relativeMeters(-3000.0, AGE1) < 0.0);         // open Atlantic stays sea
      assertEquals(1345.0, EraMath.relativeMeters(1345.0, EraSettings.NONE), 1e-9); // off = identity
   }

   @Test
   void nanStaysNaN() {
      assertTrue(Double.isNaN(EraMath.relativeMeters(Double.NaN, AGE1)));
      assertTrue(Double.isNaN(EraMath.blend(Double.NaN, Double.NaN, 0.0)));
   }

   @Test
   void blendUsesIslandWhereRealDataMissing() {
      assertEquals(300.0, EraMath.blend(Double.NaN, 300.0, 1.0));
      assertEquals(300.0, EraMath.blend(Double.NaN, 300.0, 0.25));      // no real data: island wins whenever alpha > 0
      assertEquals(10.0, EraMath.blend(10.0, 300.0, 0.0));
      assertEquals(155.0, EraMath.blend(10.0, 300.0, 0.5), 1e-9);
      assertEquals(300.0, EraMath.blend(10.0, 300.0, 1.0), 1e-9);
   }

   @Test
   void compressionIsIdentityBelowKnee() {
      for (double b : new double[]{0, 1, 63, 500, 1000, 1499.9}) {
         assertEquals(b, EraMath.compressBlocks(b), 1e-9, "b=" + b);
      }
      assertEquals(-999.0, EraMath.compressBlocks(-999.0), 1e-9);
      assertEquals(1345.0, EraMath.compressBlocks(1345.0), 1e-9);       // Ben Nevis keeps its true height
   }

   @Test
   void compressionStaysInsideWorldAndIsStrictlyIncreasing() {
      double prev = Double.NEGATIVE_INFINITY;
      for (double b = -11000; b <= 9000; b += 25) {
         double c = EraMath.compressBlocks(b);
         assertTrue(c > prev, "monotonic at " + b);
         prev = c;
         int y = (int) Math.round(c) + EraMath.HEIGHT_OFFSET;
         assertTrue(y >= EraMath.MIN_Y && y <= EraMath.MAX_Y, "b=" + b + " y=" + y);
      }
      int everest = (int) Math.round(EraMath.compressBlocks(8849.0)) + EraMath.HEIGHT_OFFSET;
      int mariana = (int) Math.round(EraMath.compressBlocks(-10935.0)) + EraMath.HEIGHT_OFFSET;
      assertTrue(everest > 1800 && everest <= 2031, "everest " + everest);
      assertTrue(mariana >= -2032 && mariana < -1800, "mariana " + mariana);
      assertTrue(EraMath.compressBlocks(5000) < EraMath.compressBlocks(8849), "relief order preserved");
   }

   @Test
   void compressionNanAndInfinity() {
      assertTrue(Double.isNaN(EraMath.compressBlocks(Double.NaN)));
      assertTrue(EraMath.compressBlocks(Double.POSITIVE_INFINITY) <= EraMath.MAX_Y - EraMath.HEIGHT_OFFSET);
   }

   @Test
   void iceSheetSitsOnTopAndNeverFloatsOrTopsEverest() {
      double cap = EraMath.relativeMeters(EraMath.EVEREST_M, AGE1);
      assertEquals(3700.0, EraMath.withIce(400.0, 3300.0, cap), 1e-9);    // Keewatin: 300 m today, 3.3 km of ice
      assertEquals(1500.0, EraMath.withIce(-100.0, 1600.0, cap), 1e-9);   // Hudson Bay floor: grounded sheet
      assertEquals(-900.0, EraMath.withIce(-900.0, 600.0, cap), 1e-9);    // would float: left out
      assertEquals(400.0, EraMath.withIce(400.0, 0.0, cap), 1e-9);
      assertEquals(cap, EraMath.withIce(cap - 10.0, 3440.0, cap), 1e-9);
      assertEquals(cap + 5.0, EraMath.withIce(cap + 5.0, 100.0, cap), 1e-9); // never lowers terrain
      assertTrue(Double.isNaN(EraMath.withIce(Double.NaN, 1000.0, cap)));
      assertEquals(400.0, EraMath.withIce(400.0, Double.NaN, cap), 1e-9);
   }

   @Test
   void lakeFloodsOnlyBelowItsLevelAndAboveOtherWater() {
      assertTrue(EraMath.lakeFloods(190, 213, false, 190));      // dry shelf under the Black Sea lake
      assertTrue(EraMath.lakeFloods(100, 213, true, 200));       // today's sea at the era sea: the lake stands higher
      assertFalse(EraMath.lakeFloods(220, 213, false, 220));     // shore above the level
      assertFalse(EraMath.lakeFloods(213, 213, false, 213));
      assertFalse(EraMath.lakeFloods(150, 213, true, 230));      // higher water already there
   }

   @Test
   void shoreConstantForLaterAges() {
      assertEquals(100.0, EraMath.todayShoreRelativeMeters(AGE1), 1e-9);
      assertEquals(0.0, EraMath.todayShoreRelativeMeters(EraSettings.NONE), 1e-9);
   }

   @Test
   void age1SnowlineFollowsLatitude() {
      assertEquals(3900.0, EraMath.age1SnowlineMeters(0.0), 1e-9);            // tropics: Porter's ~1 km lowering, 15 ka share
      assertEquals(1000.0, EraMath.age1SnowlineMeters(57.0), 1e-9);           // Scottish Highlands
      assertEquals(2200.0, EraMath.age1SnowlineMeters(45.0), 1e-9);           // Alps
      assertEquals(EraMath.age1SnowlineMeters(-40.0) + 1800.0, EraMath.age1SnowlineMeters(40.0), 1e-9); // maritime south lower
      assertEquals(0.0, EraMath.age1SnowlineMeters(-80.0), 1e-9);
      assertEquals(0.0, EraMath.age1SnowlineMeters(90.0), 1e-9);
      assertTrue(EraMath.aboveAge1Snowline(1345.0, 56.8, 0.0));                // Ben Nevis is white
      assertFalse(EraMath.aboveAge1Snowline(1000.0, 56.8, 1.0));
      assertFalse(EraMath.aboveAge1Snowline(-5.0, 85.0, -1.0));               // never under the sea
   }

   @Test
   void snowlineJitterIsStableAndBounded() {
      for (int x = -100; x < 100; x += 7) {
         for (int z = -100; z < 100; z += 11) {
            double j = EraMath.snowlineJitter(x, z);
            assertTrue(j >= -1.0 && j < 1.0);
            assertEquals(j, EraMath.snowlineJitter(x, z));
         }
      }
      assertEquals(EraMath.snowlineJitter(8, 8), EraMath.snowlineJitter(15, 15));
   }
}
