package com.yucareux.tellus.worldgen;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import net.minecraft.util.RandomSource;
import org.junit.jupiter.api.Test;

class MineSiteBoostTest {
   private static final double SCALE = 5.0;

   @Test
   void oreBlockPathsMapToGroups() {
      assertEquals("copper", MineSiteBoost.groupOf("deepslate_copper_ore"));
      assertEquals("gold", MineSiteBoost.groupOf("gold_ore"));
      assertEquals("uranium", MineSiteBoost.groupOf("uraninite_ore"));
      assertEquals("bauxite", MineSiteBoost.groupOf("deepslate_bauxite_ore"));
      assertNull(MineSiteBoost.groupOf("redstone_ore"));
   }

   @Test
   void realDistrictsAreRicherThanTheirSurroundings() {
      MineSiteBoost boost = MineSiteBoost.shared();
      double bx = EarthProjection.longitudeToBlockX(-112.5, SCALE);
      double bz = EarthProjection.latToBlockZ(46.0, SCALE);   // Butte, Montana: copper
      double atButte = boost.multiplier("copper", bx, bz, SCALE);
      assertTrue(atButte > 2.0, "copper at Butte " + atButte);
      assertEquals(1.0, boost.multiplier("coal", bx + 40000, bz, SCALE), 1e-9);
      double sx = EarthProjection.longitudeToBlockX(15.0, SCALE);
      double sz = EarthProjection.latToBlockZ(24.0, SCALE);   // central Sahara
      assertEquals(1.0, boost.multiplier("copper", sx, sz, SCALE), 1e-9);
      assertTrue(atButte <= 1.0 + MineSiteBoost.MAX_EXTRA);
   }

   @Test
   void scaledSampleCountKeepsTheMean() {
      RandomSource random = RandomSource.create(7L);
      long total = 0;
      for (int i = 0; i < 20000; i++) {
         total += MineSiteBoost.scaleSamples(17, 1.35, random);
      }
      assertEquals(17 * 1.35, total / 20000.0, 0.05);
   }
}
