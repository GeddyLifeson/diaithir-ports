package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.*;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import org.junit.jupiter.api.Test;

class EraSettingsTest {
   @Test
   void defaultsToNoneWhenKeysMissing() {
      JsonElement json = JsonParser.parseString("{}");
      EraSettings s = EraSettings.CODEC.parse(JsonOps.INSTANCE, json).getOrThrow();
      assertEquals(EraSettings.NONE, s);
      assertFalse(s.active());
   }

   @Test
   void parsesAgeOne() {
      JsonElement json = JsonParser.parseString(
         "{\"sea_level_offset_m\":-100.0,\"island_overlay\":true,\"height_compress\":true,\"ice\":true}");
      EraSettings s = EraSettings.CODEC.parse(JsonOps.INSTANCE, json).getOrThrow();
      assertEquals(-100.0, s.seaLevelOffsetM());
      assertTrue(s.islandOverlay() && s.heightCompress() && s.ice());
      assertTrue(s.active());
   }

   @Test
   void iceSheetsDefaultOffAndParse() {
      assertFalse(EraSettings.NONE.iceSheets());
      assertFalse(EraSettings.CODEC.parse(JsonOps.INSTANCE, JsonParser.parseString("{\"ice\":true}")).getOrThrow().iceSheets());
      EraSettings s = EraSettings.CODEC.parse(JsonOps.INSTANCE, JsonParser.parseString("{\"ice_sheets\":true}")).getOrThrow();
      assertTrue(s.iceSheets());
      assertTrue(s.active());
   }

   @Test
   void lakesDefaultOffAndParse() {
      assertFalse(EraSettings.NONE.lakes());
      EraSettings s = EraSettings.CODEC.parse(JsonOps.INSTANCE, JsonParser.parseString("{\"lakes\":true}")).getOrThrow();
      assertTrue(s.lakes() && s.active());
      assertNotEquals(new EraSettings(-100.0, true, false, true, true, false, false, false).cacheKey(), new EraSettings(-100.0, true, false, true, true, true, false, false).cacheKey());
   }

   @Test
   void structureFilterDefaultOffParsesAndLeavesTerrainCachesAlone() {
      assertFalse(EraSettings.NONE.structureFilter());
      EraSettings s = EraSettings.CODEC.parse(JsonOps.INSTANCE, JsonParser.parseString("{\"structure_filter\":true}")).getOrThrow();
      assertTrue(s.structureFilter() && s.active());
      assertEquals(new EraSettings(-100.0, true, false, true, true, true, true, false).cacheKey(), new EraSettings(-100.0, true, false, true, true, true, true, true).cacheKey());
   }

   @Test
   void vegetationDefaultOffAndParse() {
      assertFalse(EraSettings.NONE.vegetation());
      EraSettings s = EraSettings.CODEC.parse(JsonOps.INSTANCE, JsonParser.parseString("{\"vegetation\":true}")).getOrThrow();
      assertTrue(s.vegetation() && s.active());
      assertNotEquals(new EraSettings(-100.0, true, false, true, true, true, false, false).cacheKey(), new EraSettings(-100.0, true, false, true, true, true, true, false).cacheKey());
   }

   @Test
   void roundTrips() {
      EraSettings in = new EraSettings(-100.0, true, true, true, true, false, false, false);
      JsonElement json = EraSettings.CODEC.encodeStart(JsonOps.INSTANCE, in).getOrThrow();
      assertEquals(in, EraSettings.CODEC.parse(JsonOps.INSTANCE, json).getOrThrow());
   }

   @Test
   void rejectsAbsurdOffset() {
      JsonElement json = JsonParser.parseString("{\"sea_level_offset_m\":-5000.0}");
      assertTrue(EraSettings.CODEC.parse(JsonOps.INSTANCE, json).error().isPresent());
   }

   @Test
   void cacheKeyDiffers() {
      assertNotEquals(EraSettings.NONE.cacheKey(), new EraSettings(-100.0, true, true, true, false, false, false, false).cacheKey());
      assertNotEquals(new EraSettings(-100.0, true, true, true, false, false, false, false).cacheKey(), new EraSettings(-100.0, false, true, true, false, false, false, false).cacheKey());
      assertEquals(new EraSettings(-100.0, true, true, true, false, false, false, false).cacheKey(), new EraSettings(-100.0, true, true, true, false, false, false, false).cacheKey());
      assertNotEquals(new EraSettings(-100.0, true, false, true, false, false, false, false).cacheKey(), new EraSettings(-100.0, true, false, true, true, false, false, false).cacheKey());
   }

   @Test
   void stockEarthPresetSettingsDecodeWithEraNone() throws Exception {
      try (var in = EraSettingsTest.class.getResourceAsStream("/data/tellus/worldgen/world_preset/earth.json")) {
         JsonElement root = JsonParser.parseReader(new java.io.InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8));
         JsonElement settings = root.getAsJsonObject().getAsJsonObject("dimensions").getAsJsonObject("minecraft:overworld")
            .getAsJsonObject("generator").getAsJsonObject("settings");
         var parsed = com.yucareux.tellus.worldgen.EarthGeneratorSettings.CODEC.parse(JsonOps.INSTANCE, settings).getOrThrow();
         assertEquals(EraSettings.NONE, parsed.era());
      }
   }
}
