package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EraCoverTest {
   static final EraSettings AGE1 = new EraSettings(-100.0, true, true, true, false, false, false, false);
   static final double NAN = Double.NaN;

   @Test
   void exposedShelfIsNotSea() {              // Dogger Bank: today -25 m -> rel +75, ESA says water/no data
      assertEquals(30, EraCover.remap(80, 75.0, NAN, 0.0, 55.0, 2.5, AGE1));
      assertEquals(30, EraCover.remap(0, 75.0, NAN, 0.0, 55.0, 2.5, AGE1));
   }

   @Test
   void realSeaStaysSea() {
      assertEquals(80, EraCover.remap(80, -500.0, NAN, 0.0, 45.0, -20.0, AGE1));
      assertEquals(0, EraCover.remap(0, -5.0, NAN, 0.0, 55.0, 3.0, AGE1));
   }

   @Test
   void inlandLakeSurvives() {                // Loch Ness: today +16 m -> rel +116, ESA 80
      assertEquals(80, EraCover.remap(80, 116.0, NAN, 0.0, 57.3, -4.45, AGE1));
   }

   @Test
   void lakeBedIsWaterCover() {               // Baltic Ice Lake at -16 m today = rel +84
      assertEquals(80, EraCover.underLake(30, 40.0, 84.0));
      assertEquals(80, EraCover.underLake(70, 40.0, 84.0));     // thin ice under the lake is lake bed
      assertEquals(30, EraCover.underLake(30, 90.0, 84.0));     // shore above the level
      assertEquals(30, EraCover.underLake(30, 40.0, NAN));      // no lake here
      assertEquals(30, EraCover.underLake(30, NAN, 84.0));      // no elevation probed
   }

   @Test
   void vegetationKeepsAgreeingCoverOnly() {
      assertEquals(10, EraCover.withVegetation(10, 4));         // forest under temperate deciduous forest: kept
      assertEquals(10, EraCover.withVegetation(30, 4));         // today's grass there was forest
      assertEquals(30, EraCover.withVegetation(40, 22));        // cropland on steppe tundra: grass
      assertEquals(100, EraCover.withVegetation(10, 26));       // forest on lichen tundra: moss and lichen
      assertEquals(60, EraCover.withVegetation(50, 21));        // a desert city: bare
      assertEquals(80, EraCover.withVegetation(80, 4));         // water, sea and ice stay
      assertEquals(0, EraCover.withVegetation(0, 4));
      assertEquals(70, EraCover.withVegetation(70, 4));
      assertEquals(50, EraCover.withVegetation(50, 0));         // no BIOME4 data: today's cover
   }

   @Test
   void islandGetsVegetationByHeight() {
      assertEquals(0, EraCover.remap(0, 4.0, -3.0, 1.0, 56.9, -10.0, AGE1));
      assertEquals(30, EraCover.remap(0, NAN, 40.0, 1.0, 56.9, -10.0, AGE1));
      assertEquals(60, EraCover.remap(0, NAN, 700.0, 1.0, 56.9, -10.0, AGE1));
      assertEquals(70, EraCover.remap(0, NAN, 900.0, 1.0, 56.9, -10.0, AGE1));
      assertEquals(60, EraCover.remap(0, NAN, 900.0, 1.0, 56.9, -10.0, new EraSettings(-100.0, true, true, false, false, false, false, false)));
   }

   @Test
   void featherEdgeBelowHalfUsesRealData() {
      assertEquals(80, EraCover.remap(80, -300.0, 40.0, 0.3, 56.9, -7.9, AGE1));
   }

   @Test
   void highlandsIceNeedsHeightAndBox() {
      double benNevisRel = 1345.0 + 100.0;
      assertEquals(70, EraCover.remap(60, benNevisRel, NAN, 0.0, 56.7969, -5.0036, AGE1));
      assertEquals(30, EraCover.remap(30, 300.0 + 100.0, NAN, 0.0, 56.6, -4.5, AGE1));       // low ground, no ice
      assertEquals(60, EraCover.remap(60, 1300.0 + 100.0, NAN, 0.0, 51.0, -3.0, AGE1));      // outside the box
      assertEquals(60, EraCover.remap(60, benNevisRel, NAN, 0.0, 56.7969, -5.0036, new EraSettings(-100.0, true, true, false, false, false, false, false)));
   }

   @Test
   void iceSheetIsSnowAndIceAboveTheSea() {
      assertEquals(70, EraCover.withIceSheet(10, 3700.0, 3300.0));
      assertEquals(70, EraCover.withIceSheet(80, 1500.0, 1600.0));          // grounded over today's sea
      assertEquals(80, EraCover.withIceSheet(80, -900.0, 600.0));           // floating ice left out: sea stays sea
      assertEquals(10, EraCover.withIceSheet(10, 400.0, 0.0));
      assertEquals(10, EraCover.withIceSheet(10, NAN, 1000.0));
   }

   @Test
   void noForestAboveTheTreeline() {                                       // Kilimanjaro, line 3900 m, treeline 2900 m
      assertEquals(30, EraCover.belowTreeline(10, 5800.0, -3.07));
      assertEquals(10, EraCover.belowTreeline(10, 2000.0, -3.07));
      assertEquals(60, EraCover.belowTreeline(60, 5800.0, -3.07));
      assertEquals(10, EraCover.belowTreeline(10, NAN, -3.07));
   }

   @Test
   void noEraNoChange() {
      for (int c : new int[]{0, 10, 30, 60, 70, 80}) {
         assertEquals(c, EraCover.remap(c, 70.0, NAN, 0.0, 55.0, 2.5, EraSettings.NONE));
      }
   }

   @Test
   void nanElevationLeavesCoverAlone() {
      assertEquals(80, EraCover.remap(80, NAN, NAN, 0.0, 55.0, 2.5, AGE1));
   }
}
