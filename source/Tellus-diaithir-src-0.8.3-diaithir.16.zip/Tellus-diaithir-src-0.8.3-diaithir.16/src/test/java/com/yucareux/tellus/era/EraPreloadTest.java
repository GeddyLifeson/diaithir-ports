package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.*;

import com.yucareux.tellus.preload.TerrainPreloadArea;
import com.yucareux.tellus.worldgen.EarthProjection;
import org.junit.jupiter.api.Test;

class EraPreloadTest {
   @Test
   void boxCoversItsCorners() {
      TerrainPreloadArea a = EraPreload.area(56.97, 56.99, -10.03, -10.00, 1.0);
      int cx = Math.floorDiv((int)EarthProjection.longitudeToBlockX(-10.0145, 1.0), 16);
      int cz = Math.floorDiv((int)EarthProjection.latToBlockZ(56.982, 1.0), 16);
      assertTrue(a.containsChunk(cx, cz));
      assertTrue(a.chunkWidth() > 100 && a.chunkDepth() > 50);
   }

   @Test
   void oversizedBoxIsRejected() {
      assertThrows(IllegalArgumentException.class, () -> EraPreload.area(55.0, 58.0, -14.0, -7.0, 1.0));
   }
}
