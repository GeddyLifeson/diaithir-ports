package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class EraLakesTest {
   static EraLakes lakes;

   @BeforeAll
   static void load() throws Exception {
      lakes = EraLakes.loadFromClasspath();
   }

   @Test
   void blackSeaIsALakeBelowTheBosporusSill() {
      assertEquals(-35.0, lakes.levelMeters(43.0, 34.0));
      assertTrue(Double.isNaN(lakes.levelMeters(40.8, 28.5)), "Sea of Marmara: beyond the sill");
      assertTrue(Double.isNaN(lakes.levelMeters(46.0, 36.5)), "Sea of Azov: its floor stands above the level");
   }

   @Test
   void balticIceLakeStopsAtTheSillsAndTheIce() {
      assertEquals(-16.0, lakes.levelMeters(55.0, 16.0));
      assertTrue(Double.isNaN(lakes.levelMeters(56.5, 11.0)), "Kattegat");
      assertTrue(Double.isNaN(lakes.levelMeters(54.4, 11.0)), "Mecklenburg Bight, west of the Darss sill");
   }

   @Test
   void lakeChicagoAtTheGlenwoodLevel() {
      assertEquals(195.0, lakes.levelMeters(41.88, -87.63));               // the Loop
      assertEquals(195.0, lakes.levelMeters(42.5, -87.0));
      assertTrue(Double.isNaN(lakes.levelMeters(41.53, -88.08)), "Joliet: past the Chicago Outlet cut");
   }

   @Test
   void patagonianIceDammedLakesFromPatice() {
      assertTrue(lakes.size() >= 11);
      assertEquals(15.0, lakes.levelMeters(-52.6, -71.5));                 // Otway-Skyring, one body at 15 m
   }

   @Test
   void outsideAndBadCoordinates() {
      assertTrue(Double.isNaN(lakes.levelMeters(0.0, 0.0)));
      assertTrue(Double.isNaN(lakes.levelMeters(47.0, -96.8)), "no Lake Agassiz at 15 ka: the Red River valley is under ice");
      assertTrue(Double.isNaN(lakes.levelMeters(Double.NaN, 34.0)));
      assertTrue(Double.isNaN(lakes.levelMeters(43.0, Double.NaN)));
   }
}
