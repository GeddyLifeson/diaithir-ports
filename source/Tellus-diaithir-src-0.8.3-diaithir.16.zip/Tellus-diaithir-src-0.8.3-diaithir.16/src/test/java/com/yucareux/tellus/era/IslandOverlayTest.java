package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.*;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class IslandOverlayTest {
   static IslandOverlay island;
   static JsonObject known;

   @BeforeAll
   static void load() throws Exception {
      island = IslandOverlay.loadFromClasspath();
      try (var in = IslandOverlayTest.class.getResourceAsStream("/diaithir/known_points.json")) {
         known = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
      }
   }

   @Test
   void knownLandPointsAreHighAndFullyOwned() {
      JsonArray land = known.getAsJsonArray("land");
      assertTrue(land.size() >= 5);
      for (var e : land) {
         JsonObject p = e.getAsJsonObject();
         double lat = p.get("lat").getAsDouble(), lon = p.get("lon").getAsDouble();
         assertEquals(1.0, island.alpha(lat, lon), 1e-9, "alpha " + p);
         assertTrue(island.relativeMeters(lat, lon) >= 20.0, "land " + p + " -> " + island.relativeMeters(lat, lon));
      }
   }

   @Test
   void knownSeaPointsAreBelowTheOldSea() {
      for (var e : known.getAsJsonArray("sea")) {
         JsonObject p = e.getAsJsonObject();
         assertTrue(island.relativeMeters(p.get("lat").getAsDouble(), p.get("lon").getAsDouble()) <= -30.0, "sea " + p);
      }
   }

   @Test
   void spawnIsLand() {
      JsonObject s = known.getAsJsonObject("spawn");
      assertTrue(island.relativeMeters(s.get("lat").getAsDouble(), s.get("lon").getAsDouble()) >= 2.0);
   }

   @Test
   void outsideIslandIsNaNAndAlphaZero() {
      double[][] outside = {
         {50.0, -20.0}, {57.0, -7.0}, {56.9, -13.7}, {58.5, -10.0}, {56.0, -10.0}, {0.0, 0.0},
         {85.0, 179.9}, {-85.0, -179.9}, {56.982, 170.0}, {56.982, -170.0}, {Double.NaN, -10.0}, {56.9, Double.NaN},
      };
      for (double[] p : outside) {
         assertEquals(0.0, island.alpha(p[0], p[1]), "alpha " + p[0] + "," + p[1]);
         assertTrue(Double.isNaN(island.relativeMeters(p[0], p[1])), "rel " + p[0] + "," + p[1]);
      }
   }

   @Test
   void featherRisesMonotonicallyAcrossTheEastEdge() {
      double lat = 56.8;
      double lonE = island.lonE();
      double prev = -1.0;
      for (int k = 0; k <= 120; k++) {           // from just outside to ~13 km inside, 0.001 deg steps
         double a = island.alpha(lat, lonE - k * 0.001 + 0.002);
         assertTrue(a >= prev - 1e-9, "monotonic at k=" + k);
         prev = a;
      }
      assertEquals(1.0, prev, 1e-9);
   }

   @Test
   void heightIsContinuous() {
      double lat = 56.982, lon = -10.0145;
      double a = island.relativeMeters(lat, lon);
      double b = island.relativeMeters(lat, lon + 0.0005);   // ~30 m
      assertTrue(Math.abs(a - b) < 40.0, "no cliff: " + a + " vs " + b);
   }
}
