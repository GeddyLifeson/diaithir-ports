package com.yucareux.tellus.era;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class IceSheetsTest {
   static IceSheets ice;

   @BeforeAll
   static void load() throws Exception {
      ice = IceSheets.loadFromClasspath();
   }

   @Test
   void theGreatSheetsAreThick() {
      assertTrue(ice.meters(63.0, -104.0) > 3000.0, "Keewatin dome " + ice.meters(63.0, -104.0));
      assertTrue(ice.meters(60.0, -85.0) > 1000.0, "Hudson Bay " + ice.meters(60.0, -85.0));
      assertTrue(ice.meters(65.0, 22.0) > 2000.0, "Bothnian Bay " + ice.meters(65.0, 22.0));
      assertTrue(ice.meters(47.5, -88.0) > 500.0, "Lake Superior " + ice.meters(47.5, -88.0));
   }

   @Test
   void alpineAndPatagonianIce() {
      assertTrue(ice.meters(46.45, 8.05) > 300.0, "Aletsch area (Seguinot 2018) " + ice.meters(46.45, 8.05));
      assertTrue(ice.meters(-49.5, -73.4) > 500.0, "South Patagonian ice field (PATICE) " + ice.meters(-49.5, -73.4));
      assertEquals(0.0, ice.meters(48.14, 11.58), "Munich: the foreland lobes are gone");
   }

   @Test
   void iceFreeAt15ka() {
      assertEquals(0.0, ice.meters(41.88, -87.63), "Chicago, south of the Lake Michigan lobe");
      assertEquals(0.0, ice.meters(55.0, 2.5), "Dogger Bank");
      assertEquals(0.0, ice.meters(51.5, -0.1), "London");
      assertEquals(0.0, ice.meters(0.0, 0.0), "equator");
      assertEquals(0.0, ice.meters(56.982, -10.0145), "the island spawn");
   }

   @Test
   void islandRectangleCarriesNoIce() {
      IslandOverlay island = IslandOverlay.shared();
      for (double lat = island.latS(); lat <= island.latN(); lat += 0.02) {
         for (double lon = island.lonW(); lon <= island.lonE(); lon += 0.02) {
            assertEquals(0.0, ice.meters(lat, lon), lat + "," + lon);
         }
      }
   }

   @Test
   void taperedToZeroAtTheMargin() {                // walk south from the Laurentide interior across its 15 ka margin at Lake Huron
      double prev = Double.POSITIVE_INFINITY;
      boolean sawIce = false;
      for (double lat = 50.0; lat >= 40.0; lat -= 0.01) {
         double m = ice.meters(lat, -84.0);
         sawIce |= m > 0.0;
         if (sawIce && m == 0.0) {
            assertTrue(prev < 300.0, "no cliff at the margin, last " + prev);
            return;
         }
         prev = m;
      }
      fail("no margin found");
   }

   @Test
   void edgesAndBadCoordinatesNeverThrow() {
      double[][] pts = {{90.0, 0.0}, {-90.0, 0.0}, {89.999, 179.999}, {-89.999, -180.0}, {0.0, 180.0}, {0.0, -180.0},
         {0.0, 540.0}, {95.0, 10.0}, {Double.NaN, 0.0}, {0.0, Double.NaN}};
      for (double[] p : pts) {
         double m = ice.meters(p[0], p[1]);
         assertTrue(m >= 0.0 && m <= ice.maxMeters(), p[0] + "," + p[1] + " -> " + m);
      }
      assertEquals(0.0, ice.meters(Double.NaN, 10.0));
      assertEquals(ice.meters(-75.0, 180.0), ice.meters(-75.0, -180.0), 1e-9);
   }

   @Test
   void yBudget() {                                   // Age I preset: 5 m per block, sea Y 200, ceiling 2031
      assertTrue(ice.maxMeters() <= 3440, "thickest added ice " + ice.maxMeters());
      assertTrue(ice.maxMeters() / 5.0 <= 688.0);
      EraSettings age1 = new EraSettings(-100.0, true, false, true, true, false, false, false);
      double cap = EraMath.relativeMeters(EraMath.EVEREST_M, age1);
      double worst = EraMath.withIce(cap, ice.maxMeters(), cap);           // the thickest sheet on the highest ground
      assertTrue(200 + Math.round(worst / 5.0) <= 2031, "worst Y " + (200 + Math.round(worst / 5.0)));
      double dome = EraMath.withIce(EraMath.relativeMeters(300.0, age1), ice.meters(63.0, -104.0), cap);
      long domeY = 200 + Math.round(dome / 5.0);
      assertTrue(domeY > 850 && domeY < 1000, "Keewatin dome surface Y " + domeY);
   }
}
