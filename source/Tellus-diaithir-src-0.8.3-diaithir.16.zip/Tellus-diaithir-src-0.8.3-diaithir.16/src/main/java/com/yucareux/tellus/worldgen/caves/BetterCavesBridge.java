package com.yucareux.tellus.worldgen.caves;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.chunk.CarvingMask;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.levelgen.Aquifer;
import net.minecraft.world.level.levelgen.carver.CarvingContext;
import net.minecraft.world.level.levelgen.carver.ConfiguredWorldCarver;

/**
 * Runs YUNG's Better Caves (LGPL-3.0, an optional mod) inside Tellus' own carving step. Better Caves registers its
 * carver as an ordinary biome carver, which Tellus' generator never reads, and the carver needs a per-thread context
 * and a liquid-region aquifer that vanilla's carving loop supplies. Everything is reached by reflection so Tellus
 * neither depends on nor fails without the mod. Its caves and caverns are tuned by the pack's
 * {@code bettercaves:better_cave} datapack carver, which the pack scales by the vertical depth ratio.
 */
final class BetterCavesBridge {
   private static final String CONTEXT_CLASS = "com.yungnickyoung.minecraft.bettercaves.worldgen.context.CavegenContext";
   private static final String LIQUID_CLASS = "com.yungnickyoung.minecraft.bettercaves.duck.ILiquidRegionsProvider";
   private static final String CARVER_ID = "bettercaves:better_cave";
   private static final BetterCavesBridge INSTANCE = create();

   private final Method pushContext;
   private final Class<?> liquidInterface;

   private BetterCavesBridge(Method pushContext, Class<?> liquidInterface) {
      this.pushContext = pushContext;
      this.liquidInterface = liquidInterface;
   }

   private static BetterCavesBridge create() {
      if (Boolean.getBoolean("tellus.noBetterCaves")) {
         return null;
      }
      try {
         ClassLoader loader = Aquifer.class.getClassLoader();
         Class<?> context = Class.forName(CONTEXT_CLASS, false, loader);
         return new BetterCavesBridge(context.getMethod("push", ServerLevel.class), Class.forName(LIQUID_CLASS, false, loader));
      } catch (ReflectiveOperationException | LinkageError e) {
         return null;
      }
   }

   static boolean available() {
      return INSTANCE != null;
   }

   static void carve(
      WorldGenRegion level,
      CarvingContext carvingContext,
      ChunkAccess chunk,
      Function<BlockPos, Holder<Biome>> biomes,
      RandomSource random,
      Aquifer aquifer,
      CarvingMask carvingMask
   ) {
      if (INSTANCE != null) {
         INSTANCE.run(level, carvingContext, chunk, biomes, random, aquifer, carvingMask);
      }
   }

   private void run(
      WorldGenRegion level,
      CarvingContext carvingContext,
      ChunkAccess chunk,
      Function<BlockPos, Holder<Biome>> biomes,
      RandomSource random,
      Aquifer aquifer,
      CarvingMask carvingMask
   ) {
      Aquifer wrapped = wrapAquifer(aquifer);
      ChunkPos pos = chunk.getPos();
      for (ConfiguredWorldCarver<?> carver : carvers(level.registryAccess())) {
         try {
            this.pushContext.invoke(null, level.getLevel());
            carver.carve(carvingContext, chunk, biomes, random, wrapped, pos, carvingMask);
         } catch (ReflectiveOperationException e) {
            return;
         }
      }
   }

   private static List<ConfiguredWorldCarver<?>> carvers(RegistryAccess registries) {
      Registry<ConfiguredWorldCarver<?>> registry = registries.lookupOrThrow(Registries.CONFIGURED_CARVER);
      List<ConfiguredWorldCarver<?>> found = new ArrayList<>();
      registry.listElements().forEach(holder -> {
         if (holder.key().toString().endsWith(CARVER_ID + "]")) {
            found.add(holder.value());
         }
      });
      return found;
   }

   /** Better Caves reads liquid regions off its own mixin on the noise aquifer; ours has none, so answer null. */
   private Aquifer wrapAquifer(Aquifer delegate) {
      InvocationHandler handler = (proxy, method, args) -> {
         if (method.getDeclaringClass() == this.liquidInterface) {
            return null;
         }
         if (method.getDeclaringClass() == Object.class) {
            return method.invoke(delegate, args);
         }
         return method.invoke(delegate, args);
      };
      return (Aquifer)Proxy.newProxyInstance(Aquifer.class.getClassLoader(), new Class<?>[]{Aquifer.class, this.liquidInterface}, handler);
   }
}
