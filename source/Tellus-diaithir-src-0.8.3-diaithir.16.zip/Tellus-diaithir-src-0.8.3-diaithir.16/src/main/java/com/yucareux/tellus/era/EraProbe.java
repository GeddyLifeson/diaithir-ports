package com.yucareux.tellus.era;

public record EraProbe(
   double lat, double lon, int blockX, int blockZ, int surfaceY, boolean ocean, int cover,
   double relMeters, double overlay, boolean roads, boolean buildings
) {
   public String line() {
      return String.format(java.util.Locale.ROOT,
         "PROBE lat=%.5f lon=%.5f blockX=%d blockZ=%d surfaceY=%d ocean=%b cover=%d relM=%.2f overlay=%.3f roads=%b buildings=%b",
         this.lat, this.lon, this.blockX, this.blockZ, this.surfaceY, this.ocean, this.cover,
         this.relMeters, this.overlay, this.roads, this.buildings);
   }
}
