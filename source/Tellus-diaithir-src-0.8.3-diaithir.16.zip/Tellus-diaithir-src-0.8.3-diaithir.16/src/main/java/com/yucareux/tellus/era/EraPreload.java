package com.yucareux.tellus.era;

import com.yucareux.tellus.preload.TerrainPreloadArea;
import com.yucareux.tellus.preload.TerrainPreloadJob;
import com.yucareux.tellus.preload.TerrainPreloadJobManager;
import com.yucareux.tellus.preload.TerrainPreloadProgress;
import com.yucareux.tellus.worldgen.EarthGeneratorSettings;
import com.yucareux.tellus.worldgen.EarthProjection;

/** Starts terrain preload jobs for lat/lon boxes and reports the latest one; backs /diaithir_preload and /diaithir_preload_status. */
public final class EraPreload {
   private static volatile TerrainPreloadJob last;

   private EraPreload() {
   }

   /** Chunk-aligned preload area covering the box. Throws IllegalArgumentException if a side exceeds the preload maximum. */
   public static TerrainPreloadArea area(double latMin, double latMax, double lonMin, double lonMax, double worldScale) {
      int minChunkX = Math.floorDiv((int)Math.floor(EarthProjection.longitudeToBlockX(lonMin, worldScale)), TerrainPreloadArea.CHUNK_SIZE);
      int maxChunkX = Math.floorDiv((int)Math.floor(EarthProjection.longitudeToBlockX(lonMax, worldScale)), TerrainPreloadArea.CHUNK_SIZE);
      int minChunkZ = Math.floorDiv((int)Math.floor(EarthProjection.latToBlockZ(latMax, worldScale)), TerrainPreloadArea.CHUNK_SIZE);
      int maxChunkZ = Math.floorDiv((int)Math.floor(EarthProjection.latToBlockZ(latMin, worldScale)), TerrainPreloadArea.CHUNK_SIZE);
      int side = Math.max(maxChunkX - minChunkX, maxChunkZ - minChunkZ) + 1;
      return TerrainPreloadArea.fromChunkBounds(
         (latMin + latMax) / 2.0, (lonMin + lonMax) / 2.0, side, worldScale, minChunkX, minChunkZ, maxChunkX, maxChunkZ
      );
   }

   public static String start(double latMin, double latMax, double lonMin, double lonMax, EarthGeneratorSettings settings) {
      TerrainPreloadArea area = area(latMin, latMax, lonMin, lonMax, settings.worldScale());
      last = TerrainPreloadJobManager.instance().startAdditional(area, settings);
      return "PRELOAD started " + area.summary();
   }

   public static String status() {
      TerrainPreloadJob job = last;
      if (job == null) {
         return "PRELOAD stage=NONE done=0 total=0 failed=0";
      }
      TerrainPreloadProgress p = job.progress();
      return "PRELOAD stage=" + p.stage() + " done=" + p.completedUnits() + " total=" + p.totalUnits()
         + " failed=" + (p.error() == null ? 0 : 1);
   }
}
