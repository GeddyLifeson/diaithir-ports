package com.yucareux.tellus.era;

/** Pure era math. No Minecraft types, no I/O. */
public final class EraMath {
   public static final int HEIGHT_OFFSET = 64;
   public static final int MIN_Y = -2032;
   public static final int MAX_Y = 2031;
   private static final int MARGIN = 8;
   private static final double UP_KNEE = 1500.0;
   private static final double DOWN_KNEE = 1000.0;
   private static final double UP_ROOM = MAX_Y - HEIGHT_OFFSET - MARGIN - UP_KNEE;                 // 459
   private static final double DOWN_ROOM = -(MIN_Y + MARGIN - HEIGHT_OFFSET) - DOWN_KNEE;          // 1088
   /** Everest, today's metres: no ice-sheet surface may stand higher, so the sheets never cost Y budget beyond the terrain's. */
   public static final double EVEREST_M = 8849.0;
   /** Snow blocks on top of an ice sheet; the rest of the sheet is packed ice. */
   public static final int ICE_SNOW_CAP_BLOCKS = 2;

   private EraMath() {
   }

   /** Height of a point above the era's sea. Today's DEM metres minus the era sea level (offset is negative: -95 -> +95). */
   public static double relativeMeters(double todayMeters, EraSettings era) {
      return todayMeters - era.seaLevelOffsetM();
   }

   /** Mix the island's relative height over the real one. NaN real data yields the island wherever alpha > 0. */
   public static double blend(double relMeters, double islandRelMeters, double alpha) {
      if (!(alpha > 0.0) || Double.isNaN(islandRelMeters)) {
         return relMeters;
      }
      if (Double.isNaN(relMeters)) {
         return islandRelMeters;
      }
      return relMeters + (islandRelMeters - relMeters) * Math.min(1.0, alpha);
   }

   /**
    * Smooth saturating squash of the vertical range so every column fits -2032..2031. Identity up to the knee
    * (1500 up, 1000 down), then y = room * x / (x + room): slope 1 at the knee, strictly increasing, never reaching the cap.
    */
   public static double compressBlocks(double blocks) {
      if (Double.isNaN(blocks)) {
         return Double.NaN;
      }
      if (blocks > UP_KNEE) {
         double x = blocks - UP_KNEE;
         return Double.isInfinite(x) ? UP_KNEE + UP_ROOM : UP_KNEE + UP_ROOM * x / (x + UP_ROOM);
      }
      if (blocks < -DOWN_KNEE) {
         double x = -DOWN_KNEE - blocks;
         return Double.isInfinite(x) ? -DOWN_KNEE - DOWN_ROOM : -DOWN_KNEE - DOWN_ROOM * x / (x + DOWN_ROOM);
      }
      return blocks;
   }

   /**
    * The surface with an ice sheet on top. Ice whose top would not reach the era sea (floating shelves) is left out, and the
    * sheet surface never exceeds capMeters. NaN stays NaN.
    */
   public static double withIce(double relMeters, double iceMeters, double capMeters) {
      if (!(iceMeters > 0.0) || Double.isNaN(relMeters) || relMeters + iceMeters <= 0.0) {
         return relMeters;
      }
      return Math.max(relMeters, Math.min(relMeters + iceMeters, capMeters));
   }

   /** True where a lake at levelY floods this column: the level stands above the terrain and above any water already there. */
   public static boolean lakeFloods(int terrainY, int levelY, boolean hasWater, int waterY) {
      return levelY > terrainY && (!hasWater || waterY < levelY);
   }

   /** 15 ka snowline lowering below today's: about 80% of the ~1000 m Last Glacial Maximum lowering (Porter 2001). */
   public static final double AGE1_SNOWLINE_LOWERING_M = 800.0;
   /** Snowline wobble either side of the line, metres, so it never draws a flat contour. */
   public static final double SNOWLINE_JITTER_M = 60.0;
   private static final double[] SNOWLINE_LAT = {0, 10, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 90};
   /** Today's climatic snowline by latitude, metres above sea (Hermes 1955 / Charlesworth curve; dry subtropics highest). */
   private static final double[] SNOWLINE_NORTH_M = {4700, 4800, 5200, 5300, 5100, 4500, 3800, 3000, 2600, 2000, 1500, 1000, 600, 300, 100, 0};
   private static final double[] SNOWLINE_SOUTH_M = {4700, 5000, 5600, 5800, 5200, 4200, 2000, 1500, 1200, 900, 500, 200, 0, 0, 0, 0};

   /** Age I snowline at this latitude, metres above the era sea: today's line lowered by AGE1_SNOWLINE_LOWERING_M, never below 0. */
   public static double age1SnowlineMeters(double lat) {
      double[] line = lat >= 0.0 ? SNOWLINE_NORTH_M : SNOWLINE_SOUTH_M;
      double a = Math.min(90.0, Math.abs(lat));
      int i = 1;
      while (SNOWLINE_LAT[i] < a) {
         i++;
      }
      double t = (a - SNOWLINE_LAT[i - 1]) / (SNOWLINE_LAT[i] - SNOWLINE_LAT[i - 1]);
      return Math.max(0.0, line[i - 1] + (line[i] - line[i - 1]) * t - AGE1_SNOWLINE_LOWERING_M);
   }

   /** Age I treeline sits this far below the snowline (alpine belt between them; about 1000 m on tropical and mid-latitude mountains). */
   public static final double AGE1_TREELINE_BELOW_SNOWLINE_M = 1000.0;

   /** Age I treeline at this latitude, metres above the era sea, never below 0. */
   public static double age1TreelineMeters(double lat) {
      return Math.max(0.0, age1SnowlineMeters(lat) - AGE1_TREELINE_BELOW_SNOWLINE_M);
   }

   /** True where a column relMeters above the era sea lies above the Age I snowline; jitter in -1..1 shifts the line. */
   public static boolean aboveAge1Snowline(double relMeters, double lat, double jitter) {
      return relMeters > 0.0 && relMeters >= age1SnowlineMeters(lat) + jitter * SNOWLINE_JITTER_M;
   }

   /** Stable -1..1 value per 8x8-block cell, for the snowline wobble. */
   public static double snowlineJitter(int blockX, int blockZ) {
      long h = (blockX >> 3) * 0x9E3779B97F4A7C15L ^ (blockZ >> 3) * 0xC2B2AE3D27D4EB4FL;
      h ^= h >>> 31;
      h *= 0xBF58476D1CE4E5B9L;
      h ^= h >>> 29;
      return ((h >>> 11) * 0x1.0p-53) * 2.0 - 1.0;
   }

   /** Where today's sea sits in this era's relative metres. Later Ages flood-fill ocean-connected air below this. */
   public static double todayShoreRelativeMeters(EraSettings era) {
      return -era.seaLevelOffsetM();
   }
}
