package com.yucareux.tellus.era;

/** ESA WorldCover class remap for the Age I world. Pure; callers supply elevations. */
public final class EraCover {
   public static final int NO_DATA = 0, TREE = 10, GRASS = 30, BARE = 60, SNOW_ICE = 70, WATER = 80;
   public static final double ISLAND_SNOW_LINE_M = 850.0;
   public static final double ISLAND_BARE_LINE_M = 600.0;
   public static final double HIGHLANDS_ICE_MIN_TODAY_M = 650.0;

   private EraCover() {
   }

   public static boolean inHighlandsBox(double lat, double lon) {
      return lat >= 56.2 && lat <= 57.8 && lon >= -5.9 && lon <= -3.3;
   }

   /** Snow/ice wherever an ice sheet stands (relMeters is the surface with the sheet; a sheet below the era sea is left out). */
   public static int withIceSheet(int cover, double relMeters, double iceMeters) {
      return iceMeters > 0.0 && relMeters > 0.0 ? SNOW_ICE : cover;
   }

   /** Age I: tree cover at or above the treeline (EraMath.age1TreelineMeters) turns to grass; NaN heights leave the cover. */
   public static int belowTreeline(int cover, double relMeters, double lat) {
      return cover == TREE && relMeters >= EraMath.age1TreelineMeters(lat) ? GRASS : cover;
   }

   /** Water (vanilla lake-bed palette, river biome) wherever an Age I lake stands above the terrain; NaN levels leave the cover. */
   public static int underLake(int cover, double relMeters, double lakeRelMeters) {
      return relMeters < lakeRelMeters ? WATER : cover;   // NaN compares false
   }

   /** Age I vegetation: today's cover where it agrees with the BIOME4 class, else the class's own cover. Sea, ice and water stay. */
   public static int withVegetation(int cover, int biome4) {
      EraVegetation.Entry e = EraVegetation.entry(biome4);
      if (e == null || cover == NO_DATA || cover == SNOW_ICE || cover == WATER || e.agreesWith(cover)) {
         return cover;
      }
      return e.cover();
   }

   public static int remap(int cover, double relMeters, double islandRelMeters, double islandAlpha, double lat, double lon, EraSettings era) {
      if (!era.active()) {
         return cover;
      }
      if (era.islandOverlay() && islandAlpha >= 0.5 && !Double.isNaN(islandRelMeters)) {
         if (islandRelMeters <= 0.0) {
            return NO_DATA;
         }
         if (era.ice() && islandRelMeters >= ISLAND_SNOW_LINE_M) {
            return SNOW_ICE;
         }
         return islandRelMeters >= ISLAND_BARE_LINE_M ? BARE : GRASS;
      }
      if (Double.isNaN(relMeters)) {
         return cover;
      }
      double todayElev = relMeters + era.seaLevelOffsetM();
      if (era.ice() && inHighlandsBox(lat, lon) && todayElev >= HIGHLANDS_ICE_MIN_TODAY_M) {
         return SNOW_ICE;
      }
      if (era.seaLevelOffsetM() != 0.0 && relMeters > 0.0 && todayElev < 0.0 && (cover == NO_DATA || cover == WATER)) {
         return GRASS;
      }
      return cover;
   }
}
