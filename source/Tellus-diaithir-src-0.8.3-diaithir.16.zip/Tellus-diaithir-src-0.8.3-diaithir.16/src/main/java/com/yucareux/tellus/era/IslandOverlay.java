package com.yucareux.tellus.era;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import javax.imageio.ImageIO;

/** Bilinear sampler for the Diaithir island rasters (see world/island/build_island_raster.py for the encoding). */
public final class IslandOverlay {
   private static final String DIR = "/data/tellus/diaithir/";
   private static volatile IslandOverlay shared;

   private final double latN, latS, lonW, lonE, dmOffset;
   private final int width, height;
   private final int[] rel;
   private final byte[] mask;

   private IslandOverlay(JsonObject meta, BufferedImage h, BufferedImage m) {
      this.latN = meta.get("lat_n").getAsDouble();
      this.latS = meta.get("lat_s").getAsDouble();
      this.lonW = meta.get("lon_w").getAsDouble();
      this.lonE = meta.get("lon_e").getAsDouble();
      this.dmOffset = meta.get("decimetre_offset").getAsDouble();
      this.width = meta.get("width").getAsInt();
      this.height = meta.get("height").getAsInt();
      if (h.getWidth() != this.width || h.getHeight() != this.height || m.getWidth() != this.width || m.getHeight() != this.height) {
         throw new IllegalStateException("island rasters do not match island_meta.json");
      }
      this.rel = new int[this.width * this.height];
      this.mask = new byte[this.width * this.height];
      for (int y = 0; y < this.height; y++) {
         for (int x = 0; x < this.width; x++) {
            this.rel[y * this.width + x] = h.getRaster().getSample(x, y, 0);
            this.mask[y * this.width + x] = (byte) m.getRaster().getSample(x, y, 0);
         }
      }
   }

   public static IslandOverlay loadFromClasspath() throws IOException {
      try (InputStream mi = IslandOverlay.class.getResourceAsStream(DIR + "island_meta.json");
           InputStream hi = IslandOverlay.class.getResourceAsStream(DIR + "island_height.png");
           InputStream ki = IslandOverlay.class.getResourceAsStream(DIR + "island_mask.png")) {
         if (mi == null || hi == null || ki == null) {
            throw new IOException("island resources missing under " + DIR);
         }
         JsonObject meta = JsonParser.parseReader(new InputStreamReader(mi, StandardCharsets.UTF_8)).getAsJsonObject();
         return new IslandOverlay(meta, ImageIO.read(hi), ImageIO.read(ki));
      }
   }

   public static IslandOverlay shared() {
      IslandOverlay s = shared;
      if (s == null) {
         synchronized (IslandOverlay.class) {
            if (shared == null) {
               try {
                  shared = loadFromClasspath();
               } catch (IOException e) {
                  throw new IllegalStateException("cannot load Diaithir island overlay", e);
               }
            }
            s = shared;
         }
      }
      return s;
   }

   public double latN() { return this.latN; }
   public double latS() { return this.latS; }
   public double lonW() { return this.lonW; }
   public double lonE() { return this.lonE; }

   private boolean inside(double lat, double lon) {
      return lat <= this.latN && lat >= this.latS && lon >= this.lonW && lon <= this.lonE;   // NaN compares false
   }

   /** 0 outside the map rectangle; 1 well inside; smooth feather in between. */
   public double alpha(double lat, double lon) {
      if (!this.inside(lat, lon)) {
         return 0.0;
      }
      return this.bilinear(lat, lon, false) / 255.0;
   }

   /** Metres above the Age I sea; NaN outside the map rectangle. */
   public double relativeMeters(double lat, double lon) {
      if (!this.inside(lat, lon)) {
         return Double.NaN;
      }
      return this.bilinear(lat, lon, true) / 10.0 - this.dmOffset;
   }

   private double bilinear(double lat, double lon, boolean heightRaster) {
      double fx = (lon - this.lonW) / (this.lonE - this.lonW) * this.width - 0.5;
      double fy = (this.latN - lat) / (this.latN - this.latS) * this.height - 0.5;
      fx = Math.max(0.0, Math.min(this.width - 1.0, fx));
      fy = Math.max(0.0, Math.min(this.height - 1.0, fy));
      int x0 = (int) fx, y0 = (int) fy;
      int x1 = Math.min(this.width - 1, x0 + 1), y1 = Math.min(this.height - 1, y0 + 1);
      double tx = fx - x0, ty = fy - y0;
      double a = this.at(x0, y0, heightRaster), b = this.at(x1, y0, heightRaster);
      double c = this.at(x0, y1, heightRaster), d = this.at(x1, y1, heightRaster);
      double top = a + (b - a) * tx, bot = c + (d - c) * tx;
      return top + (bot - top) * ty;
   }

   private double at(int x, int y, boolean heightRaster) {
      int i = y * this.width + x;
      return heightRaster ? this.rel[i] : (this.mask[i] & 0xFF);
   }
}
