package com.yucareux.tellus.worldgen;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.util.RandomSource;

/**
 * Raises ore abundance near real mining districts. The sites are producing or formerly producing mines from the USGS
 * Mineral Resources Data System (public domain), summed per 0.1 degree cell and ore group in {@code mine_sites.csv}.
 * An ore feature whose target block names a group (gold_ore, deepslate_copper_ore, ...) places more veins near a
 * site of that group and plain vanilla density elsewhere.
 */
public final class MineSiteBoost {
   public static final String RESOURCE = "/tellus/mine_sites.csv";
   /** Real-world radius of a district's influence; the block radius is this divided by the world scale. */
   public static final double RADIUS_METERS = 8000.0;
   /** Veins at most this many times denser than vanilla at a district's centre. */
   public static final double MAX_EXTRA = 5.0;
   private static final double WEIGHT_TO_EXTRA = 0.5;
   private static final int GRID_SHIFT = 11;
   private static final Map<String, String> ALIASES = Map.of("uraninite", "uranium", "aluminum", "bauxite", "cinnabar", "mercury");

   private static volatile MineSiteBoost shared;
   private final Map<String, List<double[]>> sitesByGroup;
   private final Map<Double, Map<String, Map<Long, List<double[]>>>> blockIndex = new ConcurrentHashMap<>();

   MineSiteBoost(Map<String, List<double[]>> sitesByGroup) {
      this.sitesByGroup = sitesByGroup;
   }

   public static MineSiteBoost shared() {
      MineSiteBoost s = shared;
      if (s == null) {
         synchronized (MineSiteBoost.class) {
            s = shared;
            if (s == null) {
               s = load();
               shared = s;
            }
         }
      }
      return s;
   }

   private static MineSiteBoost load() {
      Map<String, List<double[]>> sites = new HashMap<>();
      try (InputStream in = MineSiteBoost.class.getResourceAsStream(RESOURCE)) {
         if (in != null) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            for (String line = reader.readLine(); line != null; line = reader.readLine()) {
               if (line.isEmpty() || line.charAt(0) == '#') {
                  continue;
               }
               String[] p = line.split(",");
               sites.computeIfAbsent(p[0], k -> new ArrayList<>())
                  .add(new double[]{Double.parseDouble(p[1]), Double.parseDouble(p[2]), Double.parseDouble(p[3])});
            }
         }
      } catch (IOException | RuntimeException e) {
         // no sites: vanilla density everywhere
      }
      return new MineSiteBoost(sites);
   }

   /** The ore group an ore block path belongs to, or null (copper_ore, deepslate_gold_ore, uraninite_ore, ...). */
   public static String groupOf(String blockPath) {
      for (String token : blockPath.split("_")) {
         String group = ALIASES.getOrDefault(token, token);
         if (GROUPS.contains(group)) {
            return group;
         }
      }
      return null;
   }

   private static final java.util.Set<String> GROUPS = java.util.Set.of(
      "gold", "silver", "copper", "iron", "lead", "zinc", "tin", "nickel", "uranium", "bauxite", "tungsten", "manganese",
      "chromium", "platinum", "diamond", "coal", "lithium", "titanium", "cobalt", "molybdenum", "mercury", "sulfur",
      "antimony", "beryllium"
   );

   /** Density multiplier (1.0 = vanilla) for one ore group at a block position. */
   public double multiplier(String group, double blockX, double blockZ, double worldScale) {
      if (group == null || worldScale <= 0.0) {
         return 1.0;
      }
      Map<Long, List<double[]>> grid = this.blockIndex
         .computeIfAbsent(worldScale, s -> new ConcurrentHashMap<>())
         .computeIfAbsent(group, g -> this.buildGrid(g, worldScale));
      double radius = RADIUS_METERS / worldScale;
      int cx = (int)Math.floor(blockX) >> GRID_SHIFT;
      int cz = (int)Math.floor(blockZ) >> GRID_SHIFT;
      double extra = 0.0;
      for (int dx = -1; dx <= 1; dx++) {
         for (int dz = -1; dz <= 1; dz++) {
            List<double[]> cell = grid.get(key(cx + dx, cz + dz));
            if (cell == null) {
               continue;
            }
            for (double[] site : cell) {
               double dist = Math.hypot(site[0] - blockX, site[1] - blockZ);
               if (dist < radius) {
                  extra += site[2] * WEIGHT_TO_EXTRA * (1.0 - dist / radius);
               }
            }
         }
      }
      return 1.0 + Math.min(MAX_EXTRA, extra);
   }

   private Map<Long, List<double[]>> buildGrid(String group, double worldScale) {
      Map<Long, List<double[]>> grid = new HashMap<>();
      for (double[] s : this.sitesByGroup.getOrDefault(group, List.of())) {
         double x = EarthProjection.longitudeToBlockX(s[1], worldScale);
         double z = EarthProjection.latToBlockZ(s[0], worldScale);
         grid.computeIfAbsent(key((int)Math.floor(x) >> GRID_SHIFT, (int)Math.floor(z) >> GRID_SHIFT), k -> new ArrayList<>())
            .add(new double[]{x, z, s[2]});
      }
      return grid;
   }

   private static long key(int cx, int cz) {
      return ((long)cx << 32) ^ (cz & 0xFFFFFFFFL);
   }

   /** Rounds a fractional sample count up with matching probability so the mean density is exact. */
   public static int scaleSamples(int samples, double multiplier, RandomSource random) {
      double scaled = samples * multiplier;
      int whole = (int)Math.floor(scaled);
      return random.nextDouble() < scaled - whole ? whole + 1 : whole;
   }
}
