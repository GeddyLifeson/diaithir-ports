package com.yucareux.tellus.era;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

/**
 * Age I proglacial and closed-basin lakes (see world/earth/ice/build_ice_raster.py in the DiaithirRPG repo for sources).
 * Each lake is a level in metres relative to today's sea and a lon/lat bit mask of its connected basin, flood-filled from the
 * DEM at build time. The generator fills water up to the level where the terrain lies below it inside the mask, so the DEM
 * draws the shore and no water stands on ground outside the basin. Where a modern valley drains the basin below its level (cut
 * after the lake drained), an outlet fill gives the ground a floor: the lake level plus a block, tapering downstream.
 */
public final class EraLakes {
   private static final String DIR = "/data/tellus/diaithir/";
   private static volatile EraLakes shared;
   /**
    * Lakes that drained inside Age I, by name. Baltic Ice Lake: drained through the Billingen / Mt Billingen gap about 11.7 cal
    * ka, at the end of the Younger Dryas (Bjorck 1995, Quaternary International 27:19-40). Other lakes keep their 15 ka state
    * until a dated source is added.
    */
   static final java.util.Map<String, Double> END_KA = java.util.Map.of("Baltic Ice Lake", 11.7);

   /** Mask cell (col, row) covers lon west+col*res .. +res, lat north-row*res .. -res; rows are packed MSB first. */
   private record Lake(String name, double levelM, double west, double north, double res, int width, int height, byte[] bits, double startKa, double endKa) {
      /** The lake stands until this many ka before 1950 (see END_KA) and is gone from then on; any time before it stood. */
      boolean stands() {
         int y = EraRuntime.year();
         if (!Double.isNaN(this.startKa)) {   // a dated stage (glacial lakes): stands only between its start and end, and never with no year set
            double ka = EraTimeline.calBp(y) / 1000.0;
            return y != Integer.MIN_VALUE && ka <= this.startKa && ka >= this.endKa;
         }
         Double endKa = END_KA.get(this.name);
         return endKa == null || y == Integer.MIN_VALUE || EraTimeline.calBp(y) / 1000.0 >= endKa;
      }

      boolean contains(double lat, double lon) {
         double fx = (lon - this.west) / this.res;
         double fy = (this.north - lat) / this.res;
         if (!(fx >= 0.0 && fx < this.width && fy >= 0.0 && fy < this.height)) {   // NaN fails
            return false;
         }
         int col = (int) fx;
         int at = (int) fy * ((this.width + 7) >> 3) + (col >> 3);
         return (this.bits[at] >> (7 - (col & 7)) & 1) != 0;
      }
   }

   /** Outlet fill: ground floor in metres (today's datum) per cell, Short.MIN_VALUE where the ground is left as it is. */
   private record Fill(double west, double north, double res, int width, int height, short[] floor) {
      double floorMeters(double lat, double lon) {
         double fx = (lon - this.west) / this.res;
         double fy = (this.north - lat) / this.res;
         if (!(fx >= 0.0 && fx < this.width && fy >= 0.0 && fy < this.height)) {
            return Double.NaN;
         }
         short f = this.floor[(int) fy * this.width + (int) fx];
         return f == Short.MIN_VALUE ? Double.NaN : f;
      }
   }

   private final List<Lake> lakes = new ArrayList<>();
   private final List<Fill> fills = new ArrayList<>();

   EraLakes(JsonObject root) throws IOException {
      for (JsonElement e : root.getAsJsonArray("lakes")) {
         JsonObject o = e.getAsJsonObject();
         int width = o.get("width").getAsInt();
         int height = o.get("height").getAsInt();
         byte[] bits = inflate(Base64.getDecoder().decode(o.get("mask").getAsString()), height * ((width + 7) >> 3));
         this.lakes.add(new Lake(o.get("name").getAsString(), o.get("level_m").getAsDouble(), o.get("west").getAsDouble(),
            o.get("north").getAsDouble(), o.get("res").getAsDouble(), width, height, bits,
            o.has("start_ka") ? o.get("start_ka").getAsDouble() : Double.NaN, o.has("end_ka") ? o.get("end_ka").getAsDouble() : Double.NaN));
         if (o.has("outlet_fills")) {
            for (JsonElement fe : o.getAsJsonArray("outlet_fills")) {
               JsonObject f = fe.getAsJsonObject();
               int fw = f.get("width").getAsInt();
               int fh = f.get("height").getAsInt();
               short[] floor = new short[fw * fh];
               ByteBuffer.wrap(inflate(Base64.getDecoder().decode(f.get("floor_m").getAsString()), floor.length * 2))
                  .order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(floor);
               this.fills.add(new Fill(f.get("west").getAsDouble(), f.get("north").getAsDouble(), f.get("res").getAsDouble(), fw, fh, floor));
            }
         }
      }
   }

   private static byte[] inflate(byte[] data, int size) throws IOException {
      Inflater inflater = new Inflater();
      try {
         inflater.setInput(data);
         byte[] out = new byte[size];
         int n = 0;
         while (n < size && !inflater.finished()) {
            int k = inflater.inflate(out, n, size - n);
            if (k == 0 && (inflater.needsInput() || inflater.needsDictionary())) {
               break;
            }
            n += k;
         }
         if (n != size || !inflater.finished()) {
            throw new IOException("lake mask is " + n + " bytes, expected " + size);
         }
         return out;
      } catch (DataFormatException e) {
         throw new IOException("bad lake mask", e);
      } finally {
         inflater.end();
      }
   }

   public static EraLakes loadFromClasspath() throws IOException {
      try (InputStream in = EraLakes.class.getResourceAsStream(DIR + "lakes.json")) {
         if (in == null) {
            throw new IOException("lakes.json missing under " + DIR);
         }
         JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
         try (InputStream dated = EraLakes.class.getResourceAsStream(DIR + "lakes_glacial.json")) {   // dated stages, optional
            if (dated != null) {
               root.getAsJsonArray("lakes").addAll(JsonParser.parseReader(new InputStreamReader(dated, StandardCharsets.UTF_8)).getAsJsonObject().getAsJsonArray("lakes"));
            }
         }
         return new EraLakes(root);
      }
   }

   public static EraLakes shared() {
      EraLakes s = shared;
      if (s == null) {
         synchronized (EraLakes.class) {
            if (shared == null) {
               try {
                  shared = loadFromClasspath();
               } catch (IOException e) {
                  throw new IllegalStateException("cannot load Diaithir lakes", e);
               }
            }
            s = shared;
         }
      }
      return s;
   }

   public int size() {
      return this.lakes.size();
   }

   /** Ground floor (metres, today's datum) an outlet fill sets here, NaN where none applies. */
   public double outletFloorMeters(double lat, double lon) {
      for (Fill fill : this.fills) {
         double f = fill.floorMeters(lat, lon);
         if (!Double.isNaN(f)) {
            return f;
         }
      }
      return Double.NaN;
   }

   public int outletFillCount() {
      return this.fills.size();
   }

   /** Lake level in metres relative to today's sea at this point, NaN outside every lake basin (or for NaN input). */
   public double levelMeters(double lat, double lon) {
      for (Lake lake : this.lakes) {
         if (lake.stands() && lake.contains(lat, lon)) {
            return lake.levelM;
         }
      }
      return Double.NaN;
   }
}
