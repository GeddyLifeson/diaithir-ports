package com.yucareux.tellus.era;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * Sea level over game time. Keyframes are (LC year, global sea level in metres against today), from
 * world/earth/timeline/SEA_LEVEL.csv in the DiaithirRPG repo. Terrain stays at the era's base datum; only the water
 * level moves, so inland chunks generated at different dates match and only coasts differ.
 */
public final class EraTimeline {
   private static final String RESOURCE = "/data/tellus/diaithir/era_timeline.json";
   private static volatile EraTimeline shared;

   /** Time slices of the ice, vegetation and climate rasters, in ka before 1950, oldest first. Beyond either end the nearest holds. */
   public static final int OLDEST_SLICE_KA = 15, YOUNGEST_SLICE_KA = 0;
   /** Ice rasters exist down to 6 ka; from 5 ka on there is none (the later rasters only held model noise against today's ice). */
   public static final int ICE_END_KA = 5;
   private static final int LC_OF_BP0 = 14873; // BP 0 = AD 1950 = LC 14,873 (engine Calendar: LC 14,949 = AD 2026)

   private final int[] lc;
   private final double[] seaM;

   EraTimeline(int[] lc, double[] seaM) {
      if (lc.length == 0 || lc.length != seaM.length) {
         throw new IllegalArgumentException("era timeline needs matching, non-empty keyframes");
      }
      for (int i = 1; i < lc.length; i++) {
         if (lc[i] <= lc[i - 1]) {
            throw new IllegalArgumentException("era timeline keyframes must rise in LC year");
         }
      }
      this.lc = lc;
      this.seaM = seaM;
   }

   static EraTimeline parse(JsonObject json) {
      JsonArray keys = json.getAsJsonArray("sea");
      int[] lc = new int[keys.size()];
      double[] sea = new double[keys.size()];
      int i = 0;
      for (JsonElement k : keys) {
         JsonArray pair = k.getAsJsonArray();
         lc[i] = pair.get(0).getAsInt();
         sea[i++] = pair.get(1).getAsDouble();
      }
      return new EraTimeline(lc, sea);
   }

   public static EraTimeline shared() {
      EraTimeline t = shared;
      if (t == null) {
         synchronized (EraTimeline.class) {
            if ((t = shared) == null) {
               try (InputStream in = EraTimeline.class.getResourceAsStream(RESOURCE)) {
                  if (in == null) {
                     throw new IllegalStateException("missing " + RESOURCE);
                  }
                  t = parse(JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject());
               } catch (IOException e) {
                  throw new IllegalStateException("cannot read " + RESOURCE, e);
               }
               shared = t;
            }
         }
      }
      return t;
   }

   /** Global sea level against today at an LC year: linear between keyframes, held flat before the first and after the last. */
   public double seaMeters(int year) {
      int n = this.lc.length;
      if (year <= this.lc[0]) {
         return this.seaM[0];
      }
      if (year >= this.lc[n - 1]) {
         return this.seaM[n - 1];
      }
      int i = 1;
      while (this.lc[i] < year) {
         i++;
      }
      double t = (double) (year - this.lc[i - 1]) / (this.lc[i] - this.lc[i - 1]);
      return this.seaM[i - 1] + (this.seaM[i] - this.seaM[i - 1]) * t;
   }

   /** Years before 1950 at an LC year. */
   public static int calBp(int year) {
      return LC_OF_BP0 - year;
   }

   /** {older slice ka, younger slice ka, share of the younger} between the two slices that bracket the year. */
   public static double[] bracket(int year) {
      double ka = calBp(year) / 1000.0;
      if (ka >= OLDEST_SLICE_KA) {
         return new double[] {OLDEST_SLICE_KA, OLDEST_SLICE_KA, 0.0};
      }
      if (ka <= YOUNGEST_SLICE_KA) {
         return new double[] {YOUNGEST_SLICE_KA, YOUNGEST_SLICE_KA, 0.0};
      }
      double younger = Math.floor(ka);
      return new double[] {younger + 1.0, younger, younger + 1.0 - ka};
   }

   /** The slice a place reads at this year: the younger one for a share of places equal to the time fraction (unit is 0 to 1). */
   public static int sliceKa(int year, double unit) {
      double[] b = bracket(year);
      return (int) (unit < b[2] ? b[1] : b[0]);
   }

   /** Whole blocks the water stands above the era's base datum (never below it), at metresPerBlock. */
   public int floodBlocks(int year, double baseOffsetM, double metersPerBlock) {
      return Math.max(0, (int) Math.round((this.seaMeters(year) - baseOffsetM) / metersPerBlock));
   }
}
