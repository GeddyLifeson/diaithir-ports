package com.yucareux.tellus.era;

import com.yucareux.tellus.world.data.biome.BiomeClassification;
import com.yucareux.tellus.world.data.biome.BiomeClassificationProvider;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;

/** Age I vegetation biomes (EraRuntime.vegetationBiome); returns null outside an era with vegetation so the stock classifiers decide. */
public final class EraBiomeProvider implements BiomeClassificationProvider {
   @Override
   public ResourceKey<Biome> findBiomeKey(int esaCode, String koppenCode, int blockX, int blockZ, double worldScale) {
      String id = EraRuntime.vegetationBiome(esaCode, blockX, blockZ, worldScale);
      return id == null ? null : BiomeClassification.toBiomeKey(id);
   }

   @Override
   public Set<ResourceKey<Biome>> allBiomeKeys() {
      return EraVegetation.biomeIds().stream().map(BiomeClassification::toBiomeKey).collect(Collectors.toUnmodifiableSet());
   }
}
