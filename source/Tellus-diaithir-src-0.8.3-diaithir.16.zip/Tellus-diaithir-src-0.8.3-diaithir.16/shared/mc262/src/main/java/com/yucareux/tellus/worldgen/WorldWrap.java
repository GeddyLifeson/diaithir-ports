package com.yucareux.tellus.worldgen;

import com.yucareux.tellus.compat.MinecraftVersionCompat;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.RegistryAccess;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.PalettedContainerFactory;
import net.minecraft.world.level.chunk.ProtoChunk;
import net.minecraft.world.level.chunk.UpgradeData;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;

/**
 * Loops an Earth world. Anything (a boat with everyone in it, a player, a mob) crossing the antimeridian comes
 * out at the other edge with its speed; crossing a pole edge it comes out at the same edge on the far
 * hemisphere, heading back. Chunks past the edges are copies of their twin on the far side
 * ({@link #fillFromTwin}; biomes and decoration sample through {@link EarthProjection#blockLongitude}), so the
 * jump is not visible.
 */
public final class WorldWrap {
   private WorldWrap() {
   }

   public static void tick(MinecraftServer server) {
      for (ServerLevel level : server.getAllLevels()) {
         if (level.getChunkSource().getGenerator() instanceof EarthChunkGenerator generator) {
            double edge = EarthProjection.edgeBlocks(generator.settings().worldScale());
            List<Entity> crossed = new ArrayList<>();
            for (Entity entity : level.getAllEntities()) {
               if (entity.getVehicle() == null && (Math.abs(entity.getX()) > edge || Math.abs(entity.getZ()) > edge)) {
                  crossed.add(entity);
               }
            }
            crossed.forEach(root -> wrap(level, root, edge));
         }
      }
   }

   private static void wrap(ServerLevel level, Entity root, double edge) {
      double x = root.getX();
      double z = root.getZ();
      Vec3 motion = root.getDeltaMovement();
      float yaw = root.getYRot();
      if (Math.abs(z) > edge) {
         x += edge;
         z = Math.signum(z) * 2.0 * edge - z;
         motion = new Vec3(motion.x, motion.y, -motion.z);
         yaw = 180.0F - yaw;
      }
      Vec3 target = new Vec3(EarthProjection.wrapX(x, edge), root.getY(), z);
      // Players load their own chunks; anything else waits past the edge until the far side is loaded.
      if (root.getSelfAndPassengers().noneMatch(ServerPlayer.class::isInstance) && !level.hasChunkAt(BlockPos.containing(target))) {
         return;
      }
      root.teleport(new TeleportTransition(level, target, motion, yaw, root.getXRot(), Set.of(), TeleportTransition.DO_NOTHING));
   }

   /** The chunk inside the world that a chunk past an edge shows, or null for a chunk inside the world. */
   static ChunkPos twinChunk(ChunkPos pos, double worldScale) {
      int edge = (int)EarthProjection.edgeBlocks(worldScale) >> 4;
      int x = MinecraftVersionCompat.chunkX(pos);
      int z = MinecraftVersionCompat.chunkZ(pos);
      if (x >= -edge && x < edge && z >= -edge && z < edge) {
         return null;
      }
      if (z < -edge || z >= edge) {
         x += edge;
         z = (z < 0 ? -2 * edge : 2 * edge) - 1 - z;
      }
      return new ChunkPos(Math.floorMod(x + edge, 2 * edge) - edge, z);
   }

   /** Generates the twin into a scratch chunk with {@code fill} and copies its blocks, flipped north-south past a pole. */
   static void fillFromTwin(ChunkAccess chunk, ChunkPos twin, RegistryAccess registries, Consumer<ChunkAccess> fill) {
      ProtoChunk scratch = new ProtoChunk(twin, UpgradeData.EMPTY, chunk, PalettedContainerFactory.create(registries), null);
      fill.accept(scratch);
      boolean flip = MinecraftVersionCompat.chunkZ(twin) != MinecraftVersionCompat.chunkZ(chunk.getPos());
      LevelChunkSection[] to = chunk.getSections();
      LevelChunkSection[] from = scratch.getSections();
      if (!flip) {
         for (int i = 0; i < to.length; i++) {
            to[i] = new LevelChunkSection(from[i].getStates(), to[i].getBiomes());
         }
      } else {
         for (int i = 0; i < to.length; i++) {
            if (!from[i].hasOnlyAir()) {
               copyFlipped(from[i], to[i]);
            }
         }
      }
      Heightmap.primeHeightmaps(chunk, EnumSet.of(Heightmap.Types.OCEAN_FLOOR_WG, Heightmap.Types.WORLD_SURFACE_WG));
   }

   private static void copyFlipped(LevelChunkSection from, LevelChunkSection to) {
      for (int y = 0; y < 16; y++) {
         for (int z = 0; z < 16; z++) {
            for (int x = 0; x < 16; x++) {
               to.setBlockState(x, y, 15 - z, from.getBlockState(x, y, z), false);
            }
         }
      }
   }
}
