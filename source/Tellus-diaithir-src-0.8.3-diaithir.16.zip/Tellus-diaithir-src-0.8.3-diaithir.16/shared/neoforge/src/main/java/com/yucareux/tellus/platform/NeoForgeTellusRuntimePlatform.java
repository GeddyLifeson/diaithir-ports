package com.yucareux.tellus.platform;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.yucareux.tellus.compat.MinecraftVersionCompat;
import com.yucareux.tellus.compat.TellusMinecraftCompat;
import com.yucareux.tellus.era.EraPreload;
import com.yucareux.tellus.era.EraRuntime;
import com.yucareux.tellus.worldgen.EarthChunkGenerator;
import com.yucareux.tellus.worldgen.EarthProjection;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent;
import net.neoforged.neoforge.event.level.ChunkEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

public final class NeoForgeTellusRuntimePlatform implements TellusRuntimePlatform {
   @Override
   public void registerCommands(Consumer<CommandDispatcher<CommandSourceStack>> registration) {
      NeoForge.EVENT_BUS.addListener((RegisterCommandsEvent event) -> {
         registration.accept(event.getDispatcher());
         registerEraCommands(event.getDispatcher());
      });
   }

   private static void registerEraCommands(CommandDispatcher<CommandSourceStack> dispatcher) {
      dispatcher.register(Commands.literal("diaithir_column").requires(TellusMinecraftCompat::hasGamemasterPermission)
         .then(Commands.argument("lat", DoubleArgumentType.doubleArg(-85.0, 85.0))
            .then(Commands.argument("lon", DoubleArgumentType.doubleArg(-180.0, 180.0)).executes(ctx -> {
               var level = ctx.getSource().getLevel();
               if (!(level.getChunkSource().getGenerator() instanceof EarthChunkGenerator gen)) {
                  ctx.getSource().sendFailure(Component.literal("COLUMN error=not-an-earth-generator"));
                  return 0;
               }
               double s = gen.settings().worldScale();
               int x = (int) Math.round(EarthProjection.longitudeToBlockX(DoubleArgumentType.getDouble(ctx, "lon"), s));
               int z = (int) Math.round(EarthProjection.latToBlockZ(DoubleArgumentType.getDouble(ctx, "lat"), s));
               var chunk = level.getChunk(x >> 4, z >> 4, net.minecraft.world.level.chunk.status.ChunkStatus.FULL, true);
               int top = chunk.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE, x & 15, z & 15);
               int floor = chunk.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.OCEAN_FLOOR, x & 15, z & 15);
               var block = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(
                  chunk.getBlockState(new net.minecraft.core.BlockPos(x, top - 1, z)).getBlock());
               String line = "COLUMN blockX=" + x + " blockZ=" + z + " surfaceY=" + top + " floorY=" + floor + " top=" + block + " | " + gen.waterDebug(x, z);
               ctx.getSource().sendSuccess(() -> Component.literal(line), false);
               return 1;
            }))));
      dispatcher.register(Commands.literal("diaithir_preload").requires(TellusMinecraftCompat::hasGamemasterPermission)
         .then(Commands.argument("latMin", DoubleArgumentType.doubleArg(-85.0, 85.0))
            .then(Commands.argument("latMax", DoubleArgumentType.doubleArg(-85.0, 85.0))
               .then(Commands.argument("lonMin", DoubleArgumentType.doubleArg(-180.0, 180.0))
                  .then(Commands.argument("lonMax", DoubleArgumentType.doubleArg(-180.0, 180.0)).executes(ctx -> {
                     if (!(ctx.getSource().getLevel().getChunkSource().getGenerator() instanceof EarthChunkGenerator gen)) {
                        ctx.getSource().sendFailure(Component.literal("PRELOAD error=not-an-earth-generator"));
                        return 0;
                     }
                     String line;
                     try {
                        line = EraPreload.start(
                           DoubleArgumentType.getDouble(ctx, "latMin"), DoubleArgumentType.getDouble(ctx, "latMax"),
                           DoubleArgumentType.getDouble(ctx, "lonMin"), DoubleArgumentType.getDouble(ctx, "lonMax"), gen.settings());
                     } catch (IllegalArgumentException error) {
                        ctx.getSource().sendFailure(Component.literal("PRELOAD error=" + error.getMessage()));
                        return 0;
                     }
                     ctx.getSource().sendSuccess(() -> Component.literal(line), false);
                     return 1;
                  }))))));
      dispatcher.register(Commands.literal("diaithir_preload_status").requires(TellusMinecraftCompat::hasGamemasterPermission)
         .executes(ctx -> {
            String line = EraPreload.status();
            ctx.getSource().sendSuccess(() -> Component.literal(line), false);
            return 1;
         }));
      dispatcher.register(Commands.literal("diaithir_era").requires(TellusMinecraftCompat::hasGamemasterPermission)
         .executes(ctx -> {
            String line = "ERA year=" + EraRuntime.year() + " flood=" + EraRuntime.floodBlocks(5.0);
            ctx.getSource().sendSuccess(() -> Component.literal(line), false);
            return 1;
         })
         .then(Commands.argument("lc", IntegerArgumentType.integer(1)).executes(ctx -> {
            EraRuntime.setYear(IntegerArgumentType.getInteger(ctx, "lc"));
            String line = "ERA year=" + EraRuntime.year() + " flood=" + EraRuntime.floodBlocks(5.0);
            ctx.getSource().sendSuccess(() -> Component.literal(line), false);
            return 1;
         })));
      dispatcher.register(Commands.literal("diaithir_probe").requires(TellusMinecraftCompat::hasGamemasterPermission)
         .then(Commands.argument("lat", DoubleArgumentType.doubleArg(-85.0, 85.0))
            .then(Commands.argument("lon", DoubleArgumentType.doubleArg(-180.0, 180.0)).executes(ctx -> {
               var level = ctx.getSource().getLevel();
               if (!(level.getChunkSource().getGenerator() instanceof EarthChunkGenerator gen)) {
                  ctx.getSource().sendFailure(Component.literal("PROBE error=not-an-earth-generator"));
                  return 0;
               }
               double s = gen.settings().worldScale();
               int x = (int) Math.round(EarthProjection.longitudeToBlockX(DoubleArgumentType.getDouble(ctx, "lon"), s));
               int z = (int) Math.round(EarthProjection.latToBlockZ(DoubleArgumentType.getDouble(ctx, "lat"), s));
               String line = gen.probe(x, z).line();
               ctx.getSource().sendSuccess(() -> Component.literal(line), false);
               return 1;
            }))));
      dispatcher.register(Commands.literal("diaithir_scan").requires(TellusMinecraftCompat::hasGamemasterPermission)
         .then(Commands.argument("lat", DoubleArgumentType.doubleArg(-85.0, 85.0))
            .then(Commands.argument("lon", DoubleArgumentType.doubleArg(-180.0, 180.0))
               .then(Commands.argument("radius", IntegerArgumentType.integer(0, 8)).executes(ctx -> {
                  var level = ctx.getSource().getLevel();
                  if (!(level.getChunkSource().getGenerator() instanceof EarthChunkGenerator gen)) {
                     ctx.getSource().sendFailure(Component.literal("SCAN error=not-an-earth-generator"));
                     return 0;
                  }
                  double s = gen.settings().worldScale();
                  int cx = (int) Math.floor(EarthProjection.longitudeToBlockX(DoubleArgumentType.getDouble(ctx, "lon"), s)) >> 4;
                  int cz = (int) Math.floor(EarthProjection.latToBlockZ(DoubleArgumentType.getDouble(ctx, "lat"), s)) >> 4;
                  int r = IntegerArgumentType.getInteger(ctx, "radius"), chunks = 0, starts = 0, bes = 0;
                  var structureIds = new java.util.TreeSet<String>();
                  var blockIds = new java.util.TreeSet<String>();
                  for (int dx = -r; dx <= r; dx++) {
                     for (int dz = -r; dz <= r; dz++) {
                        var chunk = level.getChunk(cx + dx, cz + dz, net.minecraft.world.level.chunk.status.ChunkStatus.FULL, true);
                        chunks++;
                        starts += chunk.getAllStarts().size();
                        bes += chunk.getBlockEntitiesPos().size();
                        var structures = level.registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.STRUCTURE);
                        chunk.getAllStarts().keySet().forEach(structure -> structureIds.add(String.valueOf(structures.getKey(structure))));
                        for (var pos : chunk.getBlockEntitiesPos()) {
                           blockIds.add(String.valueOf(net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(chunk.getBlockState(pos).getBlock())));
                        }
                     }
                  }
                  String line = "SCAN chunks=" + chunks + " structureStarts=" + starts + " blockEntities=" + bes
                     + " structureIds=" + String.join(",", structureIds) + " blockIds=" + String.join(",", blockIds);
                  ctx.getSource().sendSuccess(() -> Component.literal(line), false);
                  return 1;
               })))));
   }

   @Override
   public void onServerStarted(Consumer<MinecraftServer> callback) {
      NeoForge.EVENT_BUS.addListener((ServerStartedEvent event) -> callback.accept(event.getServer()));
   }

   @Override
   public void onServerStopping(Consumer<MinecraftServer> callback) {
      NeoForge.EVENT_BUS.addListener((ServerStoppingEvent event) -> callback.accept(event.getServer()));
   }

   @Override
   public void onServerTick(Consumer<MinecraftServer> callback) {
      NeoForge.EVENT_BUS.addListener((ServerTickEvent.Post event) -> callback.accept(event.getServer()));
   }

   @Override
   public void onChunkUnload(BiConsumer<ServerLevel, ChunkPos> callback) {
      NeoForge.EVENT_BUS.addListener((ChunkEvent.Unload event) -> {
         if (event.getLevel() instanceof ServerLevel level) {
            callback.accept(level, event.getChunk().getPos());
         }
      });
   }

   @Override
   public void onPlayerJoin(BiConsumer<MinecraftServer, ServerPlayer> callback) {
      NeoForge.EVENT_BUS.addListener((PlayerLoggedInEvent event) -> {
         if (event.getEntity() instanceof ServerPlayer player) {
            MinecraftServer server = MinecraftVersionCompat.serverLevel(player).getServer();
            if (server != null) {
               callback.accept(server, player);
            }
         }
      });
   }

   @Override
   public void onPlayerDisconnect(Consumer<ServerPlayer> callback) {
      NeoForge.EVENT_BUS.addListener((PlayerLoggedOutEvent event) -> {
         if (event.getEntity() instanceof ServerPlayer player) {
            callback.accept(player);
         }
      });
   }
}
